const fast_connection = require("../connections/fastconnection");
const mongoose = require('mongoose');


class reports_servies {
  // static async getAllEmployeesWithSubmissions() {
  //   try {
  //     const employees = await fast_connection.models.employee
  //       .find({ is_deleted: false })
  //       .select("-date_of_hire -date_of_joining -date_of_birth -marital_Status -gender -address_line_1 -address_line_2 -city -pincode -pan_number -aadhaar_number -password_hash")  
  //       .populate({
  //         path: "reports_to",
  //         select: ["first_name", "last_name", "employee_id"],
  //       })
  //       .collation({ locale: "en_US", strength: 2 });
  
  //     const employeeSubmissions = await Promise.all(
  //       employees.map(async (employee) => {
  //         const submissionsCount = await fast_connection.models.submission
  //           .countDocuments({
  //             is_deleted: false,
  //             submitted_by: employee._id,
  //           });
  
  //         const approvalStatus = await fast_connection.models.submission.find({is_deleted: false, submitted_by:employee._id}  )
  //            .populate({
  //               path: "submitted_by",
  //               match: { role: "recruiters" }, // Match only submissions by recruiters
  //               select: ["employee_id", "role"],
  //             }).select("approval");
              
  //        const approvalCount = await fast_connection.models.submission
  //             .countDocuments({
  //               is_deleted: false,
  //               submitted_by: employee._id,
  //               approval: true, // Count only submissions with approval status as true
  //             })
  //             .populate({
  //               path: "submitted_by",
  //               match: { role: "recruiters" }, // Match only submissions by recruiters
  //             });
     
  //         return { ...employee.toObject(), submissionsCount, approvalStatus, approvalCount };
  //       })
  //     );
  
  //     console.log(employeeSubmissions.length, "employeeSubmissions");
  
  //     return employeeSubmissions;
  //   } catch (error) {
  //     throw error;
  //   }
  // }

//\----------------------------------------

// static async getAllEmployeesWithSubmissions() {
//   try {
//     const employeeSubmissions = await fast_connection.models.employee.aggregate([
//       {
//         $lookup: {
//           from: "submission", // Assuming the name of the submission collection is "submission"
//           localField: "_id",
//           foreignField: "submitted_by",
//           as: "submissions"
//         }
//       },
//       {
//         $unwind: {
//           path: "$submissions",
//           preserveNullAndEmptyArrays: true
//         }
//       },
//       {
//         $group: {
//           _id: {
//             empId:"$_id",
//             employee_id: "$employee_id",
//             firstname: "$first_name",
//             reports_to: "$reports_to",

//           },
//           mobile_number: { $first: "$mobile_number" },
//           email: { $first: "$email" },
//           submissions_count: { $sum: 1 },
//           approvals_count: {
//             $sum: {
//               $cond: { if: { $eq: ["$submissions.approval", true] }, then: 1, else: 0 }
//             }
//           }
//         }
//       },
//       {
//         $lookup: {
//           from: "employee",
//           localField: "_id.reports_to",
//           foreignField: "_id",
//           as: "reports_to_employee"
//         }
//       },
//       {
//         $addFields: {
//           reports_to_firstname: { $arrayElemAt: ["$reports_to_employee.first_name", 0] }
//         }
//       },
//       {
//         $project: {
//           // _id: 1,
//           _id:0,
//           empId:"$_id.empId",
//           employee_id: "$_id.employee_id",
//           firstname: "$_id.firstname",
//           mobile_number: 1,
//           email: 1,
//           reports_to_firstname: 1,
//           submissions_count: 1,
//           approvals_count: 1
//         }
//       }
//     ]);
    
//     return employeeSubmissions;
//   } catch (error) {
//     console.error("Error fetching employees with submissions:", error);
//     throw error;
//   }
// }

// static async get_AM_WithSubmissions() {
//   try {
//     const employees = await fast_connection.models.employee
//       .find({ is_deleted: false, role:"account_manager" }).select("_id first_name last_name email mobile_number role status ")
//       .populate({
//         path: "reports_to",
//         select: ["first_name", "last_name", "employee_id"],
//       })
//     const employeeSubmissions = await Promise.all(
//       employees.map(async (employee) => {
//         const submissionsCount = await fast_connection.models.submission
//           .countDocuments({
//             is_deleted: false,
//             submitted_by: employee._id,
//           });

//         const submissions = await fast_connection.models.submission.find({ is_deleted: false, submitted_by: employee._id }).select("approval ");
//         const createdAt = await fast_connection.models.submission.find({ is_deleted: false, submitted_by: employee._id }).select("createdAt");

//         const approvalStatus = submissions.map(submission => submission.approval).filter(approval => approval !== undefined);
//         const approvalTrueCount = approvalStatus.reduce((count, status) => count + (status === true ? 1 : 0), 0);
//         const approvalFalseCount = approvalStatus.reduce((count, status) => count + (status === false ? 1 : 0), 0);


//         return { employee , createdAt,submissionsCount,approvalFalseCount,  approvalTrueCount };
//       })
//     );

//     console.log(employeeSubmissions.length, "employeeSubmissions");

//     return employeeSubmissions;
//   } catch (error) {
//     throw error;
//   }
// }
// static async get_AM_WithSubmissions(timeRange, searchValue) {
//   try {
//     console.log(timeRange,searchValue, "service searchValue")

    
//     const employees = await fast_connection.models.employee
//       .find({ is_deleted: false, role: "account_manager",
//       $in: [
//         { "employee id": { $regex: new RegExp(searchValue, 'i') } },
//         { "account manager": { $regex: new RegExp(searchValue, 'i') } },
//         { "reports to": { $regex: new RegExp(searchValue, 'i') } },
//         { "mobile": { $regex: new RegExp(searchValue, 'i') } },
//         { "email": { $regex: new RegExp(searchValue, 'i') } },
//       ],
//     })
//       .select("_id employee_id first_name last_name email mobile_number role status ")
//       .populate({
//         path: "reports_to",
//         select: ["first_name", "last_name", "employee_id"],
//       });

//     const employeeSubmissions = await Promise.all(
//       employees.map(async (employee) => {
//         let startDate, endDate; // Initialize start and end dates
// // console.log(startDate)
//         // Determine the start date based on the selected time range
//         switch (timeRange) {
//           case "today":
//             startDate = new Date();
//             startDate.setUTCHours(0, 0, 0, 0); // Start of the day
//             endDate = new Date();
//             endDate.setUTCHours(23, 59, 59, 999); // End of the day
//             break;
//           case "last_week":
//             startDate = new Date();
//             startDate.setDate(startDate.getDate() - 7); // Set start date to 7 days ago
//             endDate = new Date().setUTCHours(23, 59, 59, 999);
//   break;
//           case "last_month":
//             startDate = new Date();
//             startDate.setMonth(startDate.getMonth() - 1); // 1 month ago
//             endDate = new Date().setUTCHours(23, 59, 59, 999); // Current date/time
//             break;
//           case "last_year":
//             startDate = new Date();
//             startDate.setFullYear(startDate.getFullYear() - 1); // 1 year ago
//             endDate = new Date().setUTCHours(23, 59, 59, 999); // Current date/time
//             break;
//           default:
//             startDate = null; // Default to null for "Till date" or any other case
//             endDate = new Date(); // Default to current date/time for other cases
//             break;
//         }

//         let submissionsQuery = {
//           is_deleted: false,
//           submitted_by: employee._id,
//         //   $or:[
//         //     { "induvidual count":  { $regex: searchValue, $options: "i" }},
//         // { "team count":  { $regex: searchValue, $options: "i" } },
//         //   ]
//         };

//         if (startDate && endDate) {
//           submissionsQuery.createdAt = { $gte: startDate, $lt: endDate };
//         }

//         const submissions = await fast_connection.models.submission
//           .find(submissionsQuery)
//           .select("approval createdAt");

//         const pipeline = [
//           { $match: { _id: mongoose.Types.ObjectId(employee._id), is_deleted: false } },
//           {
//             $graphLookup: {
//               from: 'employees',
//               startWith: '$_id',
//               connectFromField: '_id',
//               connectToField: 'reports_to',
//               as: 'subordinates',
//               maxDepth: 10,
//               restrictSearchWithMatch: { is_deleted: false },
//             },
//           },
//           {
//             $facet: {
//               submission_results: [
//                 {
//                   $lookup: {
//                     from: 'submissions', // Assuming 'submissions' is the collection name
//                     let: { subordinateIds: '$subordinates._id' },
//                     pipeline: [
//                       {
//                         $match: {
//                           $expr: {
//                             $and: [
//                               { $in: ['$submitted_by', '$$subordinateIds'] }, // Match based on 'submitted_by' field
//                               { $eq: ['$is_deleted', false] },
//                             ],
//                           },
//                         },
//                       },
//                     ],
//                     as: 'subordinate_submissions',
//                   },
//                 },
//                 { $unwind: { path: '$subordinate_submissions', preserveNullAndEmptyArrays: true } },
//                 {
//                   $group: {
//                     _id: '$_id',
//                     subordinates: { $first: '$subordinates' },
//                     subordinate_submissions: { $push: '$subordinate_submissions' },
//                   },
//                 },
//               ],
//             },
//           },
//         ];

//         const results = await fast_connection.models.employee.aggregate(pipeline);

//         const submission_results = results[0].submission_results;
//         const sub_submission = submission_results[0].subordinate_submissions;

//         const todaySubmissions = startDate && endDate ?
//           sub_submission.filter(submission => {
//             const createdAtDate = new Date(submission.createdAt);
//             return createdAtDate >= startDate && createdAtDate <= endDate;
//           }) :
//           sub_submission;

//         const sub_teamCount = todaySubmissions.length;

//         const submissionsCount = submissions.length;

//         return { employee, submissionsCount, sub_teamCount };
//       })
//     );

//     console.log(employeeSubmissions.length, "employeeSubmissions");

//     return employeeSubmissions;
//   } catch (error) {
//     throw error;
//   }
// }
static async get_AM_WithSubmissions(timeRange, searchValue) {
  try {
    const employees = await fast_connection.models.employee
    .find({
      is_deleted: false,
      role: "account_manager",
      $or: [
        { "email": { $regex: new RegExp(searchValue, 'i') } },
        { "employee_id": { $regex: new RegExp(searchValue, 'i') } },
        { "first_name": { $regex: new RegExp(searchValue, 'i') } },
        { "last_name": { $regex: new RegExp(searchValue, 'i') } },
        { "mobile_number": { $regex: new RegExp(searchValue, 'i') } },
        { "reports_to": { $in: [mongoose.Types.ObjectId(searchValue)] } }, // Assuming searchValue is the ObjectId of the report_to

      ],
    })
    .select("_id employee_id first_name last_name email mobile_number role status ")
    .populate({
      path: "reports_to",
      select: ["first_name", "last_name", "employee_id"],
    });
  

    const employeeSubmissions = await Promise.all(
      employees.map(async (employee) => {
        let startDate, endDate;

        switch (timeRange) {
          case "today":
            startDate = new Date();
            startDate.setUTCHours(0, 0, 0, 0);
            endDate = new Date();
            endDate.setUTCHours(23, 59, 59, 999);
            break;
          case "last_week":
            startDate = new Date();
            startDate.setDate(startDate.getDate() - 7);
            endDate = new Date().setUTCHours(23, 59, 59, 999);
            break;
          case "last_month":
            startDate = new Date();
            startDate.setMonth(startDate.getMonth() - 1);
            endDate = new Date().setUTCHours(23, 59, 59, 999);
            break;
          case "last_year":
            startDate = new Date();
            startDate.setFullYear(startDate.getFullYear() - 1);
            endDate = new Date().setUTCHours(23, 59, 59, 999);
            break;
          default:
            startDate = null;
            endDate = new Date();
            break;
        }

        let submissionsQuery = {
          is_deleted: false,
          submitted_by: employee._id,
        };

        if (startDate && endDate) {
          submissionsQuery.createdAt = { $gte: startDate, $lt: endDate };
        }

        const submissions = await fast_connection.models.submission
          .find(submissionsQuery)
          .select("approval createdAt");

        const pipeline = [
          { $match: { _id: mongoose.Types.ObjectId(employee._id), is_deleted: false } },
          {
            $graphLookup: {
              from: 'employees',
              startWith: '$_id',
              connectFromField: '_id',
              connectToField: 'reports_to',
              as: 'subordinates',
              maxDepth: 10,
              restrictSearchWithMatch: { is_deleted: false },
            },
          },
          {
            $facet: {
              submission_results: [
                {
                  $lookup: {
                    from: 'submissions',
                    let: { subordinateIds: '$subordinates._id' },
                    pipeline: [
                      {
                        $match: {
                          $expr: {
                            $and: [
                              { $in: ['$submitted_by', '$$subordinateIds'] },
                              { $eq: ['$is_deleted', false] },
                            ],
                          },
                        },
                      },
                    ],
                    as: 'subordinate_submissions',
                  },
                },
                { $unwind: { path: '$subordinate_submissions', preserveNullAndEmptyArrays: true } },
                {
                  $group: {
                    _id: '$_id',
                    subordinates: { $first: '$subordinates' },
                    subordinate_submissions: { $push: '$subordinate_submissions' },
                  },
                },
              ],
            },
          },
        ];

        const results = await fast_connection.models.employee.aggregate(pipeline);

        const submission_results = results[0].submission_results;
        const sub_submission = submission_results[0].subordinate_submissions;

        const todaySubmissions = startDate && endDate ?
          sub_submission.filter(submission => {
            const createdAtDate = new Date(submission.createdAt);
            return createdAtDate >= startDate && createdAtDate <= endDate;
          }) :
          sub_submission;

        const sub_teamCount = todaySubmissions.length;
        const submissionsCount = submissions.length;

        return { employee, submissionsCount, sub_teamCount };
      })
    );

    return employeeSubmissions;
  } catch (error) {
    throw error;
  }
}




static async get_TL_WithSubmissions(timeRange,searchValue) {
  try {
    const employees = await fast_connection.models.employee
    .find({
      is_deleted: false,
      role: "team_lead",
      $or: [
        { "email": { $regex: new RegExp(searchValue, 'i') } },
        { "employee_id": { $regex: new RegExp(searchValue, 'i') } },
        { "first_name": { $regex: new RegExp(searchValue, 'i') } },
        { "last_name": { $regex: new RegExp(searchValue, 'i') } },
        { "mobile_number": { $regex: new RegExp(searchValue, 'i') } },
        
      ],
    })
    .select("_id employee_id first_name last_name email mobile_number role status ")
    .populate({
      path: "reports_to",
      select: ["first_name", "last_name", "employee_id"],
    });
  

    const employeeSubmissions = await Promise.all(
      employees.map(async (employee) => {
        let startDate, endDate;

        switch (timeRange) {
          case "today":
            startDate = new Date();
            startDate.setUTCHours(0, 0, 0, 0);
            endDate = new Date();
            endDate.setUTCHours(23, 59, 59, 999);
            break;
          case "last_week":
            startDate = new Date();
            startDate.setDate(startDate.getDate() - 7);
            endDate = new Date().setUTCHours(23, 59, 59, 999);
            break;
          case "last_month":
            startDate = new Date();
            startDate.setMonth(startDate.getMonth() - 1);
            endDate = new Date().setUTCHours(23, 59, 59, 999);
            break;
          case "last_year":
            startDate = new Date();
            startDate.setFullYear(startDate.getFullYear() - 1);
            endDate = new Date().setUTCHours(23, 59, 59, 999);
            break;
          default:
            startDate = null;
            endDate = new Date();
            break;
        }

        let submissionsQuery = {
          is_deleted: false,
          submitted_by: employee._id,
        };

        if (startDate && endDate) {
          submissionsQuery.createdAt = { $gte: startDate, $lt: endDate };
        }

        const submissions = await fast_connection.models.submission
          .find(submissionsQuery)
          .select("approval createdAt");

        const pipeline = [
          { $match: { _id: mongoose.Types.ObjectId(employee._id), is_deleted: false } },
          {
            $graphLookup: {
              from: 'employees',
              startWith: '$_id',
              connectFromField: '_id',
              connectToField: 'reports_to',
              as: 'subordinates',
              maxDepth: 10,
              restrictSearchWithMatch: { is_deleted: false },
            },
          },
          {
            $facet: {
              submission_results: [
                {
                  $lookup: {
                    from: 'submissions',
                    let: { subordinateIds: '$subordinates._id' },
                    pipeline: [
                      {
                        $match: {
                          $expr: {
                            $and: [
                              { $in: ['$submitted_by', '$$subordinateIds'] },
                              { $eq: ['$is_deleted', false] },
                            ],
                          },
                        },
                      },
                    ],
                    as: 'subordinate_submissions',
                  },
                },
                { $unwind: { path: '$subordinate_submissions', preserveNullAndEmptyArrays: true } },
                {
                  $group: {
                    _id: '$_id',
                    subordinates: { $first: '$subordinates' },
                    subordinate_submissions: { $push: '$subordinate_submissions' },
                  },
                },
              ],
            },
          },
        ];

        const results = await fast_connection.models.employee.aggregate(pipeline);

        const submission_results = results[0].submission_results;
        const sub_submission = submission_results[0].subordinate_submissions;

        const todaySubmissions = startDate && endDate ?
          sub_submission.filter(submission => {
            const createdAtDate = new Date(submission.createdAt);
            return createdAtDate >= startDate && createdAtDate <= endDate;
          }) :
          sub_submission;

        const sub_teamCount = todaySubmissions.length;
        const submissionsCount = submissions.length;

        return { employee, submissionsCount, sub_teamCount };
      })
    );

    return employeeSubmissions;
  } catch (error) {
    throw error;
  }
        }
        
        static async getRecruitersWithSubmissions(timeRange, searchValue) {
          try {
            const employees = await fast_connection.models.employee
              .find({
                is_deleted: false,
                role: "recruiter",
                $or: [
                  { "email": { $regex: new RegExp(searchValue, 'i') } },
                  { "employee_id": { $regex: new RegExp(searchValue, 'i') } },
                  { "first_name": { $regex: new RegExp(searchValue, 'i') } },
                  { "last_name": { $regex: new RegExp(searchValue, 'i') } },
                  { "mobile_number": { $regex: new RegExp(searchValue, 'i') } },
                ],
              })
              .select("_id employee_id first_name last_name email mobile_number role status ")
              .populate({
                path: "reports_to",
                select: ["first_name", "last_name", "employee_id"],
              });
        
            const employeeSubmissions = await Promise.all(
              employees.map(async (employee) => {
                let startDate, endDate;
        
                switch (timeRange) {
                  case "today":
                    startDate = new Date();
                    startDate.setHours(0, 0, 0, 0);
                    endDate = new Date();
                    endDate.setHours(23, 59, 59, 999);
                    break;
                  case "last_week":
                    startDate = new Date();
                    startDate.setDate(startDate.getDate() - 7);
                    endDate = new Date();
                    endDate.setUTCHours(23, 59, 59, 999);
                    break;
                  case "last_month":
                    startDate = new Date();
                    startDate.setMonth(startDate.getMonth() - 1);
                    endDate = new Date();
                    endDate.setUTCHours(23, 59, 59, 999);
                    break;
                  case "last_year":
                    startDate = new Date();
                    startDate.setFullYear(startDate.getFullYear() - 1);
                    endDate = new Date();
                    endDate.setUTCHours(23, 59, 59, 999);
                    break;
                  default:
                    startDate = null;
                    endDate = new Date();
                    break;
                }
        
                let submissionsQuery = {
                  is_deleted: false,
                  submitted_by: employee._id,
                };
        
                if (startDate && endDate) {
                  submissionsQuery.createdAt = { $gte: startDate, $lt: endDate };
                }
        
                const submissions = await fast_connection.models.submission
                  .find(submissionsQuery)
                  .select("approval createdAt");
        
                const submissionsCount = submissions.length;
                const approvalTrueCount = submissions.filter(submission => submission.approval === true).length;
                const approvalFalseCount = submissions.filter(submission => submission.approval === false).length;
        
                return { employee, submissionsCount, approvalFalseCount, approvalTrueCount };
              })
            );
        
            console.log(employeeSubmissions.length, "employeeSubmissions");
        
            return employeeSubmissions;
          } catch (error) {
            throw error;
          }
        }
  
        static async getAllroleSubmission(timeRange, searchValue) {
          try {
            console.log("all")
            const employees = await fast_connection.models.employee
              .find({
                is_deleted: false,
                role: { $in: ["recruiter", "account_manager", "team_lead"] },
                $or: [
                  { email: { $regex: new RegExp(searchValue, "i") } },
                  { employee_id: { $regex: new RegExp(searchValue, "i") } },
                  { first_name: { $regex: new RegExp(searchValue, "i") } },
                  { last_name: { $regex: new RegExp(searchValue, "i") } },
                  { mobile_number: { $regex: new RegExp(searchValue, "i") } },
                ],
              })
              .select("_id employee_id first_name last_name email mobile_number role status ")
              .populate({
                path: "reports_to",
                select: ["first_name", "last_name", "employee_id"],
              });
        
            const employeeSubmissions = await Promise.all(
              employees.map(async (employee) => {
                let startDate, endDate;
        
                switch (timeRange) {
                  case "today":
                    startDate = new Date();
                    startDate.setHours(0, 0, 0, 0);
                    endDate = new Date();
                    endDate.setHours(23, 59, 59, 999);
                    break;
                  case "last_week":
                    startDate = new Date();
                    startDate.setDate(startDate.getDate() - 7);
                    endDate = new Date();
                    endDate.setUTCHours(23, 59, 59, 999);
                    break;
                  case "last_month":
                    startDate = new Date();
                    startDate.setMonth(startDate.getMonth() - 1);
                    endDate = new Date();
                    endDate.setUTCHours(23, 59, 59, 999);
                    break;
                  case "last_year":
                    startDate = new Date();
                    startDate.setFullYear(startDate.getFullYear() - 1);
                    endDate = new Date();
                    endDate.setUTCHours(23, 59, 59, 999);
                    break;
                  default:
                    startDate = null;
                    endDate = new Date();
                    break;
                }
        
                let submissionsQuery = {
                  is_deleted: false,
                  submitted_by: employee._id,
                };
        
                if (startDate && endDate) {
                  submissionsQuery.createdAt = { $gte: startDate, $lt: endDate };
                }
        
                const submissions = await fast_connection.models.submission.find(submissionsQuery).select("approval createdAt");
        
                const submissionsCount = submissions.length;
                const approvalTrueCount = submissions.filter((submission) => submission.approval === true).length;
                const approvalFalseCount = submissions.filter((submission) => submission.approval === false).length;
        
                return { employee, submissionsCount, approvalFalseCount, approvalTrueCount };
              })
            );
        
            console.log(employeeSubmissions.length, "employeeSubmissions");
        
            return employeeSubmissions;
          } catch (error) {
            throw error;
          }
        }
        


  
 
}

module.exports = reports_servies;
