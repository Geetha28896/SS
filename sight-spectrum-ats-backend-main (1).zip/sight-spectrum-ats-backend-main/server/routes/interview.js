const express = require("express");
const router = express.Router();
const interview_controller = require("../controllers/interview_controller")


router.post("/scheduleMeet", interview_controller.scheduleMeet.controller)
router.get("/listInterview", interview_controller.listInterview.controller)
router.patch("/trackstat", interview_controller.statusTracker.controller)
router.get("/myinterview", interview_controller.getUserInterview.controller)
router.get("/intsearch", interview_controller.interviewSearch.controller)
router.patch("/updateStatus/:id", interview_controller.updateInterviewStatus.controller)
router.get("/getHierarchyListing", interview_controller.getUserInterviews.controller)


module.exports = router