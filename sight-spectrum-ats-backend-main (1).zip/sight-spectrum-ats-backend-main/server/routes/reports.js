const express = require("express");
const router = express.Router();
const reports_controller = require("../controllers/reports_controller");

// router.get("/getAllReports", reports_controller.getAllReports.controller);
router.get("/get_AM_Reports", reports_controller.get_AM_Reports.controller);
router.get("/get_TL_Reports", reports_controller.get_TL_Reports.controller);
router.get("/getRecruitersReports", reports_controller.getRecruitersReports.controller);
router.get("/downloadReports", reports_controller.downloadOverallPerformance.controller);
router.get("/searchReports", reports_controller.searchReports.controller);
module.exports = router;
