const reports_services = require("../services/reports_services"); // Corrected import for reports_services

// const getAllReports = {
//   controller: async (req, res) => {
//     try {
//       let getEmployee = await reports_services.getAllEmployeesWithSubmissions(); // Corrected method call

      
//       res.status(200).json({
//         data: getEmployee,
//         message: "All Employees fetched successfully",
//       });
//     } catch (error) {
//       console.error("Error:", error);
//       res.status(500).json({ error: "Internal Server Error" });
//     }
//   },
// };


const Excel = require("exceljs");
const { ISOdateToCustomDate } = require("../utils/ISO_date_helper")
const crypto = require("crypto");
const fs = require("fs");

const applyStylesToWorksheet = (worksheet, excelData) => {
  const columnHeaders = excelData.client;
  const columnWidths = columnHeaders.map((header, index) => ({
    header: header,
    key: String(index + 1),
    width: 18,
  }));

  worksheet.columns = columnWidths;

  const headerRow = worksheet.getRow(1);
  headerRow.eachCell({ includeEmpty: true }, (cell) => {
    cell.fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'DCE6F1' },
    };
    cell.alignment = { horizontal: 'center' };
    cell.border = {
      top: { style: 'thin', color: { argb: 'B2BEB5' } },
      left: { style: 'thin', color: { argb: 'B2BEB5' } },
      bottom: { style: 'thin', color: { argb: 'B2BEB5' } },
      right: { style: 'thin', color: { argb: 'B2BEB5' } },
    };
  });

  const dataRowStartIndex = 2;
  const columnWidthPadding = 5;

  // Style for data rows
  excelData.value.forEach((row, rowIndex) => {
    const rowValues = Object.values(row);
    rowValues.forEach((value, columnIndex) => {
      const cell = worksheet.getCell(rowIndex + dataRowStartIndex, columnIndex + 1);
      cell.value = value;
      cell.alignment = { horizontal: 'center' };
      const valueLength = String(value).length;
      const currentWidth = worksheet.getColumn(columnIndex + 1).width;
      const newWidth = Math.max(valueLength + columnWidthPadding, currentWidth);
      worksheet.getColumn(columnIndex + 1).width = newWidth;
      cell.border = {
        top: { style: 'thin', color: { argb: 'B2BEB5' } },
        left: { style: 'thin', color: { argb: 'B2BEB5' } },
        bottom: { style: 'thin', color: { argb: 'B2BEB5' } },
        right: { style: 'thin', color: { argb: 'B2BEB5' } },
      };
    });
  });
};

const searchReports = {
  controller: async (req, res) => {
    try {
      const { searchValue, role, timeRange } = req.query;

      let searchResults;
      switch (role) {
        case "all" || "":
        searchResults = await reports_services.getAllroleSubmission(timeRange, searchValue);

          break;
        case "account_manager":
          searchResults = await reports_services.get_AM_WithSubmissions(timeRange, searchValue);
          break;
        case "team_lead":
          searchResults = await reports_services.get_TL_WithSubmissions(timeRange,searchValue);
          break;
        case "recruiter":
          searchResults = await reports_services.getRecruitersWithSubmissions(timeRange,searchValue);
          break;
        default:
          console.log("hello")
          searchResults = await reports_services.getAllroleSubmission(timeRange, searchValue);

          // res.status(400).json({ message: "Invalid role" });
          break;
      }

      res.status(200).json({ message: "Search is done!", data: searchResults });
    } catch (err) {
      console.error(err);
      res.status(500).json({ err: 'Search error' });
    }
  }
};


// const searchReports = {
//   controller: async (req, res) => {
//     try {
//       const { role, timeRange, searchValue } = req.query; // Extract role, timeRange, and searchValue from request query
//       console.log("Role:", role);
//       console.log("Time Range:", timeRange);
//       console.log("Search Value:", searchValue);

//       let searchResults;
//       switch (role) {
//         case "account_manager":
//           console.log("Role: account_manager");
//           searchResults = await reports_services.get_AM_WithSubmissions(timeRange, searchValue);
//           console.log("Search Results (account_manager):", searchResults);
//           break;
//         case "team_lead":
//           console.log("Role: team_lead");
//           searchResults = await reports_services.get_TL_WithSubmissions(timeRange, searchValue);
//           console.log("Search Results (team_lead):", searchResults);
//           break;
//         case "recruiter":
//           console.log("Role: recruiter");
//           searchResults = await reports_services.getRecruitersWithSubmissions(timeRange, searchValue);
//           console.log("Search Results (recruiter):", searchResults);
//           break;
//         default:
//           console.log("Invalid role:", role);
//           // Handle other roles or default case
//           break;
//       }

//       res.status(200).json({ message: "Search is done!", data: searchResults });
//     } catch (err) {
//       console.error(err);
//       res.status(500).json({ err: 'Search error' });
//     }
//   }
// };


// const searchReports = {
//   controller: async (req, res) => {
//     try {
//       // const { searchValue, role,timeRange } = req.query;
//       const searchValue = "rec";
//       const role = "account_manager";
//       const timeRange = "last_week";
// console.log(searchValue)

//       let searchResults;
//       switch (role) {
//         case "account_manager":
//           console.log("Role: account_manager");
//           searchResults = await reports_services.get_AM_WithSubmissions(timeRange,searchValue);
//           console.log("Search Results (account_manager):", searchValue);
//           break;
//         case "team_lead":
//           console.log("Role: team_lead");
//           searchResults = await reports_services.get_TL_WithSubmissions(searchValue);
//           console.log("Search Results (team_lead):", searchResults);
//           break;
//         case "recruiter":
//           console.log("Role: recruiter");
//           searchResults = await reports_services.getRecruitersWithSubmissions(searchValue);
//           console.log("Search Results (recruiter):", searchResults);
//           break;
//         default:
//           console.log("Invalid role:", role);
//           // Handle other roles or default case
//           break;
//       }

//       res.status(200).json({ message: "Search is done!", data: searchResults });
//     } catch (err) {
//       console.error(err);
//       res.status(500).json({ err: 'Search error' });
//     }
//   }
// };






const downloadOverallPerformance = {
  controller: async (req, res) => {
    try {
      const role = req.query.role;
      const timeRange = req.query.timeRange;

      let AMData = [];
      let TLData = [];
      let RecData = [];

      switch (role) {
        case 'account_manager':
          AMData = await reports_services.get_AM_WithSubmissions(timeRange);
          break;
        case 'team_lead':
          TLData = await reports_services.get_TL_WithSubmissions(timeRange);
          break;
        case 'recruiter':
          RecData = await reports_services.getRecruitersWithSubmissions(timeRange);
          break;
        default:
          [AMData, TLData, RecData] = await Promise.all([
            reports_services.get_AM_WithSubmissions(timeRange),
            reports_services.get_TL_WithSubmissions(timeRange),
            reports_services.getRecruitersWithSubmissions(timeRange)
          ]);

      }


      const workbook = new Excel.Workbook();

      let accountManagerData = AMData.map(item => {
        let transformed = {
          'Employee ID': item.employee.employee_id,
          'Name': `${item.employee.first_name} ${item.employee.last_name} `,
          'Reports to': item.employee.reports_to ?` ${item.employee.reports_to.first_name} ${item.employee.reports_to.last_name}  `: 'N/A',
          'Mobile': item.employee.mobile_number,
          'Email ID': item.employee.email,
          'Individual Count': item.submissionsCount || 0,
          'Team Count': item.sub_teamCount || 0,
          "createdAt": ISOdateToCustomDate(item?.createdAt),

        };
        return transformed;
      });

      let teamLeadData = TLData.map(item => {
        let transformed = {
          'Employee ID': item.employee.employee_id, 
          'Name':` ${item.employee.first_name} ${item.employee.last_name}`,
          'Reports to': item.employee.reports_to ?` ${item.employee.reports_to.first_name} ${item.employee.reports_to.last_name} `: 'N/A',
          'Mobile': item.employee.mobile_number,
          'Email ID': item.employee.email,
          'Individual Count': item.submissionsCount || 0,
          'Team Count': item.sub_teamCount || 0,
          "createdAt": ISOdateToCustomDate(item?.createdAt),

        };
        return transformed;
      });

      let RecruiterData = RecData.map(item => {
        let transformed = {
          'Employee ID': item.employee.employee_id, 
          'Name': `${item.employee.first_name} ${item.employee.last_name}`,
          'Reports to': item.employee.reports_to ? `${item.employee.reports_to.first_name} ${item.employee.reports_to.last_name} `: 'N/A',
          'Mobile': item.employee.mobile_number,
          'Email ID': item.employee.email,
          'Individual Count': item.submissionsCount || 0,
          'Team Count': item.sub_teamCount || 0,
          "createdAt": ISOdateToCustomDate(item?.createdAt),

        };
        return transformed;
      });
      if (role === 'account_manager' || !role) {
        const AMWorksheet = workbook.addWorksheet('Account Managers');

        applyStylesToWorksheet(AMWorksheet, {
          client: ['Employee ID', 'Name', 'Reports to', 'Mobile', 'Email ID', 'Individual Count', 'Team Count'],
          value: accountManagerData
        });
      }

      if (role === 'team_lead' || !role) {
        const TLWorksheet = workbook.addWorksheet('Team Lead');

        applyStylesToWorksheet(TLWorksheet, {
          client: ['Employee ID', 'Name', 'Reports to', 'Mobile', 'Email ID', 'Individual Count', 'Team Count'],
          value: teamLeadData
        });
      }

      if (role === 'recruiter' || !role) {
        const RecruiterWorksheet = workbook.addWorksheet('Recruiter');

        applyStylesToWorksheet(RecruiterWorksheet, {
          client: ['Employee ID', 'Name', 'Reports to', 'Mobile', 'Email ID', 'Individual Count', 'Team Count'],
          value: RecruiterData
        });
      }

      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', 'attachment; filename=Overall_Performance.xlsx');


      await workbook.xlsx.write(res);


      // End the response
      res.end();
    } catch (error) {
      console.error('Error occurred while generating Excel:', error);
      res.status(500).send({ error: 'An error occurred while generating Excel file.' });
    }
  }
}
const get_AM_Reports = {
  controller: async (req, res) => {
    try {
      let timeRange = req.query.timeRange
      console.log(timeRange)
      let getEmployee = await reports_services.get_AM_WithSubmissions(timeRange); // Corrected method call
      
      res.status(200).json({
        data: getEmployee,
        message: "All Employees fetched successfully",
      });
    } catch (error) {
      console.error("Error:", error);
      res.status(500).json({ error: "Internal Server Error" });
    }
  },
};

const get_TL_Reports = {
  controller: async (req, res) => {
    try {
      console.log("tl")
      let timeRange = req.query.timeRange
      let getEmployee = await reports_services.get_TL_WithSubmissions(timeRange); // Corrected method call

      
      res.status(200).json({
        data: getEmployee,
        message: "All Employees fetched successfully",
      });
    } catch (error) {
      console.error("Error:", error);
      res.status(500).json({ error: "Internal Server Error" });
    }
  },
};




const getRecruitersReports = {
  controller: async (req, res) => {
    try {
      let timeRange = req.query.timeRange
      let getEmployee = await reports_services.getRecruitersWithSubmissions(timeRange); // Corrected method call

      
      res.status(200).json({
        data: getEmployee,
        message: "All Employees fetched successfully",
      });
    } catch (error) {
      console.error("Error:", error);
      res.status(500).json({ error: "Internal Server Error" });
    }
  },
};

module.exports = {
  // getAllReports
  get_AM_Reports,get_TL_Reports,getRecruitersReports,downloadOverallPerformance,searchReports
};
