const demand_services = require("../services/demand_services");
const submission_tracker_services = require("../services/submission_tracker_services");
const submission_services = require("../services/submission_services");
const employee_services = require("../services/employee_services");
const fast_connection = require("../connections/fastconnection");
const mongoose = require("mongoose");
const aggregate_servies = require("../services/aggregate_services");


const getDashboardAggregateData = {
  controller: async (req, res) => {
    const { start_date, end_date } = req.query;
    const current_user_id = req.auth.user_id;

    //active & overall demand count
    let submission_data = await submission_services.listUserSubmissions(current_user_id, start_date, end_date);
    let submission_data_day = await submission_services.listUserdaySubmissions(current_user_id);

    let demand_data = await demand_services.listUserCreatedDemands(current_user_id, start_date, end_date);
    const pipeline = [
      { $match: { _id: mongoose.Types.ObjectId(current_user_id), is_deleted: false } },
      {
        $graphLookup: {
          from: "employees",
          startWith: "$_id",
          connectFromField: "_id",
          connectToField: "reports_to",
          as: "subordinates",
          maxDepth: 10,
          restrictSearchWithMatch: { is_deleted: false },
        },
      },
      {
        $facet: {
          demand_results: [
            {
              $lookup: {
                from: "demands",
                let: { subordinateIds: "$subordinates._id" },
                pipeline: [
                  {
                    $match: {
                      $expr: {
                        $and: [{ $in: ["$created_by", "$$subordinateIds"] }, { $eq: ["$is_deleted", false] }],
                      },
                    },
                  },
                ],
                as: "subordinate_demands",
              },
            },
            { $unwind: { path: "$subordinate_demands", preserveNullAndEmptyArrays: true } },
            {
              $group: {
                _id: "$_id",
                subordinates: { $first: "$subordinates" },
                subordinate_demands: { $push: "$subordinate_demands" },
              },
            },
          ],
          submission_results: [
            {
              $lookup: {
                from: "submissions", // Assuming 'submissions' is the collection name
                let: { subordinateIds: "$subordinates._id" },
                pipeline: [
                  {
                    $match: {
                      $expr: {
                        $and: [
                          { $in: ["$submitted_by", "$$subordinateIds"] }, // Match based on 'submitted_by' field
                          { $eq: ["$is_deleted", false] },
                        ],
                      },
                    },
                  },
                ],
                as: "subordinate_submissions",
              },
            },
            { $unwind: { path: "$subordinate_submissions", preserveNullAndEmptyArrays: true } },
            {
              $group: {
                _id: "$_id",
                subordinates: { $first: "$subordinates" },
                subordinate_submissions: { $push: "$subordinate_submissions" },
              },
            },
          ],
        },
      },
    ];
    const results = await fast_connection.models.employee.aggregate(pipeline);
    const demand_results = results[0].demand_results;
    const sub_demand = demand_results[0].subordinate_demands;

    const add_total_demand = [...sub_demand, ...demand_data];

    let filtered_demands;
    if (start_date && end_date) {
      filtered_demands = add_total_demand.filter((demand) => {
        const createdAtDate = new Date(demand.createdAt);
        return createdAtDate >= new Date(start_date) && createdAtDate <= new Date(end_date);
      });
    } else {
      filtered_demands = add_total_demand;
    }

    let active_demands_count = filtered_demands.filter((i) => i.status === "Open").length;

    let total_demands = filtered_demands.length;

    const submission_results = results[0].submission_results;
    const sub_submission = submission_results[0].subordinate_submissions || [];
    let team_submission, user_submission, totel_submission;

    // Filter submissions based on start_date and end_date
    let filtered_submissions;
    if (start_date && end_date) {
      filtered_submissions = sub_submission.filter((submission) => {
        const createdAtDate = new Date(submission.createdAt);
        return createdAtDate >= new Date(start_date) && createdAtDate <= new Date(end_date);
      });
    } else {
      filtered_submissions = sub_submission;
    }

    team_submission = filtered_submissions.length;

    user_submission = submission_data.length;

    totel_submission = team_submission + user_submission;

    let submissions_data = await submission_tracker_services.getSubmissionTrackersCreatedByUser(
      current_user_id,
      start_date,
      end_date
    );
    let interview_arr = ["initial_screening", "level_1", "level_2", "level_3"];
    let submissions_details = submissions_data.reduce(
      (acc, curr) => {
        if (interview_arr.includes(curr.status)) {
          acc.interview++;
        } else if (curr.status == "joined") {
          acc.joined++;
        } else if (curr.status == "offered") {
          acc.offered++;
        }
        if (curr.status == "level_1") {
          acc.l1++;
        } else if (curr.status == "level_2") {
          acc.l2++;
        } else if (curr.status == "level_3") {
          acc.l3++;
        }
        acc.submissions++;

        return acc;
      },
      { interview: 0, offered: 0, joined: 0, submissions: 0, l1: 0, l2: 0, l3: 0 }
    );

    //Per day submission

    const todayStart = new Date();
    todayStart.setUTCHours(0, 0, 0, 0);
    const todayEnd = new Date();
    todayEnd.setUTCHours(23, 59, 59, 999);

    const today_submission = submission_data_day.filter((submission) => {
      const createdAtDate = new Date(submission.createdAt);
      return createdAtDate >= todayStart && createdAtDate <= todayEnd;
    });
    const today_submissions = today_submission.length;

    res.respond(
      {
        active_demands_count,
        total_demands,
        submissions_details,
        today_submissions,
        team_submission,
        totel_submission,
      },
      200,
      "Aggregate Data fetched sucessfully"
    );
  },
};

const getHierarchyDemandData = {
  controller: async (req, res) => {
    try {
      let start_date = req.query.start_date;
      let end_date = req.query.end_date;
      const current_user_id = req.query.user_id;
      // Retrieve demands created by the current user
      let demand_data = await demand_services.listUserCreatedDemands(current_user_id, start_date, end_date);
      const active_demand = demand_data.filter((demand) => demand.status === "Open");
      // Pipeline to aggregate demand data for the current user and their subordinates
      const pipeline1 = [
        { $match: { _id: mongoose.Types.ObjectId(current_user_id), is_deleted: false } },
        {
          $graphLookup: {
            from: "employees",
            startWith: "$_id",
            connectFromField: "_id",
            connectToField: "reports_to",
            as: "subordinates",
            maxDepth: 10,
            restrictSearchWithMatch: { is_deleted: false },
          },
        },
        {
          $lookup: {
            from: "demands",
            let: { subordinateIds: "$subordinates._id" },
            pipeline: [
              {
                $match: {
                  $expr: {
                    $and: [
                      { $in: ["$created_by", "$$subordinateIds"] },
                      { $eq: ["$status", "Open"] },
                      { $eq: ["$is_deleted", false] },
                    ],
                  },
                },
              },
              {
                $group: {
                  _id: null,
                  count: { $sum: 1 },
                },
              },
            ],
            as: "subordinate_demands",
          },
        },
        {
          $unwind: {
            path: "$subordinate_demands",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $addFields: {
            total_demands: {
              $sum: {
                $cond: [
                  { $eq: ["$status", "Open"] },
                  1,
                  {
                    $cond: [{ $eq: ["$subordinate_demands", null] }, 0, "$subordinate_demands.count"],
                  },
                ],
              },
            },
          },
        },
      ];

      // Aggregate demand data for the current user
      const results_currentuser = await fast_connection.models.employee.aggregate(pipeline1);

      if (results_currentuser.length === 0) {
        return res.respond({ error: "No data found for the specified user_id" }, 404);
      }

      // Retrieve current user information
      const current_user = await employee_services.getById(current_user_id);

      // Retrieve subordinates of the current user
      let subordinates = await employee_services.getByReportsto(current_user_id);

      // Fetch demands for each subordinate and aggregate data
      const employeeDemands = await Promise.all(
        subordinates.map(async (employee) => {
          let demandQuery = {
            is_deleted: false,
            created_by: employee._id,
            status: "Open",
          };

          const demands = await fast_connection.models.demand
            .find(demandQuery)
            .select(["_id", "first_name", "last_name", "role"]);

          const pipeline = [
            { $match: { _id: mongoose.Types.ObjectId(employee._id), is_deleted: false } },
            {
              $graphLookup: {
                from: "employees",
                startWith: "$_id",
                connectFromField: "_id",
                connectToField: "reports_to",
                as: "subordinates",
                maxDepth: 10,
                restrictSearchWithMatch: { is_deleted: false },
              },
            },
            {
              $facet: {
                demand_results: [
                  {
                    $lookup: {
                      from: "demands",
                      let: { subordinateIds: "$subordinates._id" },
                      pipeline: [
                        {
                          $match: {
                            $expr: {
                              $and: [{ $in: ["$created_by", "$$subordinateIds"] }, { $eq: ["$is_deleted", false] }],
                            },
                          },
                        },
                      ],
                      as: "subordinate_demand",
                    },
                  },
                  { $unwind: { path: "$subordinate_demand", preserveNullAndEmptyArrays: true } },
                  {
                    $group: {
                      _id: "$_id",
                      subordinates: { $first: "$subordinates" },
                      subordinate_demand: { $push: "$subordinate_demand" },
                    },
                  },
                ],
              },
            },
          ];

          const results = await fast_connection.models.employee.aggregate(pipeline);
          const demand_results = results[0].demand_results;
          const sub_demand = demand_results[0].subordinate_demand;

          const currentUserCount = demands.length;

          let subUserCount = sub_demand.filter((i) => i.status === "Open").length;
          let total_demands = currentUserCount + subUserCount;

          return { employee, currentUserCount, subUserCount, total_demands };
        })
      );

      // Calculate total demands
      const total_demands =
        active_demand.length +
        results_currentuser.reduce((total, results_currentuser) => total + results_currentuser.total_demands, 0);

      // Send response
      res.respond({ employeeDemands, total_demands, current_user }, 200, "Hierarchy Demand Data fetched successfully");
    } catch (error) {
      console.error("Error in getHierarchyDemandData controller:", error);
      res.respond({ error: "Internal Server Error" }, 500);
    }
  },
};

const getHierarchySubmissionData = {
  controller: async (req, res) => {
    let start_date = req.query.start_date;
    let end_date = req.query.end_date;
    let submissions_data = await submission_tracker_services.getSubmissionTrackersCreatedByUser(
      req.query.user_id,
      start_date,
      end_date
    );
    let subbordinates = await employee_services.getByReportsto(req.query.user_id);
    let current_user = await employee_services.getById(req.query.user_id);
    let total_submissions = submissions_data.length;
    res.respond(
      { total_submissions, subbordinates, current_user },
      200,
      "Hierarchy Submission Data fetched sucessfully"
    );
  },
};

const SubmissionHierarchy = {
  controller: async (req, res) => {
    try {
      const role = req.query.role;
      const timeRange = req.query.timeRange;

      let AdminData = [];
      let AMData = [];
      let TLData = [];
      let RecData = [];

      switch (role) {
        case "admin":
          AdminData = await aggregate_servies.get_Admin_WithSubmissions(timeRange);
          res.status(200).json(AdminData);

          break;
        case "account_manager":
          AMData = await aggregate_servies.get_AM_WithSubmissions(timeRange);
          res.status(200).json(AMData);
          break;
        case "team_lead":
          TLData = await aggregate_servies.get_TL_WithSubmissions(timeRange);
          res.status(200).json(TLData);
          break;
        case "recruiter":
          RecData = await aggregate_servies.getRecruitersWithSubmissions(timeRange);
          res.status(200).json(RecData);
          break;
        default:
          [AMData, TLData, RecData] = await Promise.all([
            aggregate_servies.get_AM_WithSubmissions(timeRange),
            aggregate_servies.get_TL_WithSubmissions(timeRange),
            aggregate_servies.getRecruitersWithSubmissions(timeRange),
          ]);
          res.status(200).json(AMData, TLData, RecData);
      }
    } catch (error) {
      console.error("Error occurred while generating Excel:", error);
      res.status(500).send({ error: "An error occurred while generating Excel file." });
    }
  },
};

const getIndividualHierarchy = {
  controller: async (req, res) => {
    try {
      const user_id = req.query.user_id;
      const timeRange = req.query.timeRange;

      let getEmployee = await aggregate_servies.getIndividualHierarchy(timeRange, user_id);

      res.status(200).json({
        data: getEmployee,
        message: "All Employees fetched successfully",
      });
    } catch (error) {
      console.error("Error occurred while generating Excel:", error);
      res.status(500).send({ error: "An error occurred while generating Excel file." });
    }
  },
};

const getHierarchyInterviewData = {
  controller: async (req, res) => {
    let start_date = req.query.start_date;
    let end_date = req.query.end_date;
    let submissions_data = await submission_tracker_services.getSubmissionTrackersCreatedByUser(
      req.query.user_id,
      start_date,
      end_date
    );
    let interview_arr = ["initial_screening", "level_1", "level_2", "level_3"];
    let interview_details = submissions_data
      .filter((i) => interview_arr.includes(i.status))
      .reduce(
        (acc, curr) => {
          if (curr.status == "level_1") {
            acc.l1++;
          } else if (curr.status == "level_2") {
            acc.l2++;
          } else if (curr.status == "level_3") {
            acc.l3++;
          }
          acc.interview++;
          return acc;
        },
        { interview: 0, l1: 0, l2: 0, l3: 0 }
      );
    res.respond({ interview_details }, 200, "Hierarchy Interview Data fetched sucessfully");
  },
};

const listUserLevelDemands = {
  controller: async (req, res) => {
    let start_date = req.query.start_date;
    let end_date = req.query.end_date;
    let demands = await demand_services.listUserCreatedDemands(req.query.user_id, start_date, end_date);
    res.respond(demands, 200, "Demands fetched sucessfully");
  },
};

const listUserLevelActiveDemands = {
  controller: async (req, res) => {
    let start_date = req.query.start_date;
    let end_date = req.query.end_date;
    let demands = await demand_services.listUserCreatedActiveDemands(req.query.user_id, start_date, end_date);
    res.respond(demands, 200, "Demands fetched sucessfully");
  },
};

const listUserLevelSubmissions = {
  controller: async (req, res) => {
    let start_date = req.query.start_date;
    let end_date = req.query.end_date;
    let submissions = await submission_services.listUserCreatedSubmissions(req.query.user_id, start_date, end_date);
    res.respond(submissions, 200, "Submissionss fetched sucessfully");
  },
};

module.exports = {
  getDashboardAggregateData,
  getHierarchyDemandData,
  getHierarchySubmissionData,
  getHierarchyInterviewData,
  listUserLevelDemands,
  listUserLevelActiveDemands,
  listUserLevelSubmissions,
  SubmissionHierarchy,
  getIndividualHierarchy,
};
