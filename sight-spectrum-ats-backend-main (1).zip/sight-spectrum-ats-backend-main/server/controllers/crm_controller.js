const crm_services = require("../services/crm_services");
const crypto = require('crypto')
const { ISOdateToCustomDate } = require('../utils/ISO_date_helper')
const Excel = require('exceljs')
const fs = require('fs')
const employee_service = require('../services/employee_services')

const generatePipelineId = async () => {
  const opportunity = await crm_services.getOpportunityId();
  if (!opportunity) {
    return `SSO0001`;
  }
  const lastOpportunityId = opportunity.Opportunity_id;
  opportunityCounter = parseInt(lastOpportunityId.substr(3)) + 1;
  const paddedCounter = opportunityCounter.toString().padStart(4, "0");
  return `SSO${paddedCounter}`;
}

const createOpportunity = {
  controller: async (req, res) => {
    let new_obj = { ...req.body };
    new_obj["Opportunity_id"] = await generatePipelineId()
    new_obj["created_by"] = req.auth.user_id
    new_obj["updated_by"] = req.auth.user_id
    await crm_services.addNew(new_obj);
    res.respond("Opportunity created sucessfully", 200, 'Opportunity created sucessfully');
  }
};


const getOpportunityDetails = {
  controller: async (req, res) => {
    let client = await crm_services.getOpportunityDetails(req.query);
    res.respond(client, 200, 'Opportunity fetched sucessfully');
  }
};

const getclientDetails = {
  controller: async (req, res) => {
    let employees = await crm_services.getclientDetails();
    res.respond(employees, 200, "Employees fetched sucessfully");
  },
};

const getOpportunityById = {
  controller: async (req, res) => {
    const { _id } = req.params;
    let databyid = await crm_services.getClientById(_id);
    res.respond(databyid, 200, 'client fetched successfully');

  }
}

const updateClientData = {
  controller: async (req, res) => {
    const { _id } = req.params;
    const newData = req.body;
    let updatedata = await crm_services.updateData(_id, newData, { new: true });
    res.respond(updatedata, 200, 'client updated Succesfully')

  }
}
const updateStatus = {
  controller: async (req, res) => {

    const { _id } = req.params;
    const newData = req.body;
    console.log('ID:', _id);
    console.log('New Data:', newData);
    let updatedata = await crm_services.updateData(_id,
      newData,
      { new: true });
    res.respond(updatedata, 200, 'client updated Succesfully')

  }
}

const deleteClientData = {
  controller: async (req, res) => {
    const { _id } = req.params;
    await crm_services.deleteData(_id);
    res.respond("Demand deleted successfully", 200, 'Demand deleted successfully.');
  },
};

const searchClients = {
  controller: async (req, res) => {
    let clients = await crm_services.searchClient(req.query.field_name, req.query.field_value)
    res.respond(clients, 200, 'clients fetched sucessfully');
  }
}

const downloadClient = {
  controller: async (req, res) => {
    let random_prefix = crypto.randomBytes(20).toString('hex')
    let client = await crm_services.getOpportunityDetails(req.query)


    let excel_client = client.map(e => {
      let transformed = {
        Opportunity_id: e?.Opportunity_id,
        request_client: e?.request_client.company_name + "-" + e?.request_client.ClientId,
        name: e?.name,
        request_type: e?.request_type,
        customer_name: e?.customer_name,
        start_date: ISOdateToCustomDate(e?.start_date),
        close_date: ISOdateToCustomDate(e?.close_date),
        ss_businness_unit: e?.ss_businness_unit,
        opportunity_value: e?.opportunity_value,
        level: e?.level,
        status: e?.status,
        timestamp: ISOdateToCustomDate(e?.updatedAt)
      }
      return transformed
    })
    let workbook = new Excel.Workbook();
    let worksheet = workbook.addWorksheet("client_list");

    worksheet.columns = [
      { header: 'Opportunity_id', key: 'Opportunity_id', width: 15 },
      { header: 'request_client', key: 'request_client', width: 20 },
      { header: 'title', key: 'name', width: 15 },
      { header: 'request_type', key: 'request_type', width: 15 },
      { header: 'customer_name', key: 'customer_name', width: 15 },
      { header: 'start_date', key: 'start_date', width: 15 },
      { header: 'close_date', key: 'close_date', width: 15 },
      { header: 'ss_businness_unit', key: 'ss_businness_unit', width: 20 },
      { header: 'level', key: 'level', width: 10 },
      { header: 'status', key: 'status', width: 15 },
    ]
    worksheet.getRow(1).eachCell((cell) => {
      cell.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFCCFFCC' }, // Light green background color
      };
      cell.font = {
        bold: true,
      };
      cell.alignment = {
        vertical: 'middle',
        horizontal: 'center',
      };
    });
    worksheet.columns.forEach((column) => {
      column.width = 20; // Set the width to 20
      column.alignment = { vertical: 'middle', horizontal: 'center' }; // Align center
    });
    worksheet.addRows(excel_client);
    await workbook.xlsx
      .writeFile(`./${random_prefix}_list.xlsx`)
      .then(function () {
        res.download(`./${random_prefix}_list.xlsx`, 'list.xlsx', function (err) {
          if (err) {
            console.log(err)
          } else {
            fs.unlink(`./${random_prefix}_list.xlsx`, function () {
              console.log(`${random_prefix}_list.xlsx file deleted`)
            });
          }
        })
      });
  }
}


const getAdminSales = {
  controller: async (req, res) => {
    let adminSales = await employee_service.adminSearch();
    const formattedEmployees = adminSales.map(employee => ({
      key: employee._id.toString(),
      text: `${employee.first_name} ${employee.last_name}`
    }));
    res.respond(formattedEmployees, 200, 'client fetched successfully');

  }
}
const uploadFile = {
  controller: async (req, res) => {
    const fileLink = req.file.location;
    console.log({ document: fileLink }, "titus");
    const fileExtension = path.extname(fileLink).toLowerCase();
    const documentExtensions = ['.doc', '.docx', '.txt', '.rtf', '.document'];
    const pdfExtensions = ['.pdf'];
    let fileType = 'unknown';
    let text = '';

    if (documentExtensions.includes(fileExtension)) {
      fileType = 'document';
      try {
        const dataBuffer = await fetchData(fileLink);
        if (fileExtension === '.docx') {
          text = await extractTextFromDocx(dataBuffer);
        } else if (['.doc', '.document', '.msword'].includes(fileExtension)) {
          const docxBuffer = await convertToDocx(dataBuffer);
          text = await extractTextFromDocx(docxBuffer);
          console.log('Parsed document text:');
          console.log(text);
        }
      } catch (error) {
        console.error('Error parsing document:', error);
      }
    } else if (pdfExtensions.includes(fileExtension)) {
      fileType = 'pdf';
      try {
        const dataBuffer = await fetchData(fileLink);
        text = await extractTextFromPDF(dataBuffer);
        console.log('Parsed PDF text:');
        console.log(text);
      } catch (error) {
        console.error('Error parsing PDF:', error);
      }
    }

    res.respond({ document: fileLink, fileType, resume_text: text }, 200, 'Document uploaded successfully');
  },
};

const addCrmDocuments = {
  controller: async (req, res) => {
    let documents_arr = []
    req.files.map(i => {
      let document_obj = {}
      document_obj["document_name"] = i.originalname
      document_obj["document"] = i.location
      documents_arr.push(document_obj)
    })
    res.respond({ documents: documents_arr }, 200, 'Documents uploaded sucessfully');
  }
}


module.exports = {
  createOpportunity,
  getOpportunityDetails,
  getclientDetails,
  getOpportunityById,
  getAdminSales,
  addCrmDocuments,
  updateClientData,
  deleteClientData,
  searchClients,
  downloadClient,
  updateStatus,
  uploadFile,

};