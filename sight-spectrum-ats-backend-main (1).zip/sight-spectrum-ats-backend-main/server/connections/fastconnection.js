const fast_connection = require("./fast")("sight_spectrum_master_db");

module.exports = fast_connection
