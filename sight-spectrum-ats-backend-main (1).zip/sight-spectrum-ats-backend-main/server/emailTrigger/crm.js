const fast_connection = require("../connections/fastconnection");
const cron = require('node-cron');
const Excel = require('exceljs')
const { ISOdateToCustomDate } = require('../utils/ISO_date_helper')
var AWS = require("aws-sdk");
const moment=require('moment')



//s3 Creadentials
s3 = new AWS.S3({
  aws_access_key_id: 'YOUR_ACCESS_KEY_ID',
  aws_secret_access_key: 'YOUR_SECRET_ACCESS_KEY',
  region: 'ap-south-1'
});

//Monday to Sunday Date Formate

 function getThisMondayAndSunday() {
  const today = new Date();
  const currentDayOfWeek = today.getDay(); 
  // Calculate days until this Monday 
  const daysUntilThisMonday = (1 - currentDayOfWeek + 7) % 7;
  const thisMonday = new Date(today.getTime() - currentDayOfWeek * 24 * 60 * 60 * 1000); 

  // Calculate days until this Sunday
  const daysUntilThisSunday = (7 - currentDayOfWeek) % 7;
  const thisSunday = new Date(today.getTime() + daysUntilThisSunday * 24 * 60 * 60 * 1000);

  const formatDate = (date) => {
    const day = date.getDate().toString().padStart(2, '0');
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const year = date.getFullYear();
    return { 'slashFormat': `${day}/${month}/${year}`, 'dashFormat': `${day}-${month}-${year}` };
  };

  return {
    thisMonday: formatDate(thisMonday),
    thisSunday: formatDate(thisSunday)
  };
}

const { thisMonday, thisSunday } = getThisMondayAndSunday();



//Weekly  based  crm data fetch from every monday to nextMonday 

const OpportunityWeekStatus = async () => {

    let client = await fast_connection.models.salespipelinesheet.find().populate([{ path: 'request_client', select: '_id ClientId company_name' },{ path: 'assign_to', select: '_id first_name last_name' }]);

    client = client.filter(e => !['Lost', 'N/A', 'Drop'].includes(e.status));
    const startOfCurrentWeek = moment().startOf('isoWeek').day('Monday').hour(9);
    const endOfCurrentWeek = moment().endOf('isoWeek').day('Sunday').hour(12);

    const filteredClient = client.filter(e => moment(e.createdAt).isBetween(startOfCurrentWeek, endOfCurrentWeek));
    let excel_client = filteredClient.map(e => {
        let transformed = {
            Opportunity_id: e?.Opportunity_id,
            request_client: e?.request_client.company_name,
            name: e?.name,
            request_type: e?.request_type,
            customer_name: e?.customer_name,
            email_id: e?.email_id,
            mobile_number: e?.mobile_number,
            assign_to: e?.assign_to.first_name + " " + e?.assign_to.last_name,
            ss_businness_unit: e?.ss_businness_unit,
            start_date: ISOdateToCustomDate(e?.start_date),
            close_date: ISOdateToCustomDate(e?.close_date),
            level: e?.level,
            status: e?.status,
            timestamp: ISOdateToCustomDate(e?.updatedAt)
        };
        return transformed;
    });
    let workbook = new Excel.Workbook();
    let worksheet = workbook.addWorksheet("client_list");

    worksheet.columns = [
        { header: 'Opportunity ID', key: 'Opportunity_id', width: 15 },
        { header: 'Requested Client', key: 'request_client', width: 20 },
        { header: 'Title', key: 'name', width: 15 },
        { header: 'Request Type', key: 'request_type', width: 15 },
        { header: 'Customer Name', key: 'customer_name', width: 15 },
        { header: 'Email ID', key: 'email_id', width: 15 },
        { header: 'Mobile', key: 'mobile_number', width: 15 },
        { header: 'Assigned to', key: 'assign_to', width: 15 },
        { header: 'SS Business Unit', key: 'ss_businness_unit', width: 20 },
        { header: 'Start Date', key: 'start_date', width: 15 },
        { header: 'Close Date', key: 'close_date', width: 15 },
        { header: 'Level', key: 'level', width: 10 },
        { header: 'Status', key: 'status', width: 15 },
    ];
    worksheet.getRow(1).eachCell((cell) => {
        cell.fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: 'FFCCFFCC' }, // Light green background color
        };
        cell.font = {
            bold: true,
        };
        cell.alignment = {
            vertical: 'middle',
            horizontal: 'center',
        };
    });
    worksheet.columns.forEach((column) => {
        column.width = 20; // Set the width to 20
        column.alignment = { vertical: 'middle', horizontal: 'center' }; // Align center
    });
    worksheet.addRows(excel_client);
    // await workbook.xlsx.writeFile(`./${random_prefix}_list.xlsx`);
    const folderName=" Opportunity Update Tracker";
    const formattedDate = `Opportunity Update Tracker: Week of${thisMonday.dashFormat} to ${thisSunday.dashFormat}`;
    const filePath = `${formattedDate}.xlsx`;
    workbook.xlsx.writeBuffer(filePath).then((buffer) => {
      
      //Create parameters for the S3 upload
        upload_file_s3bucket(folderName,filePath,buffer)
    });
};


//Upload file to s3 Bucket
const upload_file_s3bucket=(folderName,filePath,buffer)=>{

  const params = {
    Bucket: "opportunitytracker",
    Key: `${folderName}/${filePath}`,
    Body: buffer,
  };

s3.upload(params,async (err, data) => {
    if (err) {
      console.error("Error uploading file to S3:", err);
   } else {
    sendEmailTask(data.Location)
   }})
}


// Welcome email
const welcomeMailFormat = (username) => {
 let mail = `Dear ${username},
   `
    return mail;
  };

//getAdmin overall admin details
 const adminOnly= async()=> {
  try {
    const roles = ["superadmin",'admin'];
    return await fast_connection.models.employee.find({ role: { $in: roles }}).select('first_name last_name email ');
     } catch (error) {
    throw error;
  }
}

const EmailParams = (recipient, subject, html, attachmentLink) => {
    const params = {
    Destination: {
      ToAddresses: [recipient]
    },
    Message: {
      Body: {
        Html: {
          Charset: "UTF-8",
          Data: html
        }
      },
      Subject: {
        Charset: 'UTF-8',
        Data: subject
      }
    },
    Source: 'donotreply@sightspectrum.com',

  };

  params.Message.Body.Html.Data += `<p>Please check the enclosed record on Opportunities for this week of ${thisMonday.slashFormat} to ${thisSunday.slashFormat}.</p>
    <p style="font-size: 14px;">Attachment: <a href="${attachmentLink}" style="color: blue;">Opportunity Update Tracker</a></p>` +
    `<div style="font-size: 12px; margin-top: 10px;">` +
    ` <b>Note: This email is auto-generated. Please do not reply.</b>`;
  return params;
};



// Helper function to send an email using SES
const sendEmail = (recipient, subject, html, attachmentLink) => {

  let params = EmailParams(recipient, subject, html, attachmentLink);
  const sendPromise = new AWS.SES({ apiVersion: '2010-12-01' }).sendEmail(params).promise();

  return new Promise((resolve, reject) => {
    sendPromise.then(
      function (data) {
        resolve(data.Location)
      }).catch(
      function (err) {
        reject(err)
        console.error(err, err.stack);
      });
  })
}


const sendEmailTask = (link) => {
  adminOnly().then((data) => {
    data.map(userInfo=>{
        let email=userInfo.email
        let adminFullName=`${userInfo.first_name} ${ userInfo.last_name}`
     sendEmail(email, `Opportunity Update Tracker: Week of ${thisMonday.slashFormat} - ${thisSunday.slashFormat}`, welcomeMailFormat(adminFullName),link);

    })
   
   }).catch((error) => {
     console.error('Error fetching admin data:', error);
   });
    console.log("Sending email...");
};


// sendEmail 
cron.schedule('00 9 * * 1', () => {
   OpportunityWeekStatus().then((filePath) => {
    console.log('File path');
  
  }).catch((err) => {
    console.error(err);
  });
}, {
  scheduled: true,
  timezone: "Asia/Kolkata" // Set your timezone here
});