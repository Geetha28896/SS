const mongoose = require("mongoose");
const Schema = mongoose.Schema

const interview_schema = new Schema({
    MeetID: { type: String, unique: true },
    demand_id: { type: String },
    candidate_id: { type: String },
    submission_id: { type: String },
    candidateObjID: { type: String },
    demandObjID: { type: String },
    mobile_no: { type: String },
    candidate_email: { type: String },
    candidate_name: { type: String },
    interviewer_email: [{ type: Object }],
    company_name: { type: String },
    startDateTime: { type: String },
    duration: { type: String },
    status: { type: String },
    title: { type: String },
    schedule_meet_id: { type: String },
    passcode: { type: String },
    meet_url: { type: String },
    event_id: { type: String },
    scheduled_by: { type: String },
    is_deleted: { type: Boolean, default: false },
    created_by: { type: Schema.Types.ObjectId, ref: 'employee' },
    updated_by: { type: Schema.Types.ObjectId, ref: 'employee' }

},
    {
        timestamps: true
    });

module.exports = interview_schema