import React, { useState, useEffect, useRef } from 'react'
import styles from './AddPipelineModal.module.css'
import { TextField, PrimaryButton, DatePicker, Label, DefaultButton, Icon, FontIcon } from '@fluentui/react';
import { Dropdown } from '@fluentui/react/lib/Dropdown';
import Editicon from "../assets/editnote.png"
import { mergeStyles } from '@fluentui/react';
import { Editor } from 'react-draft-wysiwyg';
import { ContentState, EditorState, convertToRaw } from "draft-js";
import boldicon from "../../src/assets/boldicon.svg";
import undoicon from "../../src/assets/undoicon.svg";
import redoicon from "../../src/assets/redoicon.svg";
import { useLocation, useNavigate } from 'react-router-dom';
import draftToHtml from 'draftjs-to-html';
import htmlToDraft from 'html-to-draftjs';
import { axiosPrivateCall } from "../constants";
import { isEmpty, isNumOnly } from '../utils/validation';
import { UploadPopup } from '../components/UploadModal';

// regex
const vendorRegex = /^[a-zA-Z0-9 @,.()-]*$/;
const nameInputRegex = /^[a-zA-Z\u00c0-\u024f\u1e00-\u1eff ]*$/;

const dropDownStylesActive = (props, currentHover, error, value) => {
    return {
        dropdown: {
            width: "135px",
            minWidth: "120px",
            minHeight: "20px",
            selectors: {
                ":focus": {
                    borderColor: "rgb(96, 94, 92)",
                },
            },
        },
        title: {
            height: "22px",
            lineHeight: "18px",
            fontSize: "12px",
            //     borderColor: error
            //         ? "#a80000"
            //         : currentHover === value
            //             ? "rgb(96, 94, 92)"
            //             : "transparent",
        },

        caretDownWrapper: { height: "22px", lineHeight: "20px !important" },
        dropdownItem: { minHeight: "20px", fontSize: 12 },
        dropdownItemSelected: { minHeight: "22px", fontSize: 12 },
    };
};
const dropDownStylesAddActive = (props, currentHover, error, value) => {
    return {
        dropdown: {
            width: "135px",
            minWidth: "120px",
            minHeight: "20px",
            backgroundColor: '#EDF2F6'
        }
    };
};

const tableCloseIconClass = mergeStyles({
    fontSize: 10,
    height: "12px",
    width: "12px",
    cursor: "pointer",
    color: "red",
});
const calendarClass = (props, currentHover, error, value) => {
    return {
        root: {

            "*": {
                width: "135px",
                fontSize: "12px !important",
                height: "22px !important",
                lineHeight: "20px !important",
                backgroundColor:'transparent'
            },
        },

        icon: { height: 10, width: 10, left: "85%", padding: "0px 0px" },
    };
};

const textViewFieldColored = (props, currentHover, error, value) => {
    return {
        fieldGroup: {
            display: 'flex',
            width: "135px",
            height: "22px",
            backgroundColor: "transparent",
            color: 'rgba(102, 102, 102, 1) ',
            borderColor: "#edf2f6",
            selectors: {
                ":focus": {
                    // borderColor: "rgb(96, 94, 92)",
                },
            },
        },
        field: {
            fontSize: 12,
        },
        root: {
            marginLeft: '10px', 
          },
    };
};
const textFieldColored = (props, currentHover, error, value) => {
    return {
        fieldGroup: {
            display: 'flex',
            width: "135px",
            height: "22px",
            backgroundColor: "#FFFFFF",
            color: 'rgba(102, 102, 102, 1) ',
            borderColor: "transparent",
            selectors: {
                ":focus": {
                    borderColor: "rgb(96, 94, 92)",
                },
            },
        },
        field: {
            fontSize: 12,
        },
        root: {
            marginLeft: '10px', 
          },
    };
};

const dealNameOptions = [
    { key: "Staffing", text: "Staffing" },
    { key: "Projects", text: "Projects" },
    { key: "Others", text: "Others" },    
    { key: "Consulting & Delivery", text: "Consulting & Delivery" },
    { key: "Training Deployment", text: "Training Deployment" },

]
const shortStatusOptions = [
    { key: "Prospect", text: "Prospect" },
    { key: "Lead", text: "Lead" },
    { key: "Presales", text: "Presales" },
    { key: "Sales", text: "Sales" },
    { key: "Closure", text: "Closure" },
    { key: "Negotiate", text: "Negotiate" },
    { key: "Won", text: "Won" },
    { key: "Lost", text: "Lost" },
    { key: "Hold", text: "Hold" },
    { key: "In Progress", text: "In Progress" },
    { key: "Drop", text: "Drop" },
    { key: "N/A", text: "N/A" }

]

const businessUnitOptions = [
    { key: "India Staffing", text: "India Staffing" },
    { key: "US Staffing", text: "US Staffing" },
    { key: "UAE Staffing", text: "UAE Staffing" },
    { key: "Training", text: "Training" },
    { key: "Consulting & Products", text: "Consulting & Products" },
]
const currencyOptions = [
    { key: "INR", text: "INR" },
    { key: "USD", text: "USD" },
    { key: "Diram", text: "Diram" },
    { key: "Riyal", text: "Riyal" },
    { key: "Ringitt", text: "Ringitt" },
    { key: "EURO", text: "EURO" },
    { key: "Pound", text: "Pound" },
    { key: "Rand", text: "Rand" },
    { key: "CAD", text: "CAD" },
    { key: "Swiss Franc", text: "Swiss Franc" },
    { key: "Riel", text: "Riel" },


]

const requestOption =[
    {key:"Client Request",text:"Client Request"},
    {key:"Contract",text:"Contract"},
    {key:"Presentation",text:"Presentation"},
    {key:"RFP",text:"RFP"}
]

const departmentOptions =  [
    { key: "Data", text: "Data" },
    { key: "Digital", text: "Digital" },
    { key: "Recruitment", text: "Recruitment" },

]

const confidenceOptions = [
    { key: "10", text: "10" },
    { key: "20", text: "20" },
    { key: "30", text: "30" },
    { key: "40", text: "40" },
    { key: "50", text: "50" },
    { key: "60", text: "60" },
    { key: "70", text: "70" },
    { key: "80", text: "80" },
    { key: "90", text: "90" },
    { key: "100", text: "100" },

]

const ViewPipeLine = () => {
    const navigate = useNavigate()
    const client_location = useLocation()
    const getclientData = client_location.state;
    const [validationErrors, setValidationErrors] = useState({});
    const [showTextField, setShowTextField] = useState(false);
    const [otherValue1, setOtherValue1] = useState('');
    const [firstLoad, setFirstLoad] = useState(false);

    const [errorMsg, setErrorMsg] = useState('');
    const [showUploadPopup, setShowUploadPopup] = useState(false);
    const [clientData, setClientData] = useState({
        client_id: '',
        Deal_name: '',
        textField: '',
        request_type: '',
        customer_name: '',
        status: '',
        closure_date: '',
        entry_date: '',
        owner: '',
        reports_to: '',
        industry: '',
        business_Unit: '',
        currency: '',
        values: '',
        confidence: '',
        delivery_poc: '',
        lead_Reference: '',
        next_action_date: '',
        lead_Reference: '',
        opportunity_description: '',
        addtional_remarks: '',
        documents: [],

    })
    const [editorState, setEditorState] = useState(() =>
        EditorState.createEmpty()
    );

    const [editorState2, setEditorState2] = useState(() =>
        EditorState.createEmpty()
    );

    const [basicInfoerrors, setBasicInfoErrors] = useState({

    });

    const handleUCClick = () => {
        navigate('/reports/recruitersubmission');
      };

    let minDate = new Date();
    let close_date = new Date(clientData.entry_date)

    const editorToolbarOptions = {
        options: ["inline", "list", "link", "history"],
        inline: {
            bold: { icon: boldicon, className: undefined },
            options: ["bold", "italic", "underline"],
        },
        list: {
            options: ["unordered", "ordered"],
        },
        link: {
            options: ["link"],
        },
        history: {
            options: ["undo", "redo"],
            undo: { icon: undoicon },
            redo: { icon: redoicon },
        },

    };

    useEffect(() => {
        if (getclientData) {
            getData()
        }
    }, [getclientData]);


    useEffect(() => {
        setClientData((prevData) => {
            return {
                ...prevData,
                opportunity_description: draftToHtml(
                    convertToRaw(editorState.getCurrentContent())
                ),
                addtional_remarks: draftToHtml(
                    convertToRaw(editorState2.getCurrentContent())
                ),
            };
        });
    }, [editorState, editorState2]);

    useEffect(() => {
        if (firstLoad) {
            const jobHTML = clientData.opportunity_description;
            const additionalHTML = clientData.addtional_remarks;
            const contentBlock = htmlToDraft(jobHTML);
            const contentBlock2 = htmlToDraft(additionalHTML);
            const contentState = ContentState.createFromBlockArray(
                contentBlock.contentBlocks
            );
            const editorState = EditorState.createWithContent(contentState);
            const contentState2 = ContentState.createFromBlockArray(
                contentBlock2.contentBlocks
            );
            const editorState2 = EditorState.createWithContent(contentState2);
            setEditorState(EditorState.createWithContent(contentState));
            setEditorState2(EditorState.createWithContent(contentState2));
            setFirstLoad(false);
        }
    }, [firstLoad]);


    const getData = async () => {
        try {
            const response = await axiosPrivateCall.get(`/api/v1/crm/getclientbyid/${getclientData._id}`)
            console.log(response.data)
            setClientData(response.data)
            setFirstLoad(true);
        }
        catch (error) {
            console.log("data not found");
        }
    }


    const closeIconClass = mergeStyles({
  fontSize: 16,
  height: "20px",
  width: "20px",
  cursor: "pointer",
//   paddingBottom: 6
});

    const isValidInput = (value) => {
        const allowedCharactersRegex = /^[A-Za-z0-9áéíóúüñÁÉÍÓÚÜÑ\s\-\',.\(\)&]*$/;

        if (!allowedCharactersRegex.test(value)) {
          return false;
        }

        if (value.length > 40) {
          return false;
        }

        if (value.trim() !== value) {
          return false;
        }

        if (/\s{2,}/.test(value)) {
          return false;
        }

    }

    return (
        <div>
            <UploadPopup
                showPopup={showUploadPopup}
                setShowPopup={setShowUploadPopup}
                basicInfo={clientData || { documents: [] }}
                setBasicInfo={setClientData}
            />
            <div className={styles.addcandidate_modal_header_container}>
                <div className={styles.header_tag_expand_close_icon_container}>
                    <div className={styles.header_tag_container}>
                        Sales Pipeline Sheet
                    </div>
                      <div><Icon iconName="ChromeClose" className={closeIconClass} onClick={() => {
          navigate(-1);
    }} /></div>
                </div>
                <div className={styles.header_content_container}>
                    <div className={styles.header_content_title_container}>
                        <div className={styles.header_content_title_container}>
                            <div className={styles.add_info_client}>
                                <Label className={styles.label_style_clientId} required> Client ID :</Label>
                                <TextField
                                    value={clientData.client_id}
                                    placeholder='Enter Client ID'
                                  
                                    disabled
                                    style={{backgroundColor:"transparent"}}
                                     styles={textFieldColored}
                                    
                                />
                                <Label className={styles.label_style_dealId} > Opportunity/Request Id : {"   "}{clientData.opportunity_id}</Label>
                            </div>
                        </div>
                    </div>
                       <div className={styles.header_content_save_container}>
              <div className={styles.header_save_close_btns_container}>
                <PrimaryButton
                  onClick={() => navigate(`/managedeals/editpipeline?client_id=${clientData._id}`,{state: clientData})}
                  >
                  <img src={Editicon} alt="image" style={{ marginRight: "5px", width:"16px", height:"16px"}}  />
                  <span style={{ fontSize: "16px", fontWeight:"600", paddingBottom:"3px"  }}>Edit</span>
                </PrimaryButton>

              </div>
            </div>  
                </div>
            </div>

            <div className={styles.add_modal_main_container}>
                <div className={styles.border}></div>
                <div className={styles.modal_main_container}>
                    <div className={styles.sub_container}>
                        <div className={styles.opportunity_type}>
                            <Label className={styles.label_style} required>Opportunity/Request</Label>
                            
                             <TextField
                                value={clientData.Deal_name}
                                placeholder=''
                               
                                  disabled
                                    style={{backgroundColor:"transparent"}}
                                styles={textViewFieldColored}
                                />
                               {showTextField && (
                                     <TextField
                                        styles={textViewFieldColored}
                                        placeholder="Enter the Name"
                                        value={otherValue1}
                                            disabled
                                            style={{backgroundColor:"transparent"}}
                                        
                                        />
                                            )}
                                    </div>
                        <div className={styles.customer_name}>
                                <Label className={styles.label_style} required>Request Type</Label>
                                 <TextField
                                value={clientData.request_type}
                                placeholder=''
                                disabled
                                style={{backgroundColor:"transparent"}}
                                styles={textViewFieldColored} />
                            </div>
                          <div className={styles.customer_name}>
                            <Label className={styles.label_style} required>Customer Name</Label>
                            <TextField
                                value={clientData.customer_name}
                                placeholder='Enter the Name'
                            
                                  disabled
                                    style={{backgroundColor:"transparent"}}
                                styles={textViewFieldColored}
                              />
                        </div>
                       <div className={styles.closure_date}>
                       <Label className={styles.label_style} required>Start Date</Label>
                            <DatePicker
                                 disabled
                                // className={styles.myDatePicker}
                                styles={calendarClass}
                                placeholder="DD/MM/YYYY"
                                // onSelectDate={(date) => dateHandler(date, 'entry_date')}
                                value={clientData.entry_date ? new Date(clientData.entry_date) : null}
                            />
                        </div>
                         <div className={showTextField ?styles.new_entry_date:styles.entry_date}>
                         <Label className={`${styles.label_style} ${styles.close_date_label}`} required> Close Date</Label>
                            <DatePicker
                            disabled
                                minDate={close_date}
                                styles={calendarClass}
                                placeholder="DD/MM/YYYY"
                                // onSelectDate={(date) => dateHandler(date, 'closure_date')}
                                value={clientData.closure_date ? new Date(clientData.closure_date) : null}
                           
                            />
                            
                        </div>

                    <div className={showTextField ?styles.new_short_status:styles.short_status}>
                            <Label className={styles.label_style} required>Status</Label>
                            <TextField
                              disabled
                                placeholder="Select"
                                value={clientData.status}
                                notifyOnReselect
                                style={{backgroundColor:"transparent"}}
                                styles={textViewFieldColored}
                                />
                                    
                        <div className={styles.main_dropdown_container2} onClick={handleUCClick} >
                       <div className={styles.icon}>
                         <Icon iconName="ChangeEntitlements" 
                    /></div>
                  <div className={styles.iconname}>
                   Track Opportunity/Request
                 </div>
                            </div>
                        </div>
                </div>
                </div>
                {/* <div className={styles.main_filter_options_container}>
                </div>
                <br/>
                <div className={styles.border}></div> */}
                <div className={styles.additional_information_container}>
                    <div className={styles.addtional_information_title}>Additional Information</div>
                    <div className={styles.grid_container}>
                        <div className={styles.add_info}>
                            <Label className={styles.add_info_label} required>Owner</Label>
                            <TextField
                                value={clientData.owner}
                                placeholder='Enter the Name'
                                   disabled
                                    style={{backgroundColor:"transparent"}}
                                styles={textFieldColored}
                                 />
                        </div>
                        <div className={styles.add_info}>
                            <Label className={styles.add_info_label_1} required>Reports to</Label>
                            <TextField
                                value={clientData.reports_to}
                                placeholder='Enter the Name'
                                
                                   disabled
                                    style={{backgroundColor:"transparent"}}
                                styles={textFieldColored}
                                 />
                        </div>
                        <div className={styles.add_info}>
                            <Label className={styles.add_info_label_2} required>Industry</Label>
                            <TextField
                                value={clientData.industry}
                                placeholder='Enter the industry'
                                   disabled
                                    style={{backgroundColor:"transparent"}}
                                styles={textFieldColored}
                                 />
                        </div>
                        <div className={styles.add_info}>
                            <Label className={styles.add_info_label_3} required>Business Unit</Label>
                             <TextField
                                 value={clientData.business_Unit}
                                placeholder=''
                                disabled
                                style={{backgroundColor:"transparent"}}
                                styles={textFieldColored} />
                        </div>
                        <div className={styles.add_info}>
                            <Label className={styles.add_info_label_5} required>Currency</Label>
                               <TextField
                                 value={clientData.currency}
                                placeholder=''
                                disabled
                                style={{backgroundColor:"transparent"}}
                                styles={textFieldColored} />
                        </div>
                        <div className={styles.add_info}>
                            <Label className={styles.add_info_label} required >Values</Label>
                            <TextField
                                value={clientData.values}
                                placeholder='Enter the Values'
                                   disabled
                                    style={{backgroundColor:"transparent"}}
                                styles={textFieldColored}
                                
                            />
                        </div>
                        <div className={styles.add_info}>
                            <Label className={styles.add_info_label_6} required>Confidence</Label>
                           
                               <TextField
                                 value={clientData.confidence}
                                placeholder=''
                                disabled
                                style={{backgroundColor:"transparent"}}
                                styles={textFieldColored} />
                       
                        </div>

                        <div className={styles.add_info}>
                            <Label className={styles.add_info_label_8} required>Delivery Lead</Label>
                            <TextField
                                value={clientData.delivery_poc}
                                placeholder='Enter the Name'
                               
                                   disabled
                                    style={{backgroundColor:"transparent"}}
                                styles={textFieldColored}
                               />
                        </div>

                        <div className={styles.add_info}>
                            <Label className={styles.add_info_label_10} >Lead Reference</Label>
                            <TextField
                                value={clientData.lead_Reference}
                                placeholder='Enter the Lead Reference'
                              
                                   disabled
                                    style={{backgroundColor:"transparent"}}
                                styles={textFieldColored}
                            />
                        </div>
                        <div className={styles.add_info}>
                            <Label className={styles.next_action_label} >Next Action Date</Label>
                         
                               <TextField
                                 value={clientData.next_action_date ? new Date(clientData.next_action_date) : null}
                                placeholder=''
                                disabled
                                style={{backgroundColor:"transparent"}}
                                styles={textFieldColored} />
                        </div>
                    </div>
                </div>
                <div className={styles.main_container}>
                    <div className={styles.opportunity_description_container}>
                        <div className={styles.opportunity_description_title}>Opportunity Description</div>
                        <div className={styles.oppurtunity_description}>
                            <Editor
                                wrapperClassName={
                                    styles.editor_wrapper}
                                toolbar={editorToolbarOptions}
                                toolbarOnFocus
                                toolbarClassName={styles.editor_toolbar}
                                editorClassName={
                                    styles.editor_editor}
                                placeholder="Click to opportunity description"
                                editorState={editorState}
                                onEditorStateChange={(editorState) =>
                                    setEditorState(editorState)
                                }
                            />
                        </div>
                    </div>
                    <div className={styles.additional_remarks_container}>
                        <div className={styles.additional_remarks_title}>Additional Remarks</div>
                        <div className={styles.additional_remarks}>
                            <Editor
                                wrapperClassName={styles.editor_wrapper}
                                toolbar={editorToolbarOptions}
                                toolbarOnFocus
                                toolbarClassName={styles.editor_toolbar}
                                editorClassName={styles.editor_editor}
                                placeholder="Click to add Remarks"
                                editorState={editorState2}
                                onEditorStateChange={(editorState2) =>
                                    setEditorState2(editorState2)
                                }
                            />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
export default ViewPipeLine;