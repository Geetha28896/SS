import React, { useState, useEffect, useCallback, useRef } from "react";
import { Label, Modal } from "@fluentui/react";
import styles from "./OpportunityModel.module.css";
import { Icon } from "@fluentui/react/lib/Icon";
import { TextField, PrimaryButton, DefaultButton, DatePicker } from "@fluentui/react";
import { Dropdown } from "@fluentui/react/lib/Dropdown";
import { mergeStyles, mergeStyleSets } from "@fluentui/react";
import Editicon from "../../src/assets/editnote.png"
import { Editor } from "react-draft-wysiwyg";
import boldicon from "../../src/assets/boldicon.svg";
import undoicon from "../../src/assets/undoicon.svg";
import redoicon from "../../src/assets/redoicon.svg";
import { Popup } from "../components/Popup";
// import { useNavigate } from "react-router-dom";
import draftToHtml from "draftjs-to-html";
import { EditorState, convertToRaw } from "draft-js";
import { isEmpty, isNumOnly } from "../utils/validation";
import { axiosPrivateCall } from "../constants";
import { Spinner, SpinnerSize } from "@fluentui/react/lib/Spinner";
import { FontIcon } from "@fluentui/react/lib/Icon";
import { UploadPopup } from "../components/UploadModal";
import uploadImage from "../assets/upload_cloud_image.png";
import { useNavigate, useSearchParams } from "react-router-dom";
// import { ComboBox } from 'office-ui-fabric-react'; // Import ComboBox component


// regex
const vendorRegex = /^[a-zA-Z0-9 @,.()-]*$/;
const nameInputRegex = /^[a-zA-Z\u00c0-\u024f\u1e00-\u1eff ]*$/;

const buttonStyles = {
  root: {
    marginTop: "3px",
    height: "30px",
    borderRadius: "2px",
    marginRight: "8px", // Adjust spacing if needed
  },
};

const DropdownStyles = (props, currentHover, error, value) => {

  const borderColor = "#E1E5E8";
  const hoverBorderColor = "#E1E5E8"; // Same color for hover state
  const focusBorderColor = "yellow"; // Color when focused or value entered
  let titleColor = "#484848"; // Default color when value is not empty
  if (!value) {
    titleColor = "#D7D7D7"; // Change the color to red if value is empty
  }


  return {
    title: {
      height: "29px",
      display: "flex",
      alignItems: "center",
      color: titleColor, // Apply dynamic color based on value
    },
    root: {
      width: "160px", // Adjust the width for the root element
    },

    dropdown: {
      width: "160px", // Adjust the width here
      borderRadius: "4px", // Add border-radius
      selectors: {
        ".ms-Dropdown-title, .ms-Dropdown-caretDownWrapper": {
          borderColor: borderColor,
          borderRadius: "4px", // Add border-radius
          color: titleColor, // Apply dynamic color based on value
        },
        ".ms-Dropdown-title:hover, .ms-Dropdown-caretDownWrapper:hover": {
          borderColor: hoverBorderColor,
        },
        ".ms-Dropdown-title:focus, .ms-Dropdown-title:focus-within": {
          borderColor: focusBorderColor, // Apply focus border color
          borderRadius: "4px",
        },
      },
    },
  };
};

const calendarClass = (value) => {

  return mergeStyleSets({
    root: {
      "*": {
        minWidth: "160px",
        maxWidth: "120px",
        fontSize: "11px",
        height: "29px !important",
        lineHeight: "20px !important",
        borderColor: "#E1E5E8 !important",
        borderRadius: "4px",
        lineHeight: "26px !important",
        // color: "#D7D7D7", // Apply dynamic color based on value
      },
    },
    field: {
      color: "black",
      fontSize: "11px",
      input: {
        color: "black",
        "&::placeholder": {
          color: "#D7D7D7 !important",
        },
      },
    },
    icon: {
      height: "14px !important",
      width: "8px !important",
      left: "80%",
      padding: "0px 0px",
      scale: "90%",
    },
    statusMessage: { marginBottom: "-25px" },
  });
};

const customizedDropdown = (props, currentHover, error, value) => {
const borderColor = error ? "#D24545" : "#E1E5E8";
  const hoverBorderColor = "#E1E5E8"; // Same color for hover state
  const focusBorderColor = "yellow"; // Color when focused or value entered
  let titleColor = "#484848"; // Default color when value is not empty
  if (!value) {
    titleColor = "#D7D7D7"; // Change the color to red if value is empty
  }

  return {
    title: {
      height: "30.5px",
      display: "flex",
      alignItems: "center",
      color: titleColor, // Apply dynamic color based on value
    },
    root: {
      width: "180px", // Adjust the width for the root element
    },
    dropdown: {
      width: "200px", // Adjust the width here
      borderRadius: "4px", // Add border-radius
      selectors: {
        ".ms-Dropdown-title:focus, .ms-Dropdown-title:focus-within": {
          borderColor: focusBorderColor, // Apply focus border color
        },
        ".ms-Dropdown-title, .ms-Dropdown-caretDownWrapper": {
          borderColor: borderColor,
          borderRadius: "4px", // Add border-radius
          color: titleColor, // Apply dynamic color based on value
        },
        ".ms-Dropdown-title:hover, .ms-Dropdown-caretDownWrapper:hover": {
          borderColor: hoverBorderColor,
        },
      },
    },
  };
};


const secondContainerDropdown = (props, currentHover, error, value) => {

  const borderColor = error ? "#D24545" : "#E1E5E8";
  const hoverBorderColor = "#E1E5E8"; // Same color for hover state
  const focusBorderColor = "yellow"; // Color when focused or value entered
  let titleColor = "#484848"; // Default color when value is not empty
  if (!value) {
    titleColor = "#D7D7D7"; // Change the color to red if value is empty
  }

  return {
    title: {
      height: "29px",
      display: "flex",
      alignItems: "center",
      color: titleColor, // Apply dynamic color based on value
    },
    root: {
      width: "190px", // Adjust the width for the root element
    },

    dropdown: {
      width: "305px", // Adjust the width here
      borderRadius: "4px", // Add border-radius
      selectors: {
        ".ms-Dropdown-title, .ms-Dropdown-caretDownWrapper": {
          borderColor: borderColor,
          borderRadius: "4px", // Add border-radius
          color: titleColor, // Apply dynamic color based on value
        },
        ".ms-Dropdown-title:hover, .ms-Dropdown-caretDownWrapper:hover": {
          borderColor: hoverBorderColor,
        },
        ".ms-Dropdown-title:focus, .ms-Dropdown-title:focus-within": {
          borderColor: focusBorderColor, // Apply focus border color
          borderRadius: "4px",
        },
      },
    },
  };
};

// const secondContainerDropdown = (props, currentHover, error, value) => {
//   const borderColor = "#E1E5E8";
//   const hoverBorderColor = "#E1E5E8"; // Same color for hover state
//   const focusBorderColor = "yellow"; // Color when focused or value entered

//   return {
//     title: {
//       height: "30.5px",
//       display: "flex",
//       alignItems: "center",
//     },
//     root: {
//       width: "180px", // Adjust the width for the root element
//     },
//     dropdown: {
//       width: "305px", // Adjust the width here
//       borderRadius: "4px", // Add border-radius
//       selectors: {
//         ".ms-Dropdown-title:focus, .ms-Dropdown-title:focus-within": {
//           borderColor: focusBorderColor, // Apply focus border color
//         },
//       },
//       selectors: {
//         ".ms-Dropdown-title": {
//           borderColor: borderColor,
//           borderRadius: "4px", // Add border-radius
//         },
//         ".ms-Dropdown-title:hover": {
//           borderColor: hoverBorderColor,
//         },
//         ".ms-Dropdown-title:focus": {
//           borderColor: focusBorderColor,
//           borderRadius: "4px",
//         },
//         ".ms-Dropdown-caretDownWrapper": {
//           borderColor: borderColor,
//         },
//         ".ms-Dropdown-caretDownWrapper:hover": {
//           borderColor: hoverBorderColor,
//         },
//       },
//     },
//   };
// };

const contractIconClass = mergeStyles({
  fontSize: 20,
  height: "20px",
  width: "20px",
  cursor: "pointer",
});

const closeIconClass = mergeStyles({
  fontSize: 16,
  height: "20px",
  width: "20px",
  cursor: "pointer",
});

const tableCloseIconClass = mergeStyles({
  fontSize: 10,
  height: "12px",
  width: "12px",
  cursor: "pointer",
  color: "red",
 	marginTop: "3px",
	marginLeft: "8px"
});

const dropDownStylesActive = (props, currentHover, error, value) => {
  return {
    dropdown: {
      width: "135px",
      minWidth: "120px",
      minHeight: "20px",
      selectors: {
        ":focus": {
          borderColor: "rgb(96, 94, 92)",
        },
      },
    },
    title: {
      height: "22px",
      lineHeight: "18px",
      fontSize: "12px",
    },
    caretDownWrapper: { height: "22px", lineHeight: "20px !important" },
    dropdownItem: { minHeight: "20px", fontSize: 12 },
    dropdownItemSelected: { minHeight: "22px", fontSize: 12 },
  };
};

const textFieldColored1 = (props, currentHover, error, value) => {
   const borderColor = error ? "#D24545" : "#E1E5E8";
  const borderRadius = "4px";

  return {
    fieldGroup: {
      display: "flex",
      width: "450px",
      height: "30px",
      marginTop: "2.5px",
      backgroundColor: "#FFFFFF",
      color: "rgba(102, 102, 102, 1)",
      borderColor: borderColor, // Apply border color
      borderRadius: borderRadius, // Apply border radius
      selectors: {
        "&:focus": {
          borderColor: borderColor, // Apply border color
        },
        "&:hover": {
          borderColor: borderColor,
        },
      },
    },
    field: {
      color: "#5B5F62",
      fontSize: 12,
      input: {
        color: "#5B5F62",
        "&::placeholder": {
          color: "#D7D7D7",
        },
      },
    },
    root: {
      marginRight: "30px",
    },
  };
};

const textFieldColored2 = (props, currentHover, error, value) => {
  const borderColor = "#D9DEE5";
  const borderRadius = "4px";

  return {
    fieldGroup: {
      display: "flex",
      width: "160px",
      height: "30px",
      backgroundColor: "#FFFFFF",
      color: "rgba(102, 102, 102, 1)",
      borderColor: borderColor,
      borderRadius: borderRadius,
      selectors: {
        ":focus": {
          borderColor: borderColor,
        },
        ":hover": {
          borderColor: borderColor,
        },
      },
    },
    field: {
      color: "#5B5F62",
      fontSize: 12,
      input: {
        color: "#5B5F62",
        "&::placeholder": {
          color: "#D7D7D7",
        },
      },
    },
  };
};

const textFieldColored = (props, currentHover, error, value) => {
  const borderColor = "#D9DEE5"; // Border color for hover and regular states
  const borderRadius = "4px"; // Border radius

  return {
    fieldGroup: {
      display: "flex",
      width: "200px",
      height: "30px",
      marginTop: "2.5px",
      backgroundColor: "#FFFFFF",
      color: "rgba(102, 102, 102, 1)",
      borderColor: borderColor, // Apply border color
      borderRadius: borderRadius, // Apply border radius
      selectors: {
        ":focus": {
          borderColor: borderColor, // Apply border color
        },
        ":hover": {
          borderColor: borderColor, // Apply border color
        },
      },
    },
    field: {
      color: "#5B5F62",
      fontSize: 12,
      input: {
        color: "#5B5F62",
        "&::placeholder": {
          color: "#D7D7D7",
        },
      },
    },
    root: {
      marginRight: "30px",
    },
  };
};

const regionLocationOption = [
  { key: "North America", text: "North America" },
  { key: "Latin America & the Caribbean", text: "Latin America & the Caribbean" },
  { key: "Middle East & North", text: "Middle East & North" },
  { key: "Africa (MENA)", text: "Africa (MENA)" },
  { key: "SubSaharan Africa", text: "SubSaharan Africa" },
  { key: "Asia-Pacific (APAC)", text: "Asia-Pacific (APAC)" },
  { key: "Central Asia, Eurasia", text: "Central Asia, Eurasia" },
  { key: "East Asia", text: "East Asia" },
  { key: "Southeast Asia", text: "Southeast Asia" },
  { key: "India", text: "India" },
];

const LevelOption = [
  { key: "Prospect", text: "Prospect" },
  { key: "Lead", text: "Lead" },
  { key: "Presales", text: "Presales" },
  { key: "Sales", text: "Sales" },
  { key: "Closure", text: "Closure" },
  { key: "Negotiate", text: "Negotiate" },
];

const statusOption = [
  { key: "Won", text: "Won" },
  { key: "Lost", text: "Lost" },
  { key: "Hold", text: "Hold" },
  { key: "In Progress", text: "In Progress" },
  { key: "Drop", text: "Drop" },
  { key: "N/A", text: "N/A" },
];

const requesttypeOption = [
  { key: "Client Request", text: "Client Request" },
  { key: "Contract", text: "Contract" },
  { key: "Presentation", text: "Presentation" },
  { key: "RFP", text: "RFP" },
  { key: "POC", text: "POC" },
];

const SSBuisnessUnitOption = [
  { key: "India Staffing", text: "India Staffing" },
  { key: "US Staffing", text: "US Staffing" },
  { key: "UAE Staffing", text: "UAE Staffing" },
  { key: "Training", text: "Training" },
  { key: "Consulting & Products", text: "Consulting & Products" },
  { key: "Data", text: "Data" },
  { key: "Digital", text: "Digital" },
];

const currencyOptions = [
  { key: "INR", text: "INR" },
  { key: "USD", text: "USD" },
  { key: "Diram", text: "Diram" },
  { key: "Riyal", text: "Riyal" },
  { key: "Ringitt", text: "Ringitt" },
  { key: "EURO", text: "EURO" },
  { key: "Pound", text: "Pound" },
  { key: "Rand", text: "Rand" },
  { key: "CAD", text: "CAD" },
  { key: "Swiss Franc", text: "Swiss Franc" },
  { key: "Riel", text: "Riel" },
];
const probOfWinning = [
  { key: "10%", text: "10%" },
  { key: "20%", text: "20%" },
  { key: "30%", text: "30%" },
  { key: "40%", text: "40%" },
  { key: "50%", text: "50%" },
  { key: "60%", text: "60%" },
  { key: "70%", text: "70%" },
  { key: "80%", text: "80%" },
  { key: "90%", text: "90%" },
  { key: "100%", text: "100%" },
];

const budgetStatus = [
  { key: "Not Started", text: "Not Started" },
  { key: "In Progress", text: "In Progress" },
  { key: "Reviewed", text: "Reviewed" },
  { key: "Submitted", text: "Submitted" },
  { key: "Approved", text: "Approved" },
];

const priorityLevel = [
  { key: "High", text: "High" },
  { key: "Medium", text: "Medium" },
  { key: "Low", text: "Low" },
];

const opputunitySourceOption = [
  { key: "Referral", text: "Referral" },
  { key: "Direct Inquiry", text: "Direct Inquiry" },
  { key: "Marketing", text: "Marketing" },
];

const EditOpportunityModel = (props) => {
  const navigate = useNavigate();
  const { isModalOpen, setIsModalOpen, showMessageBar, setShowMessageBar } = props;
  const [showTextField, setShowTextField] = useState(false);
  const [otherValue1, setOtherValue1] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [showPopup, setShowPopup] = useState(false);
  const [isModalShrunk, setIsModalShrunk] = useState(false);
  const [currentHover, setCurrentHover] = useState("");
  const [validationErrors, setValidationErrors] = useState({});
  const [showUploadPopup, setShowUploadPopup] = useState(false);
  const fileInputRef = useRef(null);
  const [detailRes,setDetailRes] = useState('');
   const [selectedKey, setSelectedKey] = useState(null);
    const [selectedKeyCom, setSelectedKeyCom] = useState(null);
  const [pipelineData, setPipelineData] = useState({
    Opportunity_id:"",
    name: "",
    request_type: "",
    request_client: "",
    level: "",
    status: "",
    customer_name: "",
    email_id: "",
    mobile_number: "",
    start_date: "",
    close_date: "",
    probability_winning: "",
    priority_level: "",
    opportunity_source: "",
    assign_to: "",
    region_location: "",
    ss_businness_unit: "",
    currency: "",
    opportunity_value: "",
    budget_status: "",
    documents: [],
  });

  const [error, setError] = useState("");
  const [value, setValue] = useState("");

  const [editorState, setEditorState] = useState(() => EditorState.createEmpty());
  const [editorState2, setEditorState2] = useState(() => EditorState.createEmpty());
  const [basicInfoerrors, setBasicInfoErrors] = useState({});
  const [isManualInput, setIsManualInput] = useState(false);
   const [searchParams, setSearchParams] = useSearchParams();
  let minDate = new Date();
  let close_date = new Date(pipelineData.entry_date);

  const dateHandler = (date, name) => {
    setPipelineData((prevData) => {
      return {
        ...prevData,
        [name]: date,
      };
    });
    setCurrentHover("");
    setValidationErrors((prevErrors) => {
      return {
        ...prevErrors,
        [name]: "",
      };
    });
  };

  const modalSizeHandler = () => {
    setIsModalShrunk(!isModalShrunk);
  };
  const [DealName, getDealName] = useState("");

  const [currency, setCurrency] = useState([]);

  const [adminSales, setAdminSales] = useState([]);

//    const formatDate = (dateString) => {
//         const options = { year: 'numeric', month: '2-digit', day: '2-digit' };
//         return new Date(dateString).toLocaleDateString(undefined, options);
//     };


  useEffect(() => {
    const fetchOpportunityDetails = async () => {
       axiosPrivateCall.get(`/api/v1/crm/getclientbyid/${searchParams.get("_id")}`)
      .then((res) => {
        setDetailRes(res.data)
        setSelectedKey(res.data.request_client._id)
         setSelectedKeyCom(res.data.assign_to._id)
        setPipelineData({    
          Opportunity_id: res.data.Opportunity_id,
          name: res.data.name,
    request_type: res.data.request_type,
    request_client: res.data.request_client,
    level: res.data.level,
    status: res.data.status,
    customer_name: res.data.customer_name,
    email_id: res.data.email_id,
    mobile_number: res.data.mobile_number,
    start_date: res.data.start_date,
    close_date: res.data.close_date,
    probability_winning: res.data.probability_winning,
    priority_level: res.data.priority_level,
    opportunity_source: res.data.opportunity_source,
    assign_to: res.data.assign_to,
    region_location: res.data.region_location,
    ss_businness_unit: res.data.ss_businness_unit,
    currency: res.data.currency,
    opportunity_value: res.data.opportunity_value,
    budget_status: res.data.budget_status,
    documents: res.data.documents,})
        // sanitizeApiData(res.data);
        // setCandidateId(res.data.CandidateId);
        // setCandidateObjId(res.data._id);
      })
      .catch((e) => {
        console.log(e);
      });
    };

    fetchOpportunityDetails();
  }, []); 

  useEffect(() => {
    const fetchCurrency = async () => {
      try {
        const response = await axiosPrivateCall.get("https://countriesnow.space/api/v0.1/countries/currency");
        const currencyData = response.data.data;

        // Map the currency data to objects with 'value' and 'label'
        const currencyOptions = currencyData.map((currency) => ({
          value: currency.currency,
          label: currency.currency,
        }));

        // Filter out duplicate key and text values
        const uniqueCurrencyOptions = currencyOptions.filter((currency, index, array) => {
          // Check if the current currency has a unique key and text compared to all previous currencies
          return array
            .slice(0, index)
            .every((prevCurrency) => prevCurrency.value !== currency.value && prevCurrency.label !== currency.label);
        });

        // Convert 'value' and 'label' properties to 'key' and 'text'
        const uniqueCurrencyOptionsWithKeyAndText = uniqueCurrencyOptions.map((currency) => ({
          key: currency.value,
          text: currency.label,
        }));

        // Update the state with unique currency options having key and text properties
        setCurrency(uniqueCurrencyOptionsWithKeyAndText);
      } catch (error) {
        console.error(error);
      }
    };

    fetchCurrency();
  }, []);

  const getDealNameDetails = async () => {
    return axiosPrivateCall
      .get("api/v1/crm/getDealname")
      .then((response) => {
        console.log(response.data, "response");
        getDealName(response.data);
        setSelectedKey(pipelineData.request_client._id)
         setSelectedKeyCom(pipelineData.assign_to._id)
        return response.data; // Return the job roles data from the API call
      })
      .catch((error) => {
        // Handle any errors that occur during the API call
        throw error; // Propagate the error for handling in the calling function
      });
  };
    const getAssignToDetails = async () => {
    return axiosPrivateCall
      .get("api/v1/crm/getadminsales")
      .then((response) => {
        setAdminSales(response.data);
        return response.data; // Return the job roles data from the API call
      })
      .catch((error) => {
        // Handle any errors that occur during the API call
        throw error; // Propagate the error for handling in the calling function
      });
  };

  const dropDownHandler = (e, item, name) => {
    setPipelineData((prevData) => {
      return {
        ...prevData,
        [name]: item.text,
      };
    });
    setValidationErrors((prevErrors) => {
      return {
        ...prevErrors,
        [name]: "",
      };
    });
  };

  const validateFields = () => {
    const errors = {};

    console.log(errors,"isvalid")

    if (!pipelineData.name) {
      errors.name = "required";
    }

    if (!pipelineData.request_type) {
      errors.request_type = "required";
    }
   
    if (!pipelineData.request_client) {
      errors.request_client = "required";
    }

    if (!pipelineData.level) {
      errors.level = "required";
    }

    if (!pipelineData.status) {
      errors.status = "required";
    }
    // if (!pipelineData.customer_name) {
    //   errors.customer_name = "required";
    // }

    // if (!pipelineData.email_id) {
    //   errors.email_id = "required";
    // }

    // if (!pipelineData.mobile_number) {
    //   errors.mobile_number = "required";
    // }

    // if (!pipelineData.start_date) {
    //   errors.start_date = "required";
    // }

    // if (!pipelineData.close_date) {
    //   errors.close_date = "required";
    // }

    // if (!pipelineData.probability_winning) {
    //   errors.probability_winning = "required";
    // }

    // if (!pipelineData.priority_level) {
    //   errors.priority_level = "required";
    // }

    // if (!pipelineData.opportunity_source) {
    //   errors.opportunity_source = "required";
    // }

    // if (!pipelineData. assign_to) {
    //   errors. assign_to = "required";
    // }

    // if (!pipelineData.region_location) {
    //   errors.region_location = "required";
    // }

    // if (!pipelineData.ss_businness_unit) {
    //   errors.ss_businness_unit = "required";
    // }

    // if (!pipelineData.currency) {
    //   errors.currency = "required";
    // }

    // if (!pipelineData.opportunity_value) {
    //   errors.opportunity_value = "required";
    // }

    // if (!pipelineData. budget_status) {
    //   errors. budget_status = "required";
    // }

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  useEffect(() => {
    setPipelineData((prevData) => {
      return {
        ...prevData,
        opportunity_description: draftToHtml(convertToRaw(editorState.getCurrentContent())),
        addtional_remarks: draftToHtml(convertToRaw(editorState2.getCurrentContent())),
      };
    });
  }, [editorState, editorState2]);

  useEffect(() => {
    getDealNameDetails();
    getAssignToDetails()
  }, []);

  const submitHandler = async () => {
    const isValid = validateFields();

    if (isValid) {
      try {
        axiosPrivateCall
          .put(`/api/v1/crm/updateData/${searchParams.get("_id")}`, pipelineData)
          .then((response) => {
            setPipelineData(response.data);
            // setIsModalOpen(!isModalOpen);
            // setShowMessageBar(!showMessageBar);
            navigate('/managedeals/managesalespipeline');
          })
          .catch((error) => {
            console.error("Error submitting data:", error);

            if (error.response) {
              const errors = {};
              errors.client_id = error.response.data;
              setValidationErrors(errors);
            }
          });
      } catch (error) {
        console.error("Error submitting data:", error);
      }
    }
  };
  const getKeyByText = (text) => {
    for (const option of DealName) {
      if (option.text === text) {
        return option.key;
      }
    }
    return ""; // Return an empty string if no matching key is found
  };

      const handleUCClick = () => {
    navigate('/reports/recruitersubmission');
  };

  const inputChangeHandler = (e, inputName) => {
    e.preventDefault();
    const { value } = e.target;
    let inputValue = value;
    let isInputValid = true;
    let isNameValid = false;

    const validationRules = {
      client_id: /^[\w\s-]+$/,
      owner: /^[\w\s-]+$/,
      industry: /^[\w\s-]+$/,
      delivery_poc: /^[\w\s-]+$/,
      mobile_number: /^[6-9]\d{9}$/,
    };

    if (inputName === "customer_name" && /^[\w\s-]+$/.test(inputValue)) {
      if (inputValue.length > 40) inputValue = inputValue.slice(0, 40);
      isNameValid = true;
    }

    if (inputName === "mobile_number" && (inputValue === "" || !isNaN(inputValue))) {
      if (inputValue.length > 10) inputValue = inputValue.slice(0, 10);
      isNameValid = true;
    }

    if (inputName === "currency" && /^[\w\s-]+$/.test(inputValue)) {
      isNameValid = true;
    }

    if (validationRules[inputName]) {
      isInputValid = validationRules[inputName].test(value);
    }

    console.log(inputName, inputValue, "assa");

    if (inputName === "values") {
      if (!isNumOnly(value)) {
        isInputValid = false;
      }
      if (isEmpty(value)) {
        isInputValid = true;
      }
    }

    if (isInputValid || isNameValid) {
      setPipelineData({
        ...pipelineData,
        [inputName]: inputValue,
      });

      setValidationErrors((prevErrors) => {
        return {
          ...prevErrors,
          [inputName]: "",
        };
      });
    }
  };

  const handleKeyDown = (e) => {
    // Allow only digits (0-9) and backspace/delete keys
    if (!(e.key >= "0" && e.key <= "9") && e.key !== "Backspace" && e.key !== "Delete") {
      e.preventDefault();
    }
  };

  function UploadHandler() {
    setShowUploadPopup(true);
  }

  function handleDel() {
    setPipelineData((prev) => {
      let buffer = { ...prev };
      buffer.documents = [];
      return buffer;
    });
  }

  const dropDownHandlerText = (e, item, name) => {
  
    if(name === "request_client"){
 setSelectedKey(item.key)
    }else if(name === "assign_to"){
 setSelectedKeyCom(item.key)
    }
    
    setIsManualInput(false);
    if (item.text === "Others") {
      setShowTextField(true);
    } else {
      setShowTextField(false);
    }

    setPipelineData({
      ...pipelineData,
      [name]: item.key,
    });
    setValidationErrors((prevErrors) => {
      return {
        ...prevErrors,
        [name]: "",
      };
    });
  };
  function customSortDropDown(arr) {
    if (!Array.isArray(arr)) {
      // If 'arr' is not an array, handle it accordingly
      return [];
    }

    const specialChars = "!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~";
    const special = [];
    const numerical = [];
    const alpha = [];
    const mixedAlphaNumeric = [];

    // Filter out non-object entries (if any) and ensure they have 'text' property
    const validEntries = arr.filter((entry) => typeof entry === "object" && "text" in entry);

    validEntries.forEach((entry) => {
      const text = entry.text.toLowerCase();

      if (/^\d/.test(text)) {
        numerical.push(entry);
      } else if (/^[^\w\s]/.test(text)) {
        special.push(entry);
      } else if (/^[a-zA-ZÀ-ÖØ-öø-ÿ]/.test(text)) {
        alpha.push(entry);
      } else {
        mixedAlphaNumeric.push(entry);
      }
    });

    special.sort((a, b) => specialChars.indexOf(a.text[0]) - specialChars.indexOf(b.text[0]));
    numerical.sort((a, b) => a.text.localeCompare(b.text, undefined, { numeric: true }));
    alpha.sort((a, b) => a.text.localeCompare(b.text, undefined, { sensitivity: "base" }));
    mixedAlphaNumeric.sort((a, b) => a.text.localeCompare(b.text));

    return special.concat(numerical, alpha, mixedAlphaNumeric);
  }
  const jobRoleChange = (value) => {
    setOtherValue1(value);
    const trimmedValue = value.trim().replace(/\s+/g, " ");
    const isJobRoleExists = DealName.some((role) => role.text === trimmedValue.toLowerCase());

    const containsSpecialCharacters = /[!@#$%^&*(),.?":{}|<>]/.test(trimmedValue);
    if (!value) {
      setValidationErrors({
        ...validationErrors,
        otherValue1: "required",
      });
    } else if (isJobRoleExists) {
      setValidationErrors({
        ...validationErrors,
        otherValue1: "Job Role already exists.",
      });
    } else if (containsSpecialCharacters) {
      setValidationErrors({
        ...validationErrors,
        otherValue1: "Invalid Job Role",
      });
    } else {
      setValidationErrors({
        ...validationErrors,
        otherValue1: null,
      });
    }

    setIsManualInput(true);

    setPipelineData({
      ...pipelineData,
      Deal_name: trimmedValue,
    });
  };

  function uploadDocs(files) {

    let data = Object.values(files);
    const formData = new FormData();

    // data.map((file) => {
      formData.append("files", files);
    // });

    axiosPrivateCall
      .post("/api/v1/crm/addDocuments", formData)
      .then((res) => {
        let fileuploaded= res.data.documents;
        setPipelineData((prev) => {
        //   let buffer = { ...prev };
        //   buffer.documents.push(...fileuploaded);
          return {...prev,documents:res.data.documents};
        });
      })
      .catch((err) => {
        console.log(err);
      });
  }

  function removeUploadedDoc(key) {
    console.log(key);
    let buffer = [...pipelineData.documents];
    let result = [];
    buffer.map((doc) => {
      if (!(doc.document_name === key)) {
        result.push(doc);
      }
    });
    console.log(result);

    setPipelineData((prev) => {
      let buffer = { ...prev };
      buffer.documents = [...result];
      return buffer;
    });
  }


 
  return (
    <div className={styles.editContainer}>
      <UploadPopup
        showPopup={showUploadPopup}
        setShowPopup={setShowUploadPopup}
        basicInfo={pipelineData || { documents: [] }}
        setBasicInfo={setPipelineData}
      />
      {
        <Popup
          resetState={() => ""}
          showPopup={showPopup}
          setShowPopup={setShowPopup}
          isModalOpen={isModalOpen}
          setIsModalOpen={setIsModalOpen}
        />
      }
      {/* <Modal
        scrollableContentClassName={styles.addcandidate_modal_scrollable_content}
        containerClassName={`${
          isModalShrunk ? styles.addcandidate_modal_container_shrunk : styles.addcandidate_modal_container
        }`}
         isOpen={true}
        // isOpen={isModalOpen}
      > */}
        <div className={styles.addcandidate_modal_header_container}>
          <div className={styles.mini_header_tag_container}>
            <p className={styles.mini_title}>Opportunity</p>
          </div>
          <div className={styles.header_tag_expand_close_icon_container}>
          <div className={styles.header_tag_container}>Opportunity ID : { pipelineData.Opportunity_id}</div>

            <div className={styles.header_expand_close_icon_container}>
              {/* <div onClick={modalSizeHandler} className={styles.header_expand_icon_container}>
                {isModalShrunk ? (
                  <Icon iconName="FullScreen" className={contractIconClass} />
                ) : (
                  <Icon iconName="BackToWindow" className={contractIconClass} />
                )}
              </div> */}
              {/* <div onClick={() => navigate(-1)} className={styles.header_close_icon_container}>
                <Icon iconName="ChromeClose" className={closeIconClass} />
              </div> */}
            </div>
          </div>

          <div className={styles.dropdownRow}>
            <p className={styles.leftContainer}>
              <div className={styles.customer_name}>
                <Label className={styles.name_label_style} required>
                  Name
                </Label>
                <TextField
                  value={pipelineData.name}
                  placeholder="Enter the Name"
                  name="name"
                  onChange={(e) => {
                    inputChangeHandler(e, "name");
                    setCurrentHover("");
                  }}
                  styles={(props) => textFieldColored1(props, currentHover, validationErrors.name, pipelineData.name)}
                  // errorMessage={validationErrors.name}
                />
              </div>
            </p>
            <div className={styles.rightContainer}>
              <div className={styles.opportunity_type}>
                <Label className={styles.label_style} required>
                  Level
                </Label>

                <Dropdown
                  options={LevelOption}
                  selectedKey={pipelineData.level}
                  onChange={(e, item) => {
                    dropDownHandlerText(e, item, "level");
                    setCurrentHover("");
                  }}
                  placeholder="Select"
                  notifyOnReselect
                  style={{fontSize: "12px",color: "#5B5F62"}}
                  styles={(props) => customizedDropdown(props, currentHover, error, pipelineData.level)}
                  // errorMessage={validationErrors.level}
                />
              </div>
              <div className={styles.opportunity_type}>
                <Label className={styles.label_style} required>
                  Status
                </Label>
                <Dropdown
                  options={statusOption}
                  selectedKey={pipelineData.status}
                  onChange={(e, item) => {
                    dropDownHandlerText(e, item, "status");
                    setCurrentHover("");
                  }}
                  placeholder="Select"
                  notifyOnReselect
                  style={{fontSize: "12px",color: "#5B5F62"}}
                  styles={customizedDropdown(props, currentHover, error, pipelineData.status)}
                  // errorMessage={validationErrors.status}
                />
              </div>

              <div className={styles.submitButton}>
                 {/* <PrimaryButton
                  // onClick={() => navigateTo(`/candidatelibrary/editcandidate?candidate_id=${searchParams.get("candidate_id")}`)}
                >
                  <img src={Editicon} alt="image" style={{ marginRight: "5px", width:"16px", height:"16px"}}  />
                  <span style={{ fontSize: "16px", fontWeight:"600", paddingBottom:"3px"  }}>Edit</span>
                </PrimaryButton> */}
                <PrimaryButton text={`Save & Close`} onClick={submitHandler} iconProps={{ iconName: "Save" }} />
              </div>
            </div>
          </div>
        </div>

        <div className={styles.add_modal_main_container}>
          <div className={styles.modal_main_container}>
            <div className={styles.sub_container}>
                   <div className={styles.divider1}>
              <div className={styles.opportunity_type_1}>
                <Label className={styles.label_style_1} required>
                  Request Type
                </Label>
                <Dropdown
                  options={requesttypeOption}
                  selectedKey={pipelineData.request_type}
                  onChange={(e, item) => {
                    dropDownHandlerText(e, item,"request_type");
                    setCurrentHover("");
                  }}
                  placeholder="Select"
                  notifyOnReselect
                   style={{fontSize: "12px",color: "#5B5F62"}}
                  styles={(props) => secondContainerDropdown(props, currentHover, error, pipelineData.request_type)}
                  // errorMessage={validationErrors.request_type}
                />
              </div>

              <div className={styles.opportunity_type_1}>
                <Label className={styles.label_style_1} required>
                  Request Client
                </Label>
                <Dropdown
                  options={DealName}
                  selectedKey={selectedKey}
                  onChange={(e, item) => {
                    dropDownHandlerText(e, item, "request_client");
                    setCurrentHover("");
                  }}
                  placeholder="Select"
                  notifyOnReselect
                   style={{fontSize: "12px",color: "#5B5F62"}}
                  styles={(props) => secondContainerDropdown(props, currentHover, error, pipelineData.request_client)}
                  // errorMessage={validationErrors.request_client}
                />
              </div>
              </div>
                <div className={styles.main_dropdown_container2}  
                onClick={handleUCClick} 
                >             
                 <div className={styles.icon}>
                <Icon iconName="ChangeEntitlements" />
              </div>
              <div className={styles.iconname}>Track Interview</div>
            </div>
            </div>
          </div>

          <div className={styles.main_box_container}>
            <div className={styles.firstBox}>
              <div className={styles.box}>
                <p className={styles.P_customerDetains}>Customer Details</p>
                <div className={styles.customerDetailsContainer}>
                  <div className={styles.textField_customerDetails}>
                    <Label className={styles.customer_label_style}>Customer Name</Label>
                    <TextField
                      value={pipelineData.customer_name}
                      placeholder="Enter the Name"
                      onChange={(e) => {
                        inputChangeHandler(e, "customer_name");
                        setCurrentHover("");
                      }}
                      styles={textFieldColored2}
                      errorMessage={validationErrors.customer_name}
                      className={styles.input}
                    />
                  </div>
                  <div className={styles.textField_customerDetails_1}>
                    <Label className={styles.customer_label_style}>Email ID</Label>
                    <TextField
                      value={pipelineData.email_id}
                      placeholder="Enter the Email ID"
                      onChange={(e) => {
                        inputChangeHandler(e, "email_id");
                        setCurrentHover("");
                      }}
                      styles={textFieldColored2}
                      errorMessage={validationErrors.email_id}
                    />
                  </div>
                </div>
                <div className={styles.textField_customerDetails}>
                  <Label className={styles.customer_label_style}>Mobile Number</Label>
                  <TextField
                    value={pipelineData.mobile_number}
                    placeholder="Enter the Mobile Number"
                    onChange={(e) => {
                      inputChangeHandler(e, "mobile_number");
                      setCurrentHover("");
                    }}
                    styles={textFieldColored2}
                    errorMessage={validationErrors.mobile_number}
                  />
                </div>
              </div>

              <div className={styles.box}>
                <p className={styles.P_AC}>Assignment & Categorization</p>
                <div className={styles.customerDetailsContainer}>
                  <div className={styles.textField_customerDetails}>
                    <Label className={styles.customer_label_style}>Assigned To</Label>
                    <Dropdown
                      options={customSortDropDown(adminSales)}
                      selectedKey={selectedKeyCom}
                      onChange={(e, item) => {
                        dropDownHandlerText(e, item,"assign_to");
                        setCurrentHover("");
                      }}
                      notifyOnReselect
                       style={{fontSize: "12px",color: "#5B5F62"}}
                      styles={(props) => DropdownStyles(props, currentHover, error, pipelineData.assign_to)}
                      errorMessage={validationErrors.assign_to}
                    />
                  </div>
                  <div className={styles.textField_customerDetails_1}>
                    <Label className={styles.customer_label_style}>SS Business Unit</Label>
                  
                    <Dropdown
                      options={SSBuisnessUnitOption}
                      selectedKey={pipelineData.ss_businness_unit}
                      onChange={(e, item) => {
                        dropDownHandlerText(e, item, "ss_businness_unit");
                        setCurrentHover("");
                      }}
                      placeholder="Select"
                      notifyOnReselect
                       style={{fontSize: "12px",color: "#5B5F62"}}
                      styles={(props) => DropdownStyles(props, currentHover, error, pipelineData.ss_businness_unit)}
                      errorMessage={validationErrors.ss_businness_unit}
                    />

                  </div>
                </div>
                <div className={styles.textField_customerDetails}>
                  <Label className={styles.customer_label_style}>Region & Location</Label>
                  <Dropdown
                    options={customSortDropDown(regionLocationOption)}
                    selectedKey={pipelineData.region_location}
                    onChange={(e, item) => {
                      dropDownHandlerText(e, item,"region_location");
                      setCurrentHover("");
                    }}
                    placeholder="Select"
                    notifyOnReselect
                     style={{fontSize: "12px",color: "#5B5F62"}}
                    styles={(props) => DropdownStyles(props, currentHover, error, pipelineData.region_location)}
                    errorMessage={validationErrors.region_location}
                  />
                </div>
              </div>
            </div>

            <div className={styles.firstBox}>
              <div className={styles.box}>
                <p className={styles.P_timeline}>Opportunity Timeline</p>
                <div className={styles.customerDetailsContainer}>
                  <div className={styles.textField_customerDetails}>
                    <Label className={styles.customer_label_style}>Start Date</Label>
                    <DatePicker
                      placeholder="DD/MM/YYYY"
                      onSelectDate={(date) => {
                        dateHandler(date, "start_date");
                        // // fieldsChecks();
                        // setCurrentHover("");
                      }}
                      styles={calendarClass(pipelineData.start_date)}
                      value={new Date(pipelineData.start_date)}
                      errorMessage={validationErrors.start_date}

                    />
                  </div>
                  <div className={styles.textField_customerDetails_1}>
                    <Label className={styles.customer_label_style}>Close Date</Label>
                    <DatePicker
                      placeholder="DD/MM/YYYY"
                      onSelectDate={(date) => {
                        dateHandler(date, "close_date");
                        // fieldsChecks();
                        setCurrentHover("");
                      }}
                      styles={calendarClass(pipelineData.close_date)}
                      value={new Date(pipelineData.close_date)}
                      errorMessage={validationErrors.close_date}
                    />
                  </div>
                </div>
                <div className={styles.textField_customerDetails}>
                  <Label className={styles.customer_label_style}>probability of Winning %</Label>
                  <Dropdown
                    options={probOfWinning}
                    selectedKey={pipelineData.probability_winning}
                    onChange={(e, item) => {
                      dropDownHandlerText(e, item, "probability_winning");
                      setCurrentHover("");
                      // setClientData({ ...clientData, Deal_name: item.key });
                    }}
                    placeholder="Select"
                    notifyOnReselect
                     style={{fontSize: "12px",color: "#5B5F62"}}
                    styles={(props) => DropdownStyles(props, currentHover, error, pipelineData.probability_winning)}
                    errorMessage={validationErrors.probability_winning}
                  />
                </div>
              </div>

              <div className={styles.box}>
                <p className={styles.P_customerDetains}>Financial Details</p>
                <div className={styles.customerDetailsContainer}>
                  <div className={styles.textField_customerDetails}>
                    <Label className={styles.customer_label_style}>Currency</Label>
                     <Dropdown
                      options={customSortDropDown(currency)}
                      selectedKey={pipelineData.currency}
                      onChange={(e, item) => {
                        dropDownHandlerText(e, item, "currency");
                        setCurrentHover("");
                      }}
                      placeholder="Select"
                      notifyOnReselect
                       style={{fontSize: "12px",color: "#5B5F62"}}
                      styles={(props) => DropdownStyles(props, currentHover, error, pipelineData.currency)}
                      errorMessage={validationErrors.currency}
                    /> 
                  </div>
                  <div className={styles.textField_customerDetails_1}>
                    <Label className={styles.customer_label_style}>Opportunity Value</Label>
                    <TextField
                      value={pipelineData.opportunity_value}
                      placeholder="Enter the Value"
                      onChange={(e) => {
                        inputChangeHandler(e, "opportunity_value");
                        setCurrentHover("");
                      }}
                      styles={textFieldColored2}
                      errorMessage={validationErrors.opportunity_value}
                    />
                  </div>
                </div>
                <div className={styles.textField_customerDetails}>
                  <Label className={styles.customer_label_style}>Budget Status</Label>
                  <Dropdown
                    options={budgetStatus}
                    selectedKey={pipelineData.budget_status}
                    onChange={(e, item) => {
                      dropDownHandlerText(e, item, "budget_status");
                      setCurrentHover("");
                    }}
                    placeholder="Select"
                    notifyOnReselect
                     style={{fontSize: "12px",color: "#5B5F62"}}
                    styles={(props) => DropdownStyles(props, currentHover, error, pipelineData.budget_status)}
                    errorMessage={validationErrors.budget_status}
                  />
                </div>
              </div>
            </div>

            <div className={styles.firstBox}>
         
              <div className={styles.rightTopBox}>
                <p className={styles.P_otherOppurtunity}>Other Opportunity Details</p>
                <div className={styles.customerDetailsContainer}>
                  <div className={styles.textField_customerDetails}>
                    <Label className={styles.customer_label_style}>Priority Level</Label>
                    <Dropdown
                      options={priorityLevel}
                      selectedKey={pipelineData.priority_level}
                      onChange={(e, item) => {
                        dropDownHandlerText(e, item, "priority_level");
                        setCurrentHover("");
                      }}
                      placeholder="Select"
                      notifyOnReselect
                       style={{fontSize: "12px",color: "#5B5F62"}}
                      styles={(props) => DropdownStyles(props, currentHover, error, pipelineData.priority_level)}
                      errorMessage={validationErrors.priority_level}
                    />
                  </div>
                  <div className={styles.textField_customerDetails_1}>
                    <Label className={styles.customer_label_style}>Opportunity Source</Label>
                    <Dropdown
                      options={customSortDropDown(opputunitySourceOption)}
                      selectedKey={pipelineData.opportunity_source}
                      onChange={(e, item) => {
                        dropDownHandlerText(e, item, "opportunity_source");
                        setCurrentHover("");
                      }}
                      placeholder="Select"
                      notifyOnReselect
                       style={{fontSize: "12px",color: "#5B5F62"}}
                      styles={(props) => DropdownStyles(props, currentHover, error, pipelineData.opportunity_source)}
                      errorMessage={validationErrors.opportunity_source}
                    />
                  </div>
                </div>
              </div>

              <div className={styles.boxRightBottom}>
                <p className={styles.P_customerDetains}>Attachments</p>
                <div className={styles.boxWithDottedLines} style={{marginTop: "10px"}}>
                  <img className={styles.uploadImage} src={uploadImage} />
                  <p className={styles.fileTypeText}>PDF, JPG, PNG, DOC below 1 Mb</p>
                  <p className={styles.infoText}>You can also upload files by</p>
                  <div>
                    <PrimaryButton
                      text="Browse Files"
                      className={styles.uploadButton}
                      styles={buttonStyles}
                      onClick={() => fileInputRef.current.click()}
                    />
                    <input
                      multiple
                      hidden
                      ref={fileInputRef}
                      style={{ display: "none" }}
                      type="file"
                      onChange={(e) => uploadDocs(e.target.files[0])}
                    />
                  </div>
                  <div className={styles.bottomContainer}>
                    {pipelineData.documents.map((doc) => (
                    <div className={styles.spacer}>
                      <a href={doc.document}>{doc.document_name}</a>
                      <Icon
                        iconName="ChromeClose"
                        className={tableCloseIconClass}
                        onClick={() => {
                          removeUploadedDoc(doc.document_name);
                        }}
                      />
                    </div>
                  ))}
                  </div>
                  <div></div>
                </div>
                {/* <div className={styles.bottomContainer}>
                  {pipelineData.documents.map((doc) => (
                    <div className={styles.spacer}>
                      <a href={doc.document}>{doc.document_name}</a>
                      <Icon
                        iconName="ChromeClose"
                        className={tableCloseIconClass}
                        onClick={() => {
                          removeUploadedDoc(doc.document_name);
                        }}
                      />
                    </div>
                  ))}
                </div> */}
              </div>
            </div>
          </div>

          {/* <------------------------------------------------------------------------------------------> */}
        </div>
      {/* </Modal> */}
    </div>
  );
};
export default EditOpportunityModel;
