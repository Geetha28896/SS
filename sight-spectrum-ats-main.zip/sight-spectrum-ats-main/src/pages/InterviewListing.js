import React, { useEffect, useState, useId } from "react";
import styles from "./ManageEmployee.module.css"
import { SearchBox, FontIcon, mergeStyles, mergeStyleSets, MessageBarType, Dropdown, Callout, DirectionalHint, DefaultButton, MessageBar } from '@fluentui/react';
import { Shimmer } from '@fluentui/react';
import { useLocation, useNavigate } from "react-router-dom";
import InfiniteScroll from 'react-infinite-scroll-component';
import { axiosPrivateCall } from "../constants";
import Nomatchimg from "../assets/no.png"
import { Spinner, SpinnerSize } from "@fluentui/react";
import InterviewReschedule from "./InterviewReschedule";
import { DropdownMenuItemType, IDropdownOption, IDropdownStyles } from '@fluentui/react/lib/Dropdown';
import { EventCancelPopup } from "../components/EventCancelPopup";
import { loginRequest } from "../utils/authConfig";
import { useMsal } from "@azure/msal-react";

const searchIcon = { iconName: 'Search' };


const iconClass = mergeStyles({
    fontSize: 20,
    height: 20,
    width: 20,
    margin: '0 10px',
    color: '#999DA0',
    cursor: 'pointer',
    userSelect: 'none',
});

const iconClass1 = mergeStyles({
    fontSize: 12,
    height: 12,
    width: 12,
    margin: '0 ',
    color: '#999DA0',
    cursor: 'pointer'
});

const searchFieldStyles = mergeStyleSets({
    root: { width: '185px', },
});



const dropdownStyles = {
    dropdown: { width: 200 },
};

const CalloutNameStyles = {
    calloutMain: {
        background: '#EDF2F6',
        padding: '2',

    },
}


const messageBarStyles = {
    content: {
        maxWidth: 620,
        minWidth: 450,
    }
}

const DropdownControlledMultiExampleOptions = [
    { key: 'allHeader', text: 'All', itemType: DropdownMenuItemType.Header },
    { key: 'myInterviewHeader', text: 'My Interview', itemType: DropdownMenuItemType.Header },
    { key: 'accManagerHeader', text: 'Account Managers', itemType: DropdownMenuItemType.Header },
    { key: 'Dharshana', text: 'Dharshana' },
];
let items = Array(4).fill(null);
function InterviewListing(props) {
    const [showPopup1, setShowPopup1] = useState(false)
    const [showMessageBar, setShowMessageBar] = useState(false);

    const [cancelPop, setCancelPop] = useState(false);
    const [rescheduleValue, setReScheduleValue] = useState({});
    const location = useLocation()
    const [updateId, setUpdateId] = useState('')
    const [deleteId, setDeleteID] = useState('')
    const [isSubmitDel, setSubmitDel] = useState(false);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isSubmitSuccess, setSubmitSuccess] = useState(false);
    const [interviewList, setInterviewList] = useState('');
    const [isDataLoaded, setIsDataLoaded] = useState(false);
    const [rowId, setRowId] = useState('');
    const [updateCallout, setUpdateCallout] = useState(false);
    const [isUserSearching, setIsUserSearching] = useState(false)
    const [fetchOptions, setFetchOptions] = useState({
        skip: 0,
        limit: 15,
        sort_field: 'updatedAt',
        sort_type: -1,
        search_field: ''
    })
    const [loading, setLoading] = useState(false);
    const [completed, setCompleted] = useState(false);

    const [hasMore, setHasMore] = useState(true)
    const [meetObjValue, setMeetObjValue] = useState()
    const [selectedKeys, setSelectedKeys] = useState()
    const [hoverCallout, setHoverCallout] = useState('');


    const { instance, accounts } = useMsal();
    const navigateTo = useNavigate();

    console.log(interviewList, "demo")
    const addEllipsisToName = (name) => {

        if (name?.length > 13) {
            let new_name = name.substring(0, 13).padEnd(16, '.')
            return new_name
        }
        else return name

    }
    const columns = [

        {
            columnKey: 'Meeting ID',
            label: 'Meeting ID',
        }, {
            columnKey: 'Demand ID',
            label: 'Demand ID',

        }, {
            columnKey: 'Candidate ID',
            label: 'Candidate ID',
        }, {
            columnKey: 'Candidate Name',
            label: 'Candidate Name',
        },
        {
            columnKey: 'Mobile',
            label: 'Mobile'
        }, {
            columnKey: 'Candidate Email',
            label: 'Candidate Email'
        }, {
            columnKey: 'Interview Email',
            label: 'Interview Email',
        }, {
            columnKey: 'Scheduled By',
            label: 'Scheduled By',
        },

        {
            columnKey: 'Client',
            label: 'Client',
        },
        {
            columnKey: 'Interview Date',
            label: 'Interview Date',
        },
        {
            columnKey: 'Start time',
            label: 'Start time',
        },
        {
            columnKey: 'Duration',
            label: 'Duration',
        }, {
            columnKey: 'Status',
            label: 'Status',
        },

        {
            columnKey: 'More Options',
            label: ' '
        }];
    //Scheduler concept
    const token = localStorage.getItem("token");
    let base64Url = token.split(".")[1];
    let decodedValue = JSON.parse(window.atob(base64Url));
    const user_id = decodedValue.user_id
    useEffect(() => {
        axiosPrivateCall.patch('api/v1/interview/trackstat', { user_id: decodedValue.user_id })
            .then(() => {
                console.log("Cron work!!")
            }).catch((err) => {
                console.log(`Cron work: ${err}`);
            })
    }, [])

    useEffect(() => {

        if (showMessageBar) {
            setTimeout(() => {
                setShowMessageBar(!showMessageBar)
            }, 3500)
        }

    }, [showMessageBar])
    useEffect(() => {
        getInterviewData()
        setHasMore(true)
        setCancelPop(false)
        setFetchOptions({ ...fetchOptions, skip: 0, limit: 20 })
    }, [isModalOpen, fetchOptions.sort_field, fetchOptions.sort_type])



    const getInterviewData = () => {
        setIsDataLoaded(false);
        axiosPrivateCall.get(`api/v1/interview/getHierarchyListing?skip=${fetchOptions.skip}&limit=${fetchOptions.limit}&sort_field=${fetchOptions.sort_field}&sort_type=${fetchOptions.sort_type}`)
            .then(res => {
                console.log(res.data);
                setInterviewList(res.data);
                setIsDataLoaded(true);
            }).catch(e => {
                console.log(e);
            });
    };

    const [DropdownSearch, setDropdownSearch] = useState('')
    const [searchTerm, setSearchTerm] = useState('');
    const [SearchData, setSearchData] = useState('')
    const [SplitedData, setSplitedData] = useState('')
    const handleDropdownChange = (e, item) => {
        setDropdownSearch(item.key)
        setSearchTerm('')
    }

    const clearSearchBox = () => {
        setIsUserSearching(false)
        setFetchOptions(prevData => {
            return {
                ...prevData,
                search_field: ''
            }
        })
        setSearchTerm('');
        getInterviewData();
        setHasMore(true)
    }
    const fetchMoreData = () => {
        if (isUserSearching) {
            const moreInterviews = SearchData.slice(SplitedData, SplitedData + 20)
            setSplitedData(SplitedData + 20)
            setInterviewList([...interviewList, ...moreInterviews])
            if (SplitedData >= SearchData.length) {
                setHasMore(false)
            }
        }
        else {
            axiosPrivateCall.get(`api/v1/interview/getHierarchyListing?skip=${fetchOptions.skip + fetchOptions.limit}&limit=${fetchOptions.limit}&sort_field=${fetchOptions.sort_field}&sort_type=${fetchOptions.sort_type}`)
                .then(res => {
                    const moreInterviews = res.data;
                    setInterviewList([...interviewList, ...moreInterviews])
                    if (moreInterviews.length < 20 || moreInterviews.length === 0) {
                        setHasMore(false)
                    }
                    setFetchOptions((prevState) => {

                        return {
                            ...prevState,
                            skip: fetchOptions.skip + fetchOptions.limit,
                        }
                    })
                }).catch(e => {
                    console.log(e)
                })
        }
        console.log('getting more data')
    }

    const ISOdateToCustomDate = (value) => {
        const dateFormat = new Date(value);
        let year = dateFormat.getFullYear();
        let month = dateFormat.getMonth() + 1;
        let date = dateFormat.getDate();

        if (date < 10) {
            date = '0' + date;
        }
        if (month < 10) {
            month = '0' + month;
        }
        return date + '/' + month + '/' + year;


    }
    const ISOdateToCustomTime = (value) => {
        const date = new Date(value);
        const hours = date.getUTCHours();
        const minutes = date.getUTCMinutes();
        const period = hours >= 12 ? "PM" : "AM";
        const formattedHours = hours % 12 || 12;
        const timeString = `${formattedHours}:${minutes < 10 ? '0' : ''}${minutes} ${period}`;
        return timeString;
    }

    const scheduleMeet = async (id) => {
        setMeetObjValue(id)
        setUpdateCallout(!updateCallout)
        setShowPopup1(!showPopup1);
    }

    const handleSearchInputChange = (e) => {
        const { value } = e?.target || ''; // Use optional chaining to handle cases where e or e.target is undefined
        setSearchTerm(value ? value : "");
    }

    const onChange = (event, item) => {
        if (item) {
            setSelectedKeys(
                item.selected ? [...selectedKeys, item.key] : selectedKeys.filter(key => key !== item.key),
            );
        }
    };


    const cancelStatu = () => {
        const meetId = rescheduleValue._id;
        axiosPrivateCall.patch(`/api/v1/interview/updateStatus/${meetId}`, { status: "Cancelled" }).then((res) => {
            console.log("cancel event updated")
            setCancelPop(!cancelPop)
            setReScheduleValue({})
        }).catch((err) => {
            throw err;
        })
    }
    const cancelEvent = async () => {
        try {
            const eventId = rescheduleValue.event_id;
            const request = {
                scopes: ["User.ReadWrite.All", "Mail.Send", "Calendars.ReadWrite"],
                account: accounts[0],
            };
            const loginResponse = await instance.loginPopup(loginRequest);

            const tokenResponse = await instance.acquireTokenSilent({
                ...request,
                account: loginResponse.account,
            });

            const accessToken = tokenResponse.accessToken;
            const headers = new Headers();
            const bearer = `Bearer ${accessToken}`;
            headers.append('Authorization', bearer);
            headers.append('Content-Type', 'application/json');

            const deleteEndpoint = `https://graph.microsoft.com/v1.0/me/events/${eventId}`;
            const deleteResponse = await fetch(deleteEndpoint, {
                method: 'DELETE',
                headers: headers,
            }).then(() => cancelStatu())

            return deleteResponse;
        } catch (error) {
            console.error('Error:', error);
            // Log any unexpected errors that may occur during the operation
            throw error; // Optionally rethrow the error for further handling
        }
    };

    const handleUpdate = (showPopup) => {
        if (!showPopup) {
            cancelEvent()
        }
    }


    return (
        <div className={styles.page}>
            <div className={styles.container}>
                {/* <DeletePopup showPopup={showPopup} setShowPopup={setShowPopup}
                    //  handleUpdate={handleUpdate} 
                    //  deleteId={deleteId}
                    updateCallout={updateCallout} setUpdateCallout={setUpdateCallout} /> */}
                <InterviewReschedule
                    showPopup1={showPopup1}
                    setShowPopup1={setShowPopup1}
                    // handleUpdate={handleUpdate}
                    // deleteId={deleteId}
                    setCancelPop={setCancelPop}
                    cancelPop={cancelPop}
                    setReScheduleValue={setReScheduleValue}
                    meetObj={meetObjValue}
                    updateCallout={updateCallout}
                    setUpdateCallout={setUpdateCallout}
                    setShowMessageBar={setShowMessageBar}
                    showMessageBar={showMessageBar}


                />

                <div className={styles.nav_container}>
                    <div className={styles.title}>Interview Listing</div>

                    {showMessageBar && <div >

                        <MessageBar onDismiss={() => setShowMessageBar(!showMessageBar)} styles={messageBarStyles} dismissButtonAriaLabel="Close" messageBarType={MessageBarType.success}>
                            Scheduled Successfully
                        </MessageBar>
                    </div>}

                    <div className={styles.nav_items}>
                        <Dropdown
                            placeholder='Select Filter'
                            selectedKeys={selectedKeys}
                            onChange={onChange}
                            options={DropdownControlledMultiExampleOptions}
                            multiSelect
                            styles={dropdownStyles} />

                        <SearchBox
                            onChange={handleSearchInputChange}
                            value={searchTerm}
                            //  onSearch={(e) =>
                            //     searchEmployeeList(e)} 
                            onClear={clearSearchBox} placeholder=" " iconProps={searchIcon} className={styles.search} styles={searchFieldStyles}
                            showIcon />
                        <FontIcon iconName="Breadcrumb" className={iconClass} />

                        {loading ? (<Spinner size={SpinnerSize.medium} className={iconClass} />) :
                            completed ? (<FontIcon iconName="CheckMark" className={iconClass} />) :
                                (<FontIcon iconName="Download"
                                    // onClick={downloadEmployees}
                                    className={iconClass} />)}
                    </div>
                </div>
                <EventCancelPopup
                    showPopup={cancelPop}
                    setShowPopup={setCancelPop}
                    handleUpdate={handleUpdate}
                    titleValue={rescheduleValue.title}
                />
                <div id="scrollableDiv" className={styles.table_container}>
                    <InfiniteScroll style={{ overflow: 'visible', height: '100%' }} dataLength={interviewList.length} loader={isDataLoaded && interviewList.length >= 20 && <h4>Loading...</h4>}
                        hasMore={hasMore} next={fetchMoreData} scrollableTarget="scrollableDiv">
                        <table>
                            <thead className={styles.table_header}>
                                <tr className={styles.table_row}>
                                    {columns.map((column) =>
                                        <th
                                            // onClick={() => clickSortHandler(column.columnKey)} 
                                            className={styles.table_headerContents} key={column.columnKey}>
                                            <div
                                                className={styles.table_heading}>
                                                <div>{column.label}</div>
                                                {column?.icon ? <FontIcon iconName={column.icon} className={iconClass1} /> : null}
                                            </div>
                                        </th>)}
                                </tr>
                            </thead>
                            <tbody>
                                {isDataLoaded && interviewList.length === 0 ? (
                                    <tr>
                                        <td className={styles.table_dataContents1} colSpan="13" style={{ textAlign: "center" }}>
                                            <img src={Nomatchimg} alt="image" width={"180px"} height={"200px"} />
                                        </td>
                                    </tr>
                                ) : (
                                    <>
                                        {isDataLoaded && interviewList?.length === 0 ? (
                                            <tr>
                                                <td className={styles.table_dataContents1} colSpan="13" style={{ textAlign: "center" }}>
                                                    <img src={Nomatchimg} alt="image" width={"190px"} height={"200px"} />
                                                </td>
                                            </tr>
                                        ) : (
                                            <>
                                                {isDataLoaded && interviewList?.filter(inter => {
                                                    for (const key in inter) {

                                                        if (Array.isArray(inter[key])) {

                                                            for (const item of inter[key]) {

                                                                if (typeof item === 'string' && item.toLowerCase().includes(searchTerm.toLowerCase())) {
                                                                    return true; // Return true if the search term is found in any array item
                                                                }
                                                            }
                                                        } else {
                                                            // If it's not an array, check if the property value contains the search term
                                                            if (inter[key] && typeof inter[key] === 'string' && inter[key].toLowerCase().includes(searchTerm.toLowerCase())) {
                                                                return true; // Return true if the search term is found in any field
                                                            }
                                                        }
                                                    }
                                                    return false; // Return false if the search term is not found in any field
                                                })?.map((data) => (
                                                    <tr className={styles.table_row} key={data._id}>
                                                        <td onClick={() => scheduleMeet(data)} className={styles.table_dataContents}><span className={styles.custom_link}>{data.MeetID || '-'}</span></td>
                                                        <td onClick={() => navigateTo(`/demand/editdemand?demand_id=${data?.demandObjID}`)} className={styles.table_dataContents}><span className={styles.custom_link}>{data.demand_id || '-'}</span></td>
                                                        <td onClick={() => navigateTo(`/candidatelibrary/editcandidate?candidate_id=${data?.candidateObjID}`)} className={styles.table_dataContents}><span className={styles.custom_link}>{data.candidate_id || '-'}</span></td>
                                                        <td className={styles.table_dataContents}>{data.candidate_name || '-'}</td>
                                                        <td className={styles.table_dataContents}>{data.mobile_no || '-'}</td>
                                                        <td className={styles.table_dataContents}>{data.candidate_email || '-'}</td>

                                                        <td onMouseEnter={() => setHoverCallout(data._id)} onMouseLeave={() => setHoverCallout('')}
                                                            id={`ME${data._id}`} className={styles.table_dataContents}>

                                                            {addEllipsisToName(data.interviewer_email.map((e) => (e.name)).join(", ") || '-')}

                                                            {(data.interviewer_email.length > 0 && data.interviewer_email.map((e) => (e.name)).join(", ").length >= 13 && hoverCallout === data._id) &&
                                                                <Callout alignTargetEdge={true}
                                                                    bounds={e => { console.log('log', e) }}
                                                                    isBeakVisible={false} styles={CalloutNameStyles}
                                                                    directionalHint={DirectionalHint.bottomLeftEdge}
                                                                    target={`#ME${data._id}`}>

                                                                    {data.interviewer_email.map((e) => (e.name))}
                                                                </Callout>
                                                            }
                                                        </td>


                                                        <td className={styles.table_dataContents}>{data.scheduled_by || '-'}</td>
                                                        <td className={styles.table_dataContents}>{data.company_name || '-'}</td>
                                                        <td className={styles.table_dataContents}>{ISOdateToCustomDate(data.startDateTime) || '-'}</td>
                                                        <td className={styles.table_dataContents}>{ISOdateToCustomTime(data.startDateTime) || '-'}</td>
                                                        <td className={styles.table_dataContents}>{data.duration || '-'}</td>
                                                        <td className={data.status === "Scheduled" ? styles.scheduled : data.status === "Completed" ?
                                                            styles.completed : data.status === "On Progress" ? styles.onProgress : data.status === "Cancelled" ?
                                                                styles.Cancelled : data.status === "Rescheduled" ? styles.Rescheduled : styles.statusStyle}>{data.status || '-'} </td>

                                                    </tr>
                                                ))}
                                            </>
                                        )}
                                        {!isDataLoaded && items.map(data => (
                                            <tr className={styles.table_row} >
                                                <td className={styles.table_dataContents}><Shimmer /></td>
                                                <td className={styles.table_dataContents}><Shimmer /></td>
                                                <td className={styles.table_dataContents}><Shimmer /></td>
                                                <td className={styles.table_dataContents}><Shimmer /></td>
                                                <td className={styles.table_dataContents}><Shimmer /></td>
                                                <td className={styles.table_dataContents}><Shimmer /></td>
                                                <td className={styles.table_dataContents}><Shimmer /></td>
                                                <td className={styles.table_dataContents}><Shimmer /></td>
                                                <td className={styles.table_dataContents}><Shimmer /></td>
                                                <td className={styles.table_dataContents}><Shimmer /></td>
                                                <td className={styles.table_dataContents}><Shimmer /></td>
                                                <td className={styles.table_dataContents}><Shimmer /></td>
                                                <td className={styles.table_dataContents}>
                                                    <div className={styles.moreOptions} >
                                                        <FontIcon iconName='MoreVertical' className={iconClass1} />
                                                    </div>
                                                </td>
                                            </tr>))}
                                    </>
                                )}
                            </tbody>
                        </table>
                    </InfiniteScroll>
                </div>
            </div>
        </div>
    );

};

export default InterviewListing;







