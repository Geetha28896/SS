import React from 'react'

const MyTarget = () => {
    return (
        <div>
            my target
        </div>
    )
}

export default MyTarget
