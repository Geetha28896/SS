import React, { useState, useCallback, useEffect } from 'react'
import styles from './InterviewModal.module.css'
import { DatePicker, Dropdown, Icon, Modal, PrimaryButton, TextField, TimePicker, TagPicker } from '@fluentui/react'
import videocamera from "../assets/video_camera.png"
import { graphConfig } from "../utils/authConfig";
import { axiosPrivateCall } from "../constants";
import { useSearchParams } from 'react-router-dom';
import { mergeStyles } from '@fluentui/react';

const textFieldColored = (props, currentHover, error, value) => {
    return {
        fieldGroup: {
            width: "294px",
            height: "33px",
            color: '#5B5F62',
            borderColor: "#E1E5E8",
            top: "5px",
            borderRadius: '3px',
            marginBottom: '10px',
            // '&:hover': {
            //     borderColor: "#E1E5E8",
            // }
        },
        field: {
            color: "#5B5F62",
            fontSize: '12px',
            borderColor: "#E1E5E8",
            lineHeight: '18px',
            input: {

                '&::placeholder': {
                    color: "rgba(179, 179, 179, 1)"
                }
            },

        },
    };
};
const tagPickerStyle = (props, currentHover, error, value) => {
    const borderColor = "#E1E5E8";
    const hoverBorderColor = "#E1E5E8"; // Same color for hover state

    return {
        text: {
            border: "1px solid #E1E5E8",
            selectors: {
                '&:hover': {
                    border: '1px solid rgb(96, 94, 92)',
                },
                '&:focus': {
                    border: '1px solid yellow',
                },
            },
        },
    }
};

const calendarClass = (props, currentHover, error, value) => {
    return {
        root: {

            "*": {
                width: "140px",
                fontSize: "12px !important",
                height: "27px !important",
                lineHeight: "25px !important",
                color: "#5B5F62",
                borderColor: '#E1E5E8',
                borderRadius:"3px",
                top: "3px",
                marginBottom: '10px',

                // borderColor: error
                //     ? "rgb(168,0,0)"
                //     : currentHover === value
                //         ? "rgb(50, 49, 48) !important "
                //         : "transparent !important",
                // selectors: {
                //     ":focus": {
                //         borderColor: "rgb(50, 49, 48)",
                //     },
                // },
            },
        },

        icon: { height: 10, width: 10, left: "85%", padding: "0px 0px", lineHeight: "22px !important", },
    };
};

const timePickerStyles = {
    root: {
        width: "140px",
        fontSize: "12px !important",
        height: "27px !important",
        lineHeight: "20px !important",
        color: "#5B5F62",
        borderColor: '#E1E5E8',
        top: "5px",
        maxWidth: "200px"

    },
    dropdown: {
        width: '250px', // Adjust the width as needed
    },
    input: {
        fontSize: '12px',
        color: "#5B5F62",
        selectors: {
            '&:hover': {
                borderColor: '#E1E5E8',
            },
            '&:focus': {
                borderColor: '#E1E5E8',
            },
            // width: "200px",
            borderColor: '#E1E5E8',
        },
    },
    pickerInput: {
        selectors: {
            '.ms-Callout.ms-ComboBox-callout': {
                width: '200px', // Adjust the width of the dropdown
            },
        },
    },
    icon: {
        width: "100px",
        // color: 'red', // Set the icon color
    },

};
const pickerCalloutStyles = {
    root: {
        width: '300px',
        minHeight: '200px',

    }
};


const timePickerStyles1 = {
    root: {
        width: "140px",
        maxWidth: "150px",
        fontSize: "12px !important",
        height: "27px !important",
        lineHeight: "20px !important",
        color: "rgba(179, 179, 179, 1)",
        borderColor: 'rgba(179, 179, 179, 1)',
    },
    input: {
        // fontSize: '16px', 
        // color: 'blue',
        selectors: {
            '&:hover': {
                borderColor: 'rgba(179, 179, 179, 1)',
            },
            '&:focus': {
                borderColor: 'rgba(179, 179, 179, 1)',
            },
            width: "100px",
            borderColor: 'rgba(179, 179, 179, 1)',
        },
    },
    icon: {
        width: "100px"
        // color: 'red', // Set the icon color
    },
    pickerItems: {
        width: "120px"
    },
    dropdown: {
        '& .ms-Dropdown': {
            width: '100px', // Adjust the width as needed
            height: '100px', // Adjust the height as needed
        },
    },
};

const textFieldColored1 = (props, currentHover, error, value) => {
    const borderColor = "#E1E5E8";
    const hoverBorderColor = "#E1E5E8"; // Same color for hover state

    return {
        text: {
            border: "1px solid #E1E5E8",
            borderRadius:"3px",
            width:"295px",
            selectors: {
                '&:hover': {
                    border: '1px solid rgb(96, 94, 92)',
                },
                '&:focus': {
                    border: '1px solid yellow',
                },
            },
        },
    }
};
const dropDownStylesActive = (props, currentHover, error, value) => {
    return {
        dropdown: {
            width: "145px",
            minWidth: "140px",
            minHeight: "27px",
            top: "5px",
            color: "#5B5F62",
            borderColor: error ? "#a80000" : "#E1E5E8",
            marginBottom: "10px",
            selectors: {
                ":focus": {
                    borderColor: "#E1E5E8",
                },
                ":hover": {
                    borderColor: "#E1E5E8 !important",
                },
            },
        },
        dropdownItemsWrapper:{
            height:"100px"
          },
        title: {
            height: "27px",
            lineHeight: "25px",
            fontSize: "12px",
            color: "#5B5F62",
            borderColor: '#E1E5E8',
            borderRadius:"3px",
            //     borderColor: error
            //         ? "#a80000"
            //         : currentHover === value
            //             ? "rgb(96, 94, 92)"
            //             : "transparent",
        },

        caretDownWrapper: { height: "22px", lineHeight: "25px !important" },
        dropdownItem: { minHeight: "20px", fontSize: 12 },
        dropdownItemSelected: { minHeight: "22px", fontSize: 12 },
    };
};


const durationOptions = [
    { key: '00.15.00', text: '0.15 mins' },
    { key: '00.30.00', text: '0.30 mins' },
    { key: '00.45.00', text: '0.45 mins' },
    { key: '01.00.00', text: '1.00 hours' },
    { key: '01.15.00', text: '1.15 hours' },
    { key: '01.30.00', text: '1.30 hours' },
    { key: '01.45.00', text: '1.45 hours' },
    { key: '02.00.00', text: '2.00 hours' },

]


const InterviewSchedule = (props) => {
    let showPopup = props.showPopup;
    let setShowPopup = props.setShowPopup;
    let candidateObj = props.basicInfo
    let candidateId = props.candidate_Id
    let demand_id = props.demandId
    let { showMessageBar, setShowMessageBar } = props;
    let employmentDetails = props.employmentDetails
    let title_role = employmentDetails.map(role => role.job_role)
    const title = (candidateObj?.first_name + " " + title_role + "interview 001" + demand_id)
    const company_name = employmentDetails.map(client => client.company_name).join(", ");
    const [selectedTags, setSelectedTags] = useState([]);
    const [searchParams, setSearchParams] = useSearchParams();
    const submission_id = searchParams.get("submission_id")

    const [meetobjValue, setMeetObjValue] = useState({
        demand_id: "",
        submission_id: "",
        candidate_id: "",
        candidateObjID: "",
        demandObjID: "",
        mobile_no: "",
        candidate_email: "",
        candidate_name: "",
        interviewer_email: [],
        company_name: "",
        duration: "",
        status: "",
        title: "",
        schedule_meet_id: "",
        passcode: "",
        meet_url: "",
        startDateTime: new Date().toISOString(),
        event_id: "",
        scheduled_by: "",
    })
    useEffect(() => {
        const interviewerEmail = selectedTags;
        setMeetObjValue((prevState) => ({
            ...prevState,
            interviewer_email: interviewerEmail,
        }));
    }, [selectedTags]);


    const [userList, setUserList] = useState(null);

    const [tempInputValue, setTempInputValue] = useState("");
    const [borderWidth, setBorderWidth] = useState(329);

    const handleInputChange = (newValue) => {
        if (newValue === "") {
            setUserList([]);
        }
        setTempInputValue(newValue);
        setSelectedTags((prevTags) =>
            prevTags.map((tag) => ({ ...tag }))
        );

    };

    const updateDateTime = (selectedDate, selectedTime) => {

        const combinedDateTime = new Date(
            Date.UTC(
                selectedDate.getFullYear(),
                selectedDate.getMonth(),
                selectedDate.getDate(),
                selectedTime.getHours(),
                selectedTime.getMinutes(),
                selectedTime.getSeconds()
            )
        );

        // Convert the combined date and time to ISO 8601 format
        const isoDateTime = combinedDateTime.toISOString();
        setMeetObjValue(prevState => ({
            ...prevState,
            startDateTime: isoDateTime
        }));
    };


    const handleTabKeyPress = (event) => {
        if ((event.key === "Tab" || event.key === ",") && tempInputValue !== "") {
            event.preventDefault();
            const tags = tempInputValue
                .split(",")
                .map((tag) => tag.trim())
                .filter((tag) => tag !== "");
            if (tags.length > 0) {
                const newTags = tags.map((tag) => ({ key: tag, name: tag }));
                setSelectedTags([...selectedTags, ...newTags]);
            }
            setTempInputValue("");
        }
    };

    const contactAutocomplete = async (keys) => {
        const headers = new Headers();
        const bearer = localStorage.getItem("accessToken");
        if (!keys) {
            console.log("Empty keys provided");
            return null;
        }

        if (!bearer) {
            throw new Error("Bearer token is missing");
        }

        headers.append("Authorization", `Bearer ${bearer}`);
        headers.append("Content-Type", "application/json");

        try {
            const response = await fetch(`https://graph.microsoft.com/v1.0/myorganization/users?$filter=(accountEnabled eq true) and (userType eq 'Guest') and
    (startswith(displayName, '${keys}') or startswith(givenName, '${keys}') or startswith(surname, '${keys}') or startswith(mail, '${keys}') or startswith(userPrincipalName, '${keys}'))&$top=20`, {
                headers: headers,
            });

            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }

            const listContact = await response.json();
            if (listContact.value && Array.isArray(listContact.value)) {
                // const emails = listContact.value.map(contact => contact.mail); 22/02/24,02:57pm
                const emails = listContact.value.map(contact => ({
                    email: contact.mail,
                    displayName: contact.displayName
                }))
                setUserList(emails); // Update the state with the array of emails
                return emails;
            }
            return listContact;
        } catch (err) {
            console.error("Error fetching contacts:", err);
            throw err;
        }
    };

    const autoCompletework = useCallback(async () => {
        try {
            if (selectedTags !== null) {
                const res = await contactAutocomplete(tempInputValue);
                if (res.value !== null) {
                    const maxWidth = Math.max(...res.value.map(email => email.length), 0);
                    const calculatedWidth = Math.max(329, maxWidth * 8);
                    setBorderWidth(calculatedWidth);
                } else {
                    setBorderWidth(329);

                }
            }
        } catch (error) {
            console.log("Error fetching contact autocomplete:", error);
        }
    }, [selectedTags, tempInputValue])

    useEffect(() => {
        if (tempInputValue === "") {
            setUserList([]);
        } else {
            autoCompletework();
        }
    }, [tempInputValue, autoCompletework]);

    useEffect(() => {
        let first_name = localStorage.getItem('first_name');
        if (candidateObj) {
            setMeetObjValue(prevState => ({
                ...prevState,
                demand_id: demand_id,
                candidateObjID: candidateId,
                demandObjID: candidateObj.demand_id,
                submission_id: submission_id,
                title: title,
                candidate_email: candidateObj?.email,
                candidate_name: candidateObj?.first_name,
                candidate_id: candidateObj.CandidateId,
                mobile_no: candidateObj.mobile_number,
                company_name: company_name,
                scheduled_by: first_name
            }));
        }

    }, [candidateObj, company_name, demand_id, submission_id, title]);

    useEffect(() => {
        autoCompletework();
    }, [selectedTags, autoCompletework]);


    const submitHandler = async () => {
        const startDateTime = new Date(meetobjValue.startDateTime.replace("Z", ""));
        const durationMilliseconds = parseFloat(meetobjValue.duration) * 60 * 60 * 1000;
        const endDateTime = new Date(startDateTime.getTime() + durationMilliseconds);
        const accessToken = localStorage.getItem('accessToken');

        const headers = new Headers();
        const bearer = `Bearer ${accessToken}`;

        headers.append("Authorization", bearer);
        headers.append("Content-Type", "application/json");

        const attendees = selectedTags.map(interviewer => ({
            emailAddress: {
                address: interviewer.name,
                name: interviewer.key
            },
            "type": "required"
        }));
        attendees.push({
            emailAddress: {
                address: meetobjValue.candidate_email,
                name: meetobjValue.candidate_name
            },
            "type": "required"
        });
        const joinLnk = "https://www.microsoft.com/en-in/microsoft-teams/join-a-meeting"
        const eventObject = {
            subject: meetobjValue.title,
            start: {
                dateTime: startDateTime.toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }),
                timeZone: "Asia/Kolkata"
            },
            end: {
                dateTime: endDateTime.toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }),
                timeZone: "Asia/Kolkata"
            },
            body: {
                contentType: "HTML",
                content: `<h1>Sight Spectrum Call</h1><br><a href=${joinLnk}><button style="background-color: blue; color: white; padding: 10px 20px; font-size: 16px;">Join Now</button></a>`
            },
            attendees: attendees,

            allowNewTimeProposals: true,
            isOnlineMeeting: true,
            onlineMeetingProvider: "teamsForBusiness"
        };

        const options = {
            method: "POST",
            headers: headers,
            body: JSON.stringify(
                eventObject,
            ),
        };

        try {
            const response = await fetch(graphConfig.graphCalendarEvents, options);
            const eventResponse = await response.json();
            let htmlContent = eventResponse.body.content;
            const eventId = eventResponse.id;

            let meetingID=null;
            let passCode=null;          
           
            const parser = new DOMParser();
            const doc = parser.parseFromString(htmlContent, 'text/html');          
            
            const passcodeElement = doc.querySelector('span[style="font-size:14px; color:#252424"] + span[style="font-size:16px; color:#252424"]');
           
            if(passcodeElement){
            
                    passCode = passcodeElement.textContent.trim();
                    const meetingIdSpan = doc.querySelector('span[data-tid="meeting-code"] span');
                    meetingID = meetingIdSpan.textContent.trim();                    
            }else{                
                    const meetingIdElement = Array.from(doc.querySelectorAll('.me-email-text-secondary')).find(element => {
                        return element.textContent.includes('Meeting ID:');
                        });
                        meetingID = meetingIdElement.nextElementSibling.textContent.trim();
        
                        const passcodeElement = Array.from(doc.querySelectorAll('.me-email-text-secondary')).find(element => {
                            return element.textContent.includes('Passcode:');
                        });
                        passCode = passcodeElement.nextElementSibling.textContent.trim();                             
                
            }
            
            await axiosPrivateCall.post("/api/v1/interview/scheduleMeet", {
                ...meetobjValue,
                meet_url: joinLnk,
                event_id: eventId,
                schedule_meet_id: meetingID,
                passcode: passCode,
                status: 'Scheduled' // Assuming you want to update the status here
            });
            setShowPopup(!showPopup);
            setShowMessageBar(!showMessageBar);

        } catch (error) {
            console.error("Error creating event:", error);
        }
    }

    const onTagChange = async (items) => {
        setSelectedTags(items);
        const selectedInterviewerEmails = items.map((interviewer) => interviewer.name);

        const interviewerEmailString = selectedInterviewerEmails.join(', ');
        setMeetObjValue(prevState => ({
            ...prevState,
            interviewer_email: interviewerEmailString
        }));

        await autoCompletework();
    };

    const onResolveSuggestions = async (filterText, tagPickerSuggestionsProps) => {
        // Use the userList state to provide suggestions
        const filteredSuggestions = userList ? userList.filter(email => email.includes(filterText)) : [];
        return filteredSuggestions.map((suggestion) => ({
            key: suggestion,
            text: suggestion,
        }));
    };

    const handleMap = (item) => {
        const { email, displayName } = item.item;
        const tags = email
            .split(",")
            .map((tag) => tag.trim())
            .filter((tag) => tag !== "");
        if (tags.length > 0) {
            const newTags = tags.map((tag) => ({ key: displayName, name: tag }));
            setSelectedTags([...selectedTags, ...newTags]);
        }
        setTempInputValue("");
    };

    const handleGetText = (item) => {
        return item.key
    }

    const generateTimeOptions = () => {
        const options = [];
        for (let hour = 0; hour < 24; hour++) {
            for (let minute = 0; minute < 60; minute += 15) {
                const hourString = hour.toString().padStart(2, '0');
                const minuteString = minute.toString().padStart(2, '0');
                const key = `${hourString}.${minuteString}.00`;
                const text = `${hourString}:${minuteString}`;
                options.push({ key, text });
            }
        }
        return options;
    };

    const durationOptions1 = generateTimeOptions();
    const findKeyByTime = (dateTimeString) => {
        const date = new Date(dateTimeString);
        const hours = date.getHours();
        const minutes = date.getMinutes();
        const formattedTime = `${hours.toString().padStart(2, '0')}.${minutes.toString().padStart(2, '0')}.00`;

        // Find the option with the matching text
        const matchingOption = durationOptions1.find(option => option.key === formattedTime);
        return matchingOption ? matchingOption.key : null;
    };

    const updateIsoTime = (selectedDate, selectedTime) => {
        const timeParts = selectedTime.key.split('.');
        const hours = parseInt(timeParts[0]);
        const minutes = parseInt(timeParts[1]);

        // Combine the selected date with the extracted time
        const isoDateTime = new Date(
            Date.UTC(
                selectedDate.getFullYear(),
                selectedDate.getMonth(),
                selectedDate.getDate(),
                hours,
                minutes,
                0 // Set seconds to 0
            )).toISOString();
        setMeetObjValue(prevState => ({
            ...prevState,
            startDateTime: isoDateTime
        }));
    }

    return (
        <div>
            <Modal isOpen={showPopup} container >

                <div className={styles.border}
                    style={{ width: `${borderWidth}px` }}
                >
                    <div className={styles.main_container}>

                        <div className={styles.chromeclose1} onClick={() => setShowPopup(!showPopup)}><Icon title='Delete all uploaded documents'
                            iconName='ChromeClose'

                        /></div>
                        <div className={styles.sub_container}>
                            <span className={styles.sub_title}>Interview Title</span>
                            <TextField readOnly
                                type="text"
                                name="title"
                                placeholder="Interview Title"
                                styles={textFieldColored}
                                // onChange={(e) => {
                                //     inputChangeHandler(e, "title");
                                // }}
                                value={meetobjValue.title}

                            />


                        </div>
                        <div className={styles.sub_container}>
                            <span className={styles.sub_title} >Start Time</span>
                            <div className={styles.start_time}>
                                <DatePicker
                                    value={new Date(meetobjValue.startDateTime.replace("Z", ""))}
                                    onSelectDate={(selectedDate) => updateDateTime(selectedDate, new Date(meetobjValue.startDateTime.replace("Z", "")))}
                                    ariaLabel="Date picker"
                                    placeholder="DD/MM/YYYY"
                                    styles={calendarClass}
                                />
                                {/* <TimePicker
                                    placeholder="Select a time"
                                    dateAnchor={new Date(meetobjValue.startDateTime)}
                                    value={new Date(meetobjValue.startDateTime.replace("Z",""))}
                                    onChange={(_ev, date) => updateIsoTime(new Date(meetobjValue.startDateTime.replace("Z","")), date)}
                                    styles={timePickerStyles1}
                                    ariaLabel="Time picker"
                                    // className={styles.SchtimePickerStyles}
                                /> */}
                                <Dropdown
                                    placeholder="Select"
                                    options={durationOptions1}
                                    selectedKey={findKeyByTime(meetobjValue.startDateTime.replace("Z", ""))}
                                    onChange={(_ev, date) => updateIsoTime(new Date(meetobjValue.startDateTime.replace("Z", "")), date)}
                                    styles={dropDownStylesActive}
                                />

                            </div >
                            <div className={styles.sub_container}>
                                <span className={styles.sub_title}>Duration</span>
                                <Dropdown
                                    placeholder="Select"
                                    options={durationOptions}
                                    onChange={(e, item) => setMeetObjValue(prevState => ({ ...prevState, duration: item.key }))}
                                    styles={dropDownStylesActive}
                                />

                            </div>

                            <div className={styles.sub_container}>
                                <span className={styles.sub_title}>Candidate</span>
                                <TextField readOnly
                                    type="text"
                                    name="email"
                                    placeholder="Enter the mail ID"
                                    styles={textFieldColored}
                                    // onChange={(e) => {
                                    //     inputChangeHandler(e, "email");
                                    // }}
                                    value={meetobjValue.candidate_email}

                                />

                            </div>

                            <div className={styles.sub_container}>
                                <span className={styles.sub_title}>Add Interviewer</span>

                                <TagPicker
                                    removeButtonAriaLabel="Remove"
                                    onResolveSuggestions={onResolveSuggestions}
                                    getTextFromItem={handleGetText}
                                    selectedItems={selectedTags}
                                    onChange={onTagChange}
                                    onInputChange={handleInputChange}
                                    inputProps={{
                                        placeholder:
                                            selectedTags.length > 0
                                                ? "Enter another Mail ID"
                                                : "Enter the Mail ID",
                                        className: styles.inputContainerWithTags,
                                        onKeyDown: handleTabKeyPress,
                                        value: tempInputValue,

                                    }}
                                    // styles={{
                                    //     root: {
                                    //      backgroundColor:"white",
                                    //     },

                                    //   text:{
                                    //     border:"1px solid #E1E5E8",
                                    //   },

                                    //   }}
                                    styles={textFieldColored1}
                                    autoComplete="on"
                                // onRenderItem={(props) => (
                                //     <span className={styles.pickerSelectedTag}>
                                //         {props.item.name}
                                //     </span>
                                // )}
                                />
                                <div className={styles.dropdown_container}>
                                    {userList?.map?.((item, index) => (
                                        <div
                                            key={`${item}-${index}`}
                                            onClick={() => handleMap({ item })}
                                            className={styles.dropdown_option}
                                        >
                                            <div className={styles.popUpItems}>{item.email}</div>
                                        </div>
                                    ))}
                                </div>
                            </div>

                            <div className={styles.schedule_button}>
                                <PrimaryButton text={`Schedule`}
                                    onClick={submitHandler}
                                    className={styles.sechduleButton}
                                    iconProps={{ imageProps: { src: videocamera }, style: { marginTop: "5px" } }}

                                />

                            </div>

                        </div >

                    </div >
                </div >
            </Modal >
        </div >
    )
}

export default InterviewSchedule