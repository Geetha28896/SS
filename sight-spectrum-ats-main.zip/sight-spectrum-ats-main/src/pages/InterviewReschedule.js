import React, { useState, useCallback, useEffect } from 'react'
import styles from './InterviewModal.module.css'
import { DatePicker, Dropdown, Icon, Modal, PrimaryButton, TextField, TimePicker, ComboBox, TagPicker } from '@fluentui/react'
import videocamera from "../assets/video_camera.png"
import { axiosPrivateCall, axiosPublicCall } from "../constants";
import { useNavigate } from 'react-router-dom';
import { useMsal } from '@azure/msal-react';
import { loginRequest } from '../utils/authConfig';


const textFieldColored = (props, currentHover, error, value) => {
    const borderColor = "#E1E5E8";
    const hoverBorderColor = "#E1E5E8"; // Same color for hover state

    return {
        fieldGroup: {
            width: "365px",
            height: "33px",
            color: '#5B5F62',
            top: "5px",
            borderColor: borderColor,
            borderRadius: "3px",
            marginBottom: '10px',
            '&:hover': {
                borderColor: hoverBorderColor,
            }
        },
        field: {
            color: "#5B5F62",
            fontSize: 12,
            input: {
                color: "#5B5F62",
                '&::placeholder': {
                    color: "#5B5F62"
                }
            },
        },
    };
};

const textFieldColored1 = (props, currentHover, error, value) => {
    const borderColor = "#E1E5E8";
    const hoverBorderColor = "#E1E5E8";
    return {
        fieldGroup: {
            width: "175px",
            height: "33px",
            color: '#5B5F62',
            top: "5px",
            marginBottom: '10px',
            borderColor: borderColor,
            borderRadius: "3px",
            '&:hover': {
                borderColor: hoverBorderColor,
            }
        },
        field: {
            color: "#5B5F62",
            fontSize: 12,
            input: {
                color: "red",
                '&::placeholder': {
                    color: "#5B5F62"
                }
            },

        },
    };
};

const textFieldColored2 = (props, currentHover, error, value) => {
    const borderColor = "#E1E5E8";
    const hoverBorderColor = "#E1E5E8";
    return {
        fieldGroup: {
            width: "180px",
            height: "33px",
            color: '#5B5F62',
            top: "5px",
            marginBottom: '10px',
            borderColor: borderColor,
            borderRadius: "3px",
            '&:hover': {
                borderColor: hoverBorderColor,
            }
        },
        field: {
            color: "#5B5F62",
            fontSize: 12,
            textAlign: 'center',
            input: {
                color: "red",
                '&::placeholder': {
                    color: "#5B5F62"
                },
            },

        },
    };
};
const iconStyle = {
    marginTop: "3px"
}

const InterviewReschedule = (props) => {
    const { showPopup1, setShowPopup1, meetObj,
        setCancelPop, cancelPop, setReScheduleValue } = props;
    console.log(meetObj)
    const [showPopup, setShowPopup] = useState(false)
    const navigateTo = useNavigate();
    const { instance, accounts } = useMsal();

    const ISOdateToCustomDate = (value) => {
        const dateFormat = new Date(value);
        let year = dateFormat.getUTCFullYear();
        let month = dateFormat.getUTCMonth() + 1;
        let date = dateFormat.getUTCDate();

        if (date < 10) {
            date = '0' + date;
        }
        if (month < 10) {
            month = '0' + month;
        }
        return date + '/' + month + '/' + year;
    }
    const ISOdateToCustomTime = (value) => {
        const date = new Date(value);
        const hours = date.getUTCHours();
        const minutes = date.getUTCMinutes();
        const period = hours >= 12 ? "pm" : "am";
        const formattedHours = hours % 12 || 12;
        const timeString = `${formattedHours}:${minutes < 10 ? '0' : ''}${minutes} ${period}`;
        return timeString;
    }
    // const splitDateTime = () => {
    //     const date = ISOdateToCustomDate(meetobjValue.startDateTime);
    //     const time = ISOdateToCustomTime(meetobjValue.startDateTime);
    //     setStartDate(date);
    //     setStartTime(time);
    // };

    // useEffect(() => {
    //     splitDateTime();
    // }, []);
    const [meetobjValue, setMeetObjValue] = useState({
        demand_id: "",
        candidate_id: "",
        mobile_no: "",
        candidate_email: "",
        candidate_name: "",
        interviewer_email: [],
        company_name: "",
        status: "",
        title: "",
        schedule_meet_id: "",
        scheduled_by: "",
        passcode: "",
        meet_url: "",
        duration: "",
        startDateTime: new Date().toISOString(),
        event_id: "",
        submission_id: "",
    })
    const [copyText, setCopyText] = useState('Copy')
    const copyToClipboard = (...texts) => {
        const textToCopy = texts.join('\n');
        navigator.clipboard.writeText(textToCopy);
        setCopyText("Copied")
        setTimeout(() => {
            setCopyText("Copy")
        }, 3000)
    };
    const durationOptions = [
        { key: '00.15.00', text: '0.15 mins' },
        { key: '00.30.00', text: '0.30 mins' },
        { key: '00.45.00', text: '0.45 mins' },
        { key: '01.00.00', text: '1.00 hour' },
        { key: '01.15.00', text: '1.15 hours' },
        { key: '01.30.00', text: '1.30 hours' },
        { key: '01.45.00', text: '1.45 hours' },
        { key: '02.00.00', text: '2.00 hours' },
    ];

    const rescheduleDuration = durationOptions.find(option => option.key === meetobjValue.duration);

    useEffect(() => {

        if (meetObj) {
            setMeetObjValue(prevState => ({
                ...prevState,
                demand_id: meetObj.demand_id,
                schedule_meet_id: meetObj.schedule_meet_id,
                passcode: meetObj.passcode,
                meet_url: meetObj.meet_url,
                candidate_id: meetObj.candidate_id,
                mobile_no: meetObj.mobile_no,
                candidate_email: meetObj.candidate_email,
                candidate_name: meetObj.candidate_name,
                interviewer_email: meetObj.interviewer_email,
                company_name: meetObj.company_name,
                duration: meetObj.duration,
                status: meetObj.status,
                title: meetObj.title,
                startDateTime: meetObj.startDateTime,
                event_id: meetObj.event_id,
                scheduled_by: meetObj.scheduled_by,
                submission_id: meetObj.submission_id
            }));
        }

    }, [meetObj]);

    const rescheduleMeet = async () => {
        try {
            const request = {
                scopes: ["User.ReadWrite.All", "Mail.Send", "Calendars.ReadWrite"],
                account: accounts[0],
            };
            const loginResponse = await instance.loginPopup(loginRequest);

            const tokenResponse = await instance.acquireTokenSilent({
                ...request,
                account: loginResponse.account,
            });
            const accessToken = tokenResponse.accessToken;
            localStorage.setItem('accessToken', accessToken);
            const meetObjJson = encodeURIComponent(JSON.stringify(meetObj));
            navigateTo(`/submission/viewsubmission?submission_id=${meetObj?.submission_id}&showPopup1=true&meetObj=${meetObjJson}`)
        } catch (err) {
            throw err;
        }

    }

    const deleteEvent = () => {
        navigateTo(`/Interview/InterviewListing`, { state: { meetObj } })
        setCancelPop(!cancelPop)
        setShowPopup1(!showPopup1)
        setReScheduleValue(meetObj)
    }
    return (
        <div>

            <Modal isOpen={showPopup1} containerClassName={styles.main_PopUp_Container}>
                <div className={styles.border} >
                    <div className={styles.main_container}>

                        <div className={styles.chromeclose} onClick={() => setShowPopup1(!showPopup1)}><Icon title='Delete all uploaded documents'
                            iconName='ChromeClose'

                        /></div>



                        <div className={styles.sub_container}>
                            <span className={styles.sub_title}>Interview Title</span>
                            <TextField
                                type="text"
                                name="title"
                                placeholder="Interview Title"
                                styles={textFieldColored}
                                value={meetobjValue.title}
                            />
                        </div>
                        <div className={styles.sub_container}>
                            <span className={styles.sub_title}>Start Time</span>
                            <div className={styles.start_time}>

                                <TextField
                                    type="text"
                                    name="title"
                                    placeholder="Interview Title"
                                    styles={textFieldColored1}
                                    value={ISOdateToCustomDate(meetobjValue.startDateTime)}

                                />
                                <TextField
                                    type="text"
                                    name="title"
                                    placeholder="Interview Title"
                                    styles={textFieldColored2}
                                    value={ISOdateToCustomTime(meetobjValue.startDateTime)}
                                />
                            </div>
                            <div className={styles.sub_container}>
                                <span className={styles.sub_title}>Duration</span>
                                <TextField
                                    type="text"
                                    name="title"
                                    placeholder="Interview Title"
                                    styles={textFieldColored1}
                                    value={rescheduleDuration?.text}
                                />
                            </div>


                            <div className={styles.sub_container}>
                                <span className={styles.sub_title_}>Participants</span>
                                <div className={styles.participant_list}>
                                    <div className={styles.participant}>
                                        <span>Recruiter&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-</span>
                                        <span>&nbsp;{meetobjValue.scheduled_by}</span>
                                    </div>
                                    <div className={styles.participant}>
                                        <span>Candidate&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-</span>
                                        <span>&nbsp;{meetobjValue.candidate_name} <span style={{ color: '#909090' }}>({meetobjValue.candidate_email})</span></span>
                                    </div>
                                    <div className={styles.participantEmailBlock}>
                                        <div className={styles.participantNames}>
                                            <span>Interviewer&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-</span>
                                        </div>
                                        <div className={styles.participantMail}>
                                            <span> {meetobjValue.interviewer_email.map(participant => (
                                                <span key={participant.name}>
                                                    <div className={styles.participantNameValue}>
                                                        {`${participant.key} `}
                                                        <span style={{ color: '#909090' }}>({participant.name})</span>
                                                    </div>
                                                </span>
                                            ))}</span>
                                        </div>
                                    </div>
                                </div>

                            </div>


                            <div className={styles.sub_container}>

                                <span className={styles.sub_title}>Meeting Details</span>
                                <div className={styles.meeting_details}>
                                    <div className={styles.detail_row}>
                                        <span className={styles.copy_icon}
                                            onClick={() => copyToClipboard(meetobjValue.schedule_meet_id, meetobjValue.passcode, meetobjValue.meet_url)}
                                        >
                                            <Icon
                                                iconName="Copy"
                                                title="Copy"
                                            />{copyText}</span>

                                        <span className={styles.meet_title}>Meeting ID&nbsp;:</span>
                                        <span className={styles.meet_value}>&nbsp;{meetobjValue.schedule_meet_id}</span>

                                    </div>
                                    <div className={styles.detail_row}>
                                        <span className={styles.meet_title}>Passcode&nbsp;:</span>
                                        <span className={styles.meet_value}>&nbsp;&nbsp;&nbsp;&nbsp;{meetobjValue.passcode}</span>

                                    </div>
                                    <div className={styles.detail_rows}>
                                        <span className={styles.meet_titles}>URL&nbsp;:</span>
                                        <span className={styles.meet_urls}>{meetobjValue.meet_url}</span>

                                    </div>
                                </div>
                            </div>

                            <div className={styles.schedule_button}>

                                <div className={styles.cancel_meet}>
                                    <button className={styles.cancel_btn} onClick={() => deleteEvent()}>Cancel</button>
                                </div>
                                <div>
                                    <PrimaryButton text={`Reschedule`}
                                        className={styles.reschedule_btn}
                                        onClick={rescheduleMeet}
                                        iconProps={{ imageProps: { src: videocamera }, style: { marginTop: "5px" } }}
                                    />
                                </div>
                            </div >

                        </div >

                    </div >
                </div >
            </Modal >
        </div >
    )
}

export default InterviewReschedule