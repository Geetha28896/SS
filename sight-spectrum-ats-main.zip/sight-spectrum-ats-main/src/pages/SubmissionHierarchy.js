import React, { useState, useEffect, useCallback, useRef } from "react";
import { Label, Modal } from "@fluentui/react";
import styles from "./HierarchyView.module.css";
import { Icon } from "@fluentui/react/lib/Icon";
import { mergeStyles, mergeStyleSets } from "@fluentui/react";
import { axiosPrivateCall } from "../constants";
import { Dropdown } from "@fluentui/react/lib/Dropdown";
import { debounce } from "lodash";
import { Spinner, SpinnerSize } from "@fluentui/react";

const contractIconClass = mergeStyles({
  fontSize: 20,
  height: "20px",
  width: "20px",
  cursor: "pointer",
});

const closeIconClass = mergeStyles({
  fontSize: 16,
  height: "20px",
  width: "20px",
  cursor: "pointer",
});

const DropdownStyles = (props, currentHover, error, value) => {
  const hoverBorderColor = "#F9FBFF";
  let titleColor = "#D7D7D7";
  if (!value) {
    titleColor = error ? "#D24545" : "#D7D7D7";
  }
  return {
    title: {
      height: "21px",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      color: "#7A7A7A",
      fontSize: "12px",
      background: "#F9FBFF",
      border: "1px solid #F9FBFF",
    },
    dropdown: {
      selectors: {
        ".ms-Dropdown-title, .ms-Dropdown-caretDownWrapper": {
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          height: "21px",
        },
        ".ms-Dropdown-title:hover, .ms-Dropdown-caretDownWrapper:hover": {
          borderColor: hoverBorderColor,
        },
      },
    },
  };
};

const options = [
  { key: "day", text: "Day" },
  { key: "week", text: "Week" },
  { key: "month", text: "Month" },
  { key: "year", text: "Year" },
  { key: "tilltime", text: "Till time" },
];

const SubmissionHierarchy = (props) => {
  const [history, setHistory] = useState([]);
  const [isModalShrunk, setIsModalShrunk] = useState(false);
  const [loading, setLoading] = useState(false);
  const { isModalOpen, setIsModalOpen, showMessageBar, setShowMessageBar, startDate, endDate } = props;
  const [overallSubmission, setOverallSubmission] = useState([]);
  const [initialData, setInitialData] = useState([]);
  const [empCount, setEmpCount] = useState([]);
  const [dropdownFilter, setDropdownFilter] = useState("");
  const [role, setRole] = useState("");
  const [indSearch, setIndSearch] = useState(false);
  const [id, setId] = useState("");
  const [AMCache, setAMCache] = useState([]);
  const [TLCache, setTLCache] = useState([]);
  const [RecCache, setRecCache] = useState([]);
  const token = localStorage.getItem("token");
  let base64Url = token.split(".")[1];
  let decodedValue = JSON.parse(window.atob(base64Url));
  const user_id = decodedValue.user_id;

  const modalSizeHandler = () => {
    setIsModalShrunk(!isModalShrunk);
  };

  const handlePopupClose = () => {
    setIsModalOpen(!isModalOpen);
  };

  useEffect(() => {
    const token = localStorage.getItem("token");
    let base64Url = token.split(".")[1];
    let decodedValue = JSON.parse(window.atob(base64Url));
    const userRole = decodedValue.user_role;

    switch (userRole) {
      case "admin":
        setRole("account_manager");
        break;
      case "account_manager":
        setRole("team_lead");
        break;
      case "team_lead":
        setRole("recruiter");
        break;
      default:
        setRole("");
        break;
    }
  }, []);

  useEffect(() => {
    getOverallSubmission();
  }, []);

  const capitalizeRole = (role) => {
    if (!role) return "";

    if (role.includes("_")) {
      return role
        .split("_")
        .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
        .join(" ");
    }
    return role.charAt(0).toUpperCase() + role.slice(1);
  };

  const updateHistory = (data) => {
    console.log(data, "data");
    setHistory((prevHistory) => [...prevHistory, data]);
  };

  const handleBackButton = () => {
    if (history.length > 1) {
      const previousState = history[history.length - 2];
      setHistory(history.slice(0, -1));
      setOverallSubmission(previousState);
      const newEmpCount = previousState.length;
      setEmpCount(newEmpCount);
      setId("");
    } else {
      setHistory([]);
      setOverallSubmission(initialData);
      setId("");
      const newEmpCount = initialData.length;
      setEmpCount(newEmpCount);
    }
  };

  const getOverallSubmission = debounce((select) => {
    const token = localStorage.getItem("token");
    let base64Url = token.split(".")[1];
    let decodedValue = JSON.parse(window.atob(base64Url));
    const user_id = decodedValue.user_id;
    setOverallSubmission([]);
    axiosPrivateCall
      .get(`/api/v1/aggregate/getIndividualHierarchy?user_id=${user_id}&timeRange=${select}`)
      .then((res) => {
        setOverallSubmission(res.data.data.employeeSubmissions);
        setEmpCount(res.data.data.employeCount);
        setRole(res.data.data.employeeSubmissions[0].employee.role);
        updateHistory(res.data.data.employeeSubmissions);
        setInitialData(res.data.data.employeeSubmissions);
        switch (role) {
          case "account_manager":
            if (AMCache.length > 0) {
              setAMCache(res.data.data.employeeSubmissions);
              break;
            } else {
              setAMCache(res.data.data.employeeSubmissions);
            }
            break;
          case "team_lead":
            if (TLCache.length > 0) {
              setTLCache(res.data.data.employeeSubmissions);
              break;
            } else {
              setTLCache(res.data.data.employeeSubmissions);
            }
            break;
          case "recruiter":
            if (RecCache.length > 0) {
              break;
            } else {
              setRecCache(res.data.data.employeeSubmissions);
            }
            break;
          default:
            break;
        }
      })
      .catch((err) => {
        console.log(err);
      })
      .finally(() => {
        setTimeout(() => {
          setLoading(false);
        }, 1000);
      });
  }, 300);

  const [aaa, getdataKey] = useState("");

  const getIndividualHierarchy = (select) => {
    setLoading(true);
    axiosPrivateCall
      .get(`/api/v1/aggregate/getIndividualHierarchy?user_id=${id}&timeRange=${select}`)
      .then((res) => {
        const employeeSubmissions = res.data.data.employeeSubmissions;
        setOverallSubmission(employeeSubmissions);
        setEmpCount(res.data.data.employeCount);
        const role = employeeSubmissions[0]?.employee?.role;
        console.log("Role:", role);
        setRole(role);
        setIndSearch(true);

        if (employeeSubmissions.length === 0) {
          updateHistory([]);
        } else {
          updateHistory(employeeSubmissions);
        }
      })
      .catch((err) => {
        console.log(err);
      })
      .finally(() => {
        setLoading(false);
      });
  };

  const handleDropdownChange = (e, item) => {
    setDropdownFilter(item.key);
    getdataKey(item.key);

    if (!indSearch) {
      getOverallSubmission(item.key);
    } else {
      getIndividualHierarchy(item.key);
    }
  };

  useEffect(() => {
    console.log(id, "id");
    getIndividualHierarchy();
  }, [id]);

  return (
    <div>
      <Modal
        scrollableContentClassName={styles.addcandidate_modal_scrollable_content}
        containerClassName={`${
          isModalShrunk ? styles.addcandidate_modal_container_shrunk : styles.addcandidate_modal_container
        }`}
        isOpen={isModalOpen}
      >
        <div className={styles.header_expand_close_icon_container}>
          <Dropdown
            placeholder="Filter By"
            selectedKey={dropdownFilter}
            styles={(props) => DropdownStyles(props, "role")}
            onChange={handleDropdownChange}
            options={options}
          />

          <div onClick={handlePopupClose} className={styles.header_close_icon_container}>
            <Icon iconName="ChromeClose" className={closeIconClass} />
          </div>
        </div>
        <div className={styles.main_container}>
          <div className={styles.back_button}>
            <Icon iconName="Chromeback" onClick={handleBackButton} />
          </div>
          <span className={styles.sub_title}>
            {overallSubmission.length > 0 && capitalizeRole(overallSubmission[0].employee.role)} Count: {empCount}
          </span>
          
        
          <table>
            <thead className={styles.table_header}>
              <tr className={styles.table_row}>
                <th className={styles.table_headerContents}>Employee Name</th>
                <th className={styles.table_headerContents1}>Designation</th>
                <th className={styles.table_headerContents2}>Submission Count</th>
              </tr>
            </thead>

            <tbody>
              {loading ? (
                <Spinner className={styles.spinnerStyle} size={SpinnerSize.large} label="Loading ..." />
              ) : empCount === 0 ? (
                <div className={styles.notfound}>Data Not found !</div>
              ) : (
                overallSubmission.map((submission, index) => (
                  <tr key={index} className={styles.table_row}>
                    <td
                      className={`${styles.table_dataContents} ${
                        submission.employee.role === "recruiter" ? styles.recruiterRole : ""
                      }`}
                      onClick={
                        submission.employee.role !== "recruiter" ? () => setId(submission.employee._id) : undefined
                      }
                    >
                      {submission.employee.first_name} {submission.employee.last_name}
                    </td>

                    <td className={styles.table_dataContents1}>{capitalizeRole(submission.employee.role)}</td>
                    <td className={styles.table_dataContents2}>{submission.overallcount}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </Modal>
    </div>
  );
};

export default SubmissionHierarchy;
