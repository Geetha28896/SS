import React, { useEffect, useState, useRef } from "react";

import { Modal } from "@fluentui/react";
import { Toggle } from "@fluentui/react/lib/Toggle";
import {
  getNumberFromString,
  isAlphaNumeric,
  isAlphaNumericSpecial,
  isEmpty,
  isNumOnly,
} from "../utils/validation";

import { mergeStyles, mergeStyleSets } from "@fluentui/react";
import styles from "./EditDemand.module.css";
import { Icon } from "@fluentui/react/lib/Icon";
import {
  DefaultButton,
  PrimaryButton,
  DatePicker,
  ActionButton,
  Persona,
  PersonaSize,
  Callout,
  CommandBarButton,
  Label,
} from "@fluentui/react";
import { Dropdown } from "@fluentui/react/lib/Dropdown";
import { TextField } from "@fluentui/react/lib/TextField";

import { useNavigate, useSearchParams, useLocation } from "react-router-dom";

import { EditorState, convertToRaw, ContentState } from "draft-js";
import { Editor } from "react-draft-wysiwyg";
import draftToHtml from "draftjs-to-html";
import htmlToDraft from "html-to-draftjs";

import AssignedDemandModal from "./AssignedDemandModal";
// import 'draft-js/dist/Draft.css';
import "../../node_modules/react-draft-wysiwyg/dist/react-draft-wysiwyg.css";
import "./DraftEditorResetFix.css";

//icons
import boldicon from "../../src/assets/boldicon.svg";
import undoicon from "../../src/assets/undoicon.svg";
import redoicon from "../../src/assets/redoicon.svg";
import { Popup } from "../components/Popup";

// API
import { axiosPrivateCall, axiosJsonCall } from "../constants";
import ComboBox from '../components/ComboBox/ComboBox';

//regex
const vendorRegex = /^[a-zA-Z0-9 @,.()-]*$/;
const jobRRRegex = /^[A-Z0-9]*$/;

const contractIconClass = mergeStyles({
  fontSize: 20,
  height: 20,
  width: 20,
  cursor: "pointer",
});

const closeIconClass = mergeStyles({
  fontSize: 16,
  height: 20,
  width: 20,
  cursor: "pointer",
});

const downIconClass = mergeStyles({
  fontSize: 14,
  height: 20,
  width: 20,
  cursor: "pointer",
});

const textFieldColored = (props, currentHover, error, value) => {
  return {
    fieldGroup: {
      width: "160px",
      height: "22px",
      backgroundColor: "#EDF2F6",
      borderColor: error ? "#a80000" : "transparent",

      selectors: {
        ":focus": {
          borderColor: "rgb(96, 94, 92)",
        },
      },
    },
    field: {
      fontSize: 12,
    },
  };
};

const textField = (props, currentHover, error, value) => {
  return {
    fieldGroup: {
      width: "160px",
      height: "22px",
      borderColor: error ? "#a80000" : "transparent",

      selectors: {
        ":focus": {
          borderColor: "rgb(96, 94, 92)",
        },
      },
    },
    field: {
      fontSize: 12,
    },
    errorMessage: {
      paddingTop: 0,
      position: "absolute",
    },
  };
};

const textField1 = (props, currentHover, error, value) => {
  return {
    fieldGroup: {
      width: "100%",
      height: "22px",
      borderColor: error ? "#a80000" : "transparent",

      selectors: {
        ":focus": {
          borderColor: "rgb(96, 94, 92)",
        },
      },
    },
    field: {
      fontSize: 12,
    },
    errorMessage: {
      paddingTop: 0,
      position: "absolute",
    },
  };
};

const textFieldColored1 = (props, currentHover, error, value) => {
  const borderColor = error ? "#D24545" : "#E1E5E8";
  let titleColor = "#484848";
  if (!value) {
    titleColor = error ? "#D24545" : "#484848";
  }

  const borderRadius = "4px";

  return {
    fieldGroup: {
      width: "35vw",
      marginTop: "2.6px",
      height: "30px",
      backgroundColor: "#FFFFFF",
      color: titleColor,
      borderColor: borderColor,
      borderRadius: borderRadius,
      boxSizing: "border-box",
      selectors: {
        ":focus": {
          borderColor: borderColor,
        },
        ":hover": {
          borderColor: borderColor,
        },
      },
    },
    field: {
      color: titleColor,
      input: {
        color: "red",
        "&::placeholder": {
          color: titleColor,
          fontSize: 12,
        },
      },
    },
  };
};
const textFieldColored4 = (props, currentHover, error, value) => {
  const borderColor = error ? "#D24545" : "#E1E5E8";
  let titleColor = "#484848";
  if (!value) {
    titleColor = error ? "#D24545" : "#484848";
  }

  const borderRadius = "4px";

  return {
    fieldGroup: {
      display: "flex",
      width: "190px",
      maxWidth:"190px",
      height: "30px",
      backgroundColor: "#FFFFFF",
      color: titleColor,
      borderColor: borderColor,
      borderRadius: borderRadius,
      boxSizing: "border-box",
      selectors: {
        ":focus": {
          borderColor: borderColor,
        },
        ":hover": {
          borderColor: borderColor,
        },
      },
    },
    field: {
      color: "#5B5F62",
      fontSize: 12,
      input: {
        color: "red",
        "&::placeholder": {
          color: titleColor,
        },
      },
    },
  };
};

const DropdownStyles1 = (props, currentHover, error, value) => {
  const borderColor = error ? "#D24545" : "#E1E5E8";
  const hoverBorderColor = "#E1E5E8"; // Same color for hover state
  let titleColor = "#484848"; // Default color when value is not empty
  if (!value) {
    titleColor = error ? "#D24545" : "#484848"; // Change the color to red if value is empty
  }
  return {
    title: {
      height: "29px",
      display: "flex",
      alignItems: "center",
      color: titleColor,
    },
    dropdown: {
      borderRadius: "4px",
      selectors: {
        ".ms-Dropdown-title, .ms-Dropdown-caretDownWrapper": {
          borderColor: borderColor,
          borderRadius: "4px",
          color: titleColor,
        },
        ".ms-Dropdown-title:hover, .ms-Dropdown-caretDownWrapper:hover": {
          borderColor: hoverBorderColor,
        },
        ".ms-Dropdown-title:focus, .ms-Dropdown-title:focus-within": {
          borderRadius: "4px",
        },
      },
    },
  };
};


const DropdownStyles = (props, currentHover, error, value) => {
  const borderColor = error ? "#D24545" : "#E1E5E8";
  const hoverBorderColor = "#E1E5E8"; // Same color for hover state
  let titleColor = "#484848"; // Default color when value is not empty
  if (!value) {
    titleColor = error ? "#D24545" : "#484848"; // Change the color to red if value is empty
  }
  return {
    title: {
      height: "29px",
      display: "flex",
      alignItems: "center",
      color: titleColor,
    },
    dropdown: {
      borderRadius: "4px",
      selectors: {
        ".ms-Dropdown-title, .ms-Dropdown-caretDownWrapper": {
          borderColor: borderColor,
          borderRadius: "4px",
          color: titleColor,
        },
        ".ms-Dropdown-title:hover, .ms-Dropdown-caretDownWrapper:hover": {
          borderColor: hoverBorderColor,
        },
        ".ms-Dropdown-title:focus, .ms-Dropdown-title:focus-within": {
          borderRadius: "4px",
        },
      },
    },
  };
};

const textFieldColored2 = (props, currentHover, error, value) => {
  const borderColor = error ? "#D24545" : "#E1E5E8";
  let titleColor = "#484848";
  if (!value) {
    titleColor = error ? "#D24545" : "#484848";
  }

  const borderRadius = "4px";

  return {
    fieldGroup: {
      height: "30px",     
      backgroundColor: "#FFFFFF",
      color: titleColor,
      borderColor: borderColor,
      borderRadius: borderRadius,
      boxSizing: "border-box",
      selectors: {
        ":focus": {
          borderColor: borderColor,
        },
        ":hover": {
          borderColor: borderColor,
        },
      },
    },
    field: {
      color: "#5B5F62",
      input: {
        color: "red",
        "&::placeholder": {
          color: titleColor,
          fontSize: 12,
        },
      },
    },
  };
};

const textFieldColored3 = (props, currentHover, error, value) => {
  const borderColor = error ? "#D24545" : "#E1E5E8";
  let titleColor = "#484848";
  if (!value) {
    titleColor = error ? "#D24545" : "#484848";
  }

  const borderRadius = "4px";

  return {
    fieldGroup: {
      height: "30px",
      backgroundColor: "#FFFFFF",
      color: titleColor,
      paddingLeft: 1,
      width: "37px",
      maxWidth: "37px",
      borderColor: borderColor,
      borderRadius: borderRadius,
      boxSizing: "border-box",
      selectors: {
        ":focus": {
          borderColor: borderColor,
        },
        ":hover": {
          borderColor: borderColor,
        },
      },
    },
    field: {
      color: "#5B5F62",
      input: {
        color: "red",
        "&::placeholder": {
          color: titleColor,
          fontSize: 12,
          paddingLeft: 2,
        },
      },
    },
  };
};
let minDate = new Date(); // Today's date as minimum date

const textFieldTransparent = {
  fieldGroup: {
    width: "160px",
    height: "22px",
    border: "0.5px solid transparent",
    backgroundColor: "#EDF2F6",
  },
  field: {
    fontSize: 12,
  },
};

const textFieldTransparent1 = {
  fieldGroup: {
    width: "160px",
    height: "22px",
    border: "0.5px solid transparent",
  },
  field: {
    fontSize: 12,
  },
};

const textFieldTransparent2 = {
  fieldGroup: {
    width: "100%",
    height: "22px",
    border: "0.5px solid transparent",
  },
  field: {
    fontSize: 12,
  },
};

const textFieldError = {
  fieldGroup: {
    border: "0.5px solid rgb(164, 38, 44)",
    width: "160px",
    height: "22px",
  },
  field: {
    fontSize: 12,
  },
  errorMessage: {
    paddingTop: 0,
    position: "absolute",
  },
};

const dropDownStylesActive = (props, currentHover, error, value) => {
  return {
    dropdown: {
      width: "160px",
      minWidth: "160px",
      minHeight: "20px",

      // selectors:{

      // 	':focus:':{
      // 		border: '1px solid #0078D4',
      // 		':after':{
      // 			border: currentHover===value ? '1px solid #0078D4 ':  'none',
      // 		}
      // 	}
      // }
    },
    title: {
      height: "22px",
      lineHeight: "18px",
      fontSize: "12px",
      backgroundColor: "#EDF2F6",
      borderColor: error
        ? "#a80000"
        : currentHover === value
          ? "rgb(96, 94, 92)"
          : "transparent",
      // border: error ? '1px solid #a80000': currentHover===value ? '1px solid #0078D4 ':  'none',
      // selectors:{
      // 	':hover':{
      // 		border: '1px solid #0078D4'
      // 	},
      // 	':after':{
      // 		border: error ? '1px solid #a80000': currentHover===value ? '1px solid #0078D4 ':  'none'
      // 	},
      // }
    },
    errorMessage: {
      display: "none",
    },
    caretDownWrapper: { height: "22px", lineHeight: "20px !important" },
    dropdownItem: { minHeight: "22px", fontSize: 12 },
    dropdownItemSelected: { minHeight: "22px", fontSize: 12 },
  };
};

const dropDownStylesTransparent = mergeStyleSets({
  dropdown: { width: "160px", minWidth: "160px", minHeight: "20px" },
  title: {
    height: "22px",
    lineHeight: "18px",
    fontSize: "12px",
    border: "0.5px solid transparent",
    backgroundColor: "#EDF2F6",
  },
  caretDownWrapper: { height: "22px", lineHeight: "20px !important" },
  caretDown: { color: "transparent" },
  dropdownItem: { minHeight: "22px", fontSize: 12 },
  dropdownItemSelected: { minHeight: "22px", fontSize: 12 },
  errorMessage: {
    paddingTop: 0,
    position: "absolute",
  },
});

const dropDownStyles = (props, currentHover, error, value) => {
  return {
    dropdown: { width: "160px", minWidth: "160px", minHeight: "20px" },
    title: {
      height: "22px",
      lineHeight: "18px",
      fontSize: "12px",
      borderColor: error
        ? "#a80000"
        : currentHover === value
          ? "rgb(96, 94, 92)"
          : "transparent",
    },
    caretDownWrapper: { height: "22px", lineHeight: "20px !important" },
    dropdownItem: { minHeight: "22px", fontSize: 12 },
    dropdownItemSelected: { minHeight: "22px", fontSize: 12 },
    errorMessage: {
      paddingTop: 0,
      position: "absolute",
    },
  };
};

const dropDownErrorStyles = mergeStyleSets({
  dropdown: { width: "160px", minWidth: "160px", minHeight: "20px" },
  title: {
    height: "22px",
    lineHeight: "18px",
    fontSize: "12px",
    border: "0.5px solid #a80000",
  },
  caretDownWrapper: { height: "22px", lineHeight: "20px !important" },
  dropdownItem: { minHeight: "22px", fontSize: 12 },
  dropdownItemSelected: { minHeight: "22px", fontSize: 12 },
  errorMessage: {
    paddingTop: 0,
    position: "absolute",
  },
});

const dropDownRegularStyles = (props, currentHover, error, value) => {
  return {
    dropdown: {
      width: "100%",
      minHeight: "20px",
      // selectors:{
      // 	':focus':{
      // 		 'border': '1px solid #0078D4 ',
      // 	},

      // 	':focus':{
      // 		':after':{
      // 			border: '1px solid #0078D4 '
      // 		},

      // 	}

      // }
    },
    title: {
      height: "22px",
      lineHeight: "18px",
      fontSize: "12px",
      borderColor: error
        ? "#a80000"
        : currentHover === value
          ? "rgb(96, 94, 92)"
          : "transparent",
      // border: error ? '1px solid #a80000': currentHover === value ? '1px solid #0078D4 ':  'none',
      // selectors:{

      // 	':hover':{
      // 		border: '1px solid #0078D4'
      // 	}
      // }
    },
    caretDownWrapper: { height: "22px", lineHeight: "20px !important" },
    dropdownItem: { minHeight: "22px", fontSize: 12 },
    dropdownItemSelected: { minHeight: "22px", fontSize: 12 },
    dropdownItems: {
      height: 100,
      width: 150,
      overflow: "auto",
    },
    errorMessage: {
      paddingTop: 0,
      position: "absolute"
    },
  };
};

const dropDownRegularNoticeStyles = (props, currentHover, error, value) => {
  return {
    dropdown: { width: "100%", minHeight: "20px" },
    title: {
      height: "22px",
      lineHeight: "18px",
      fontSize: "12px",
      borderColor: error
        ? "#a80000"
        : currentHover === value
          ? "rgb(96, 94, 92)"
          : "transparent",
    },
    caretDownWrapper: { height: "22px", lineHeight: "20px !important" },
    dropdownItem: { minHeight: "22px", fontSize: 12 },
    dropdownItemSelected: { minHeight: "22px", fontSize: 12 },
    errorMessage: {
      paddingTop: 0,
      position: "absolute",
    },
  };
};

const dropDownRegularErrorStyles = mergeStyleSets({
  dropdown: { width: "100%", minHeight: "20px" },
  title: {
    height: "22px",
    lineHeight: "18px",
    fontSize: "12px",
    border: "0.5px solid #a80000",
  },
  caretDownWrapper: { height: "22px", lineHeight: "20px !important" },
  dropdownItem: { minHeight: "22px", fontSize: 12 },
  dropdownItemSelected: { minHeight: "22px", fontSize: 12 },
  errorMessage: {
    paddingTop: 0,
    position: "absolute",
  },
});

const dropDownRegularErrorStyles1 = mergeStyleSets({
  dropdown: { width: "100%", minHeight: "20px" },
  title: {
    height: "22px",
    lineHeight: "18px",
    fontSize: "12px",
    border: "0.5px solid #a80000",
  },
  caretDownWrapper: { height: "22px", lineHeight: "20px !important" },
  dropdownItem: { minHeight: "22px", fontSize: 12 },
  dropdownItemSelected: { minHeight: "22px", fontSize: 12 },
  errorMessage: {
    paddingTop: 0,
    position: "absolute",
  },
  dropdownItems: {
    height: 100,
    width: 150,
    overflow: "auto",
  },
});

const dropDownRegularActiveStyles = mergeStyleSets({
  dropdown: { width: "100%", minHeight: "20px" },
  title: {
    height: "22px",
    lineHeight: "18px",
    fontSize: "12px",
    border: "0.5px solid #333333",
  },
  caretDownWrapper: { height: "22px", lineHeight: "20px !important" },
  dropdownItem: { minHeight: "22px", fontSize: 12 },
  dropdownItemSelected: { minHeight: "22px", fontSize: 12 },
  errorMessage: {
    paddingTop: 0,
    position: "absolute",
  },
  dropdownItems: {
    height: 100,
    width: 150,
    overflow: "auto",
  },
});

const dropDownRegularActiveStyles1 = mergeStyleSets({
  dropdown: { width: "100%", minHeight: "20px" },
  title: {
    height: "22px",
    lineHeight: "18px",
    fontSize: "12px",
    border: "0.5px solid #333333",
  },
  caretDownWrapper: { height: "22px", lineHeight: "20px !important" },
  dropdownItem: { minHeight: "22px", fontSize: 12 },
  dropdownItemSelected: { minHeight: "22px", fontSize: 12 },
  errorMessage: {
    paddingTop: 0,
    position: "absolute",
  },
});

const dropDownMediumStyles = mergeStyleSets({
  dropdown: { width: "270px", minHeight: "20px" },
  title: { height: "22px", lineHeight: "18px", fontSize: "12px" },
  caretDownWrapper: { height: "22px", lineHeight: "20px !important" },
  dropdownItem: { minHeight: "22px", fontSize: 12 },
  dropdownItemSelected: { minHeight: "22px", fontSize: 12 },
  errorMessage: {
    paddingTop: 0,
    position: "absolute",
  },
});

const dropDownSmallStyles = mergeStyleSets({
  root: { width: "100%" },
  dropdown: { width: "100%", minHeight: "20px" },
  title: {
    height: "22px",
    lineHeight: "18px",
    fontSize: "12px",
    border: "0.5px solid transparent",
  },
  caretDownWrapper: { height: "22px", lineHeight: "20px !important" },
  dropdownItems: {
    height: 200,
    width: 150,
    overflow: "auto",
  },
  errorMessage: {
    paddingTop: 0,
    position: "absolute",
  },
});

const calendarClass = (value) => {
  console.log(value, "valueee");
  let titleColor = value && value?.length === 0 ? "LightGray" : "black";
  return mergeStyleSets({
    root: {
      "*": {
        fontSize: 13,
        height: "29px !important",
        lineHeight: "20px !important",
        borderColor: "#E1E5E8 !important",
        borderRadius: "4px",
        lineHeight: "26px !important",
        color: value.length === 0 ? "LightGray !important" : "#484848 !important",
      },
    },
    field: {
      color: value.length === 0 ? "LightGray !important" : "black !important",
      fontSize: 12,
      input: {
        color: value.length === 0 ? "LightGray !important" : "black !important",
        "&::placeholder": {
          color: value.length === 0 ? "LightGray !important" : "black !important",
        },
      },
    },
    icon: {
      height: "14px !important",
      width: "8px !important",
      left: "90%",
      padding: "0px 0px",
      scale: "90%",
    },
    statusMessage: { marginBottom: "-25px" },
  });
};

const calendarClassActive = mergeStyleSets({
  root: {
    "*": {
      width: "100%",
      fontSize: 12,
      height: "22px !important",
      lineHeight: "20px !important",
      borderColor: "grey !important",
    },
  },
  icon: { height: 10, width: 10, left: "85%", padding: "0px 0px" },
  fieldGroup: { border: "0.5px solid grey !important" },
  statusMessage: { marginBottom: "-25px" },
});

const calendarErrorClass = mergeStyleSets({
  root: {
    "*": {
      width: "100%",
      fontSize: 12,
      height: "22px !important",
      lineHeight: "20px !important",
      borderColor: "#a80000",
    },
  },
  icon: {
    height: 10,
    width: 10,
    left: "85%",
    padding: "0px 0px",
    color: "#a80000",
  },
  fieldGroup: { border: "0.5px solid #a80000 !important" },
});

const SkillFieldStyles = (props, currentHover, error, value) => {
  return {
    fieldGroup: {
      height: 22,
      width: "100%",
      borderColor: error ? "#a80000" : "transparent",

      selectors: {
        ":focus": {
          borderColor: "rgb(96, 94, 92)",
        },
      },
    },
    field: {
      fontSize: 12,
    },
    errorMessage: {
      paddingTop: 0,
      position: "absolute",
    },
  };
};

const jobDescriptionStyles = (props, currentHover, error) => {
  return {
    fieldGroup: {
      height: 32,
      width: "100%",
      borderColor: error ? "#a80000" : "transparent",
      selectors: {
        ":after": {
          borderColor: error
            ? " #a80000"
            : currentHover
              ? "#0078D4 "
              : "transparent",
        },
        ":focus": {
          borderColor: "#0078D4",
        },
        ":hover": {
          borderColor: "rgb(96, 94, 92)",
        },
      },
    },
  };
};

const personaStyles = {
  primaryText: {
    height: 16,
  },
};

const personaDropDownStyles = {
  root: {
    margin: "0px 5px",
  },
};

const addButtonStyles = {
  icon: {
    color: "rgb(50, 49, 48)",
    fontSize: 14,
  },
};

const removeIconClass = mergeStyles({
  fontSize: 10,
  height: "20px",
  width: "12px",
  paddingTop: "11px",
  paddingLeft: "20px",
  cursor: "pointer",
  color: "red",
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
});

const unassignedDropdownStyles = {
  dropdown: {
    width: 120,
  },
  title: {
    height: 30,
  },
};

const editorToolbarOptions = {
  options: ["inline", "list", "link", "history"],
  inline: {
    bold: { icon: boldicon, className: undefined },
    options: ["bold", "italic", "underline"],
  },
  list: {
    options: ["unordered", "ordered"],
  },
  link: {
    options: ["link"],
  },
  history: {
    options: ["undo", "redo"],
    undo: { icon: undoicon },
    redo: { icon: redoicon },
  },
  // fontFamily: {
  //   options: ['Arial', 'Georgia', 'Impact', 'Tahoma', 'Times New Roman', 'Verdana'],
  // },
};

const dropDownStatus = [
  { key: "Open", text: "Open" },
  { key: "Close", text: "Close" },
  { key: "On Hold", text: "On Hold" },
  { key: "In Progress", text: "In Progress" },
];

const dropDownPriority = [
  { key: "Low", text: "Low" },
  { key: "Medium", text: "Medium" },
  { key: "High", text: "High" },
];

const dropDownNoticePeriod = [
  { key: "Immediate", text: "Immediate" },
  { key: "< 15 Days", text: "< 15 Days" },
  { key: "< 30 Days", text: "< 30 Days" },
  { key: "< 60 Days", text: "< 60 Days" },
  { key: "> 60 Days", text: "> 60 Days" },
];

const dropDownMonth = [
  { key: "0 month", text: 0 },
  { key: "1 month", text:  1},
  { key: "2 months", text: "2" },
  { key: "3 months", text: "3" },
  { key: "4 months", text: "4" },
  { key: "5 months", text: "5" },
  { key: "6 months", text: "6" },
  { key: "7 months", text: "7" },
  { key: "8 months", text: "8" },
  { key: "9 months", text: "9" },
  { key: "10 months", text: "10" },
  { key: "11 months", text: "11" },
  { key: "12 months", text: "12" },
];

const dropDownYear = [
  { key: "0 year", text: 0  },
  { key: "1 year", text: "1 " },
  { key: "2 years", text: "2 " },
  { key: "3 years", text: "3 " },
  { key: "4 years", text: "4 " },
  { key: "5 years", text: "5 " },
  { key: "6 years", text: "6 " },
  { key: "7 years", text: "7 " },
  { key: "8 years", text: "8 " },
  { key: "9 years", text: "9 " },
  { key: "10 years", text: "10 " },
  { key: "11 years", text: "11 " },
  { key: "12 years", text: "12 " },
  { key: "13 years", text: "13 " },
  { key: "14 years", text: "14 " },
  { key: "15+ years", text: "15+ " },
];

const modeOfHireDropdown = [
  { key: "C2H (contract to Hire)", text: "C2H (contract to Hire)" },
  { key: "C2H (contract to Hire) - Client side ", text: "C2H (contract to Hire) - Client side " },
  { key: "Permanent", text: "Permanent" },
  { key: "Permanent  - Internal recruitment", text: "Permanent  - Internal recruitment" },

];

// const personaList =[

// 	{
// 		text: 'Maor Sharett',
// 		imageInitials: 'MS',
// 		secondaryText: 'maorsharett@gmail.com',
// 		showSecondaryText: true,
// 	},
// 	{
// 		text: 'Mary Shekar',
// 		imageInitials: 'MS',
// 		secondaryText: 'maorsharett1@gmail.com',
// 		showSecondaryText: true,
// 	},
// 	{
// 		text: 'Miss Shajan',
// 		imageInitials: 'MS',
// 		secondaryText: 'maorsharett2@gmail.com',
// 		showSecondaryText: true,
// 	},
// 	{
// 		text: 'Gowri Shankar',
// 		imageInitials: 'GS',
// 		secondaryText:'gowris@gmail.com',
// 		showSecondaryText: true,
// 	},
// 	{
// 		text: 'Elango Viswanath',
// 		imageInitials: 'EV',
// 		secondaryText:'elangoviswa@gmail.com',
// 		showSecondaryText: true,
// 	}
// ]

const initialState = {
  job_title: "",
  assigned_to: "",
  status: "",
  no_of_positions: "",
  priority: "",
  client: "",
  job_description: "",
  additional_details: "",
  due_date: "",
  notice_period: "",
  minimum_experience_months: "",
  minimum_experience_years: "",
  maximum_experience_months: "",
  maximum_experience_years: "",
  mode_of_hire: "",
  vendor_name: "",
  poc_vendor: "",
  lead: "",
  job_rr_id: "",
};

const sanitizeObject = {
  job_title: "",
  assigned_to: "",
  status: "",
  no_of_positions: "",
  priority: "",
  client: "",
  job_description: "",
  additional_details: "",
  due_date: "",
  notice_period: "",
  minimum_experience: "",
  maximum_experience: "",
  mode_of_hire: "",
  vendor_name: "",
  poc_vendor: "",
  job_rr_id: "",
  skillset: [],
};

const convertSantizedToInitial = (data) => {
  const state = {};

  Object.keys(data).forEach((key) => {
    if (key === "skillset") {
      state[key] = [];
      data["skillset"].map((skillObj, index) => {
        state[key].push({});
        state[key][index]["skill"] = skillObj["skill"];
        state[key][index]["years"] = Number(Math.floor(skillObj["exp"] / 12));
        state[key][index]["months"] = Number(Math.floor(skillObj["exp"] % 12));
      });
      return;
    }

    if (key === "assigned_to") {
      // state[key] = data[key]["_id"];

      state[key] = data[key];
      return;
    }

    if (key === "minimum_experience") {
      state["minimum_experience_months"] = `${Math.floor(
        data["minimum_experience"] % 12
      )} months`;
      state["minimum_experience_years"] = `${Math.floor(
        data["minimum_experience"] / 12
      )} years`;
      return;
    }

    if (key === "maximum_experience") {
      state["maximum_experience_months"] = `${Math.floor(
        data["maximum_experience"] % 12
      )} months`;
      state["maximum_experience_years"] = `${Math.floor(
        data["maximum_experience"] / 12
      )} years`;
      return;
    }

    state[key] = data[key];
  });

  return state;
};

const EditDemand = (props) => {
  // const {showMessageBar,setShowMessageBar} = props;
  const demand_location = useLocation()
  const mydemandValidate = demand_location.state;

  const [searchParams, setSearchParams] = useSearchParams();
  const [firstLoad, setFirstLoad] = useState(false);
  const [demandId, setDemandId] = useState("");

  const [showPopup, setShowPopup] = useState(false);
  const [currentHover, setCurrentHover] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [personaText, setPersonaText] = useState("");
  const [personaList, setPersonaList] = useState([]);

  const [showAssignedDemandmodal, setShowAssignedDemandModal] = useState(false);

  const [isPersonaListLoaded, setIsPersonaListLoaded] = useState(false);
  const [dropDownVendors, setDropDownVendors] = useState([]);
  const [dropDownClients, setDropDownClients] = useState([]);
  const [dropDownSkills, setDropDownSkills] = useState([]);

  const [hasMore, setHasMore] = useState(true);
  const [linkedData, setLinkedData] = useState([])
  const [visibleData, setVisibleData] = useState([]);


  const navigateTo = useNavigate();

  const userId = searchParams.get('demand_id')


  const [editorState, setEditorState] = React.useState(() =>
    EditorState.createEmpty()
  );

  const [editorState2, setEditorState2] = React.useState(() =>
    EditorState.createEmpty()
  );

  const [errorMessage, setErrorMessage] = useState('');

  useEffect(() => {
    axiosPrivateCall.get(`/api/v1/vendor/listVendors`).then(res => {
      let buffer = res.data;
      let dropdown_data = buffer.map((obj) => { return { key: obj.company_name, text: obj.company_name } });
      setDropDownVendors(dropdown_data)
    }).catch(e => {
      console.log(e)
    })

    axiosPrivateCall.get(`/api/v1/client/listClients`).then(res => {
      let buffer = res.data;
      let dropdown_data = buffer.map((obj) => { return { key: obj.company_name, text: obj.company_name } });
      setDropDownClients(dropdown_data)
    }).catch(e => {
      console.log(e)
    })

    axiosPrivateCall.get(`/api/v1/skill/listSkills`).then(res => {
      let buffer = res.data;
      let dropdown_data = buffer.map((obj) => { return { key: obj.skill_name, text: obj.skill_name } });
      setDropDownSkills(dropdown_data)
    }).catch(e => {
      console.log(e)
    })

  }, [])

  useEffect(() => {
    axiosPrivateCall
      .get("/api/v1/employee/getReportsToHierarchy")
      .then((res) => {
        const personaArr = res.data;

        if (personaArr.length) {
          setPersonaList(
            personaArr.map((persona) => {
              return {
                text: persona["first_name"] + " " + persona["last_name"],
                id: persona["_id"],
                imageInitials:
                  persona["first_name"].slice(0, 1).toUpperCase() +
                  persona["last_name"].slice(0, 1).toUpperCase(),
                secondaryText: persona["email"],
                showSecondaryText: true,
              };
            })
          );

          setIsPersonaListLoaded(true);
          setPersona(personaArr);
          console.log(personaList, "losss", personaArr);
        }
      })
      .catch((e) => {
        console.log(e);
      });
    axiosPrivateCall(
      `/api/v1/demand/getDemandDetails?demand_id=${searchParams.get(
        "demand_id"
      )}`
    )
      .then((res) => {
        setDemandData(convertSantizedToInitial(res.data));
        setFirstLoad(true);
        const errorObj = getErrorObj(convertSantizedToInitial(res.data));
        // setErrors(errorObj);
        // setPersona(res.data.assigned_to)
        setDemandId(res.data.DemandId);
      })
      .catch((e) => {
        console.log(e);
      });
  }, []);

  useEffect(() => {
    const contentLength = editorState.getCurrentContent().getPlainText().trim().length;
    if (contentLength === 0 || contentLength >= 10) {
      setErrors((prevData) => {
        return {
          ...prevData,
          job_description: "",
        };
      });
      setDemandData((prevData) => {
        return {
          ...prevData,
          job_description: draftToHtml(convertToRaw(editorState.getCurrentContent())),
          additional_details: draftToHtml(convertToRaw(editorState2.getCurrentContent())),
        };
      });
    } else if (contentLength < 10) {
      setDemandData((prevData) => {
        return {
          ...prevData,
          job_description: draftToHtml(convertToRaw(editorState.getCurrentContent())),
          additional_details: draftToHtml(convertToRaw(editorState2.getCurrentContent())),
        };
      });
    }

    if (demandData.job_description.length > 18) {
      setErrors((prevData) => {
        return {
          ...prevData,
          job_description: "",
        };
      });
    }
  }, [editorState, editorState2]);

  const handleEditorStateChange = (newEditorState) => {
    const content = newEditorState.getCurrentContent().getPlainText().trim();
    if (content.length === 0) {
      setErrorMessage('');
    }
    else if (content.length < 10) {
      setErrorMessage('Minimum 10 characters Required');
    }

    else {
      setErrorMessage('');
    }
    setEditorState(newEditorState);
  };
  useEffect(() => {
    if (firstLoad) {
      const jobHTML = demandData.job_description;
      const additionalHTML = demandData.additional_details;

      const contentBlock = htmlToDraft(jobHTML);
      const contentBlock2 = htmlToDraft(additionalHTML);

      const contentState = ContentState.createFromBlockArray(
        contentBlock.contentBlocks
      );
      const editorState = EditorState.createWithContent(contentState);

      const contentState2 = ContentState.createFromBlockArray(
        contentBlock2.contentBlocks
      );
      const editorState2 = EditorState.createWithContent(contentState2);

      setEditorState(EditorState.createWithContent(contentState));
      setEditorState2(EditorState.createWithContent(contentState2));

      setFirstLoad(false);
    }
  }, [firstLoad]);

  const personaRef = useRef(null);


  useEffect(() => { }, []);

  const setPersona = (assigned_to) => {
    console.log(assigned_to, "kkk");

    setPersonaList([
      {
        text: assigned_to["first_name"] + " " + assigned_to["last_name"],
        id: assigned_to["_id"],
        imageInitials:
          assigned_to["first_name"].slice(0, 1).toUpperCase() +
          assigned_to["last_name"].slice(0, 1).toUpperCase(),
        secondaryText: assigned_to["email"],
        showSecondaryText: true,
      },
    ]);

    setPersonaText(assigned_to["email"]);

    setIsPersonaListLoaded(true);
  };

  const escKeyHandler = (event) => {
    if (event.key === 'Escape') {
      event.preventDefault();
      // Optionally, you can add your close logic here
    }
  };

  useEffect(() => {
    const handleKeyDown = (event) => {
      escKeyHandler(event);
    };

    document.addEventListener('keydown', handleKeyDown, { capture: true });

    return () => {
      document.removeEventListener('keydown', handleKeyDown, { capture: true });
    };
  }, []);

  const [demandData, setDemandData] = useState({
    ...initialState,
    skillset: [
      {
        skill: "",
        years: "",
        months: "",
      },
    ],
  });

  const [errors, setErrors] = useState({
    ...initialState,
    skillset: [
      {
        skill: "",
        years: "",
        months: "",
      },
    ],
  });

  const dropDownHandler = (e, item, name) => {
    setDemandData((prevData) => {
      return {
        ...prevData,
        [name]: item.text,
      };
    });
    setErrors({
      ...errors,
      [name]: "",
    });
  };

  const hoverHandler = (name) => {
    setCurrentHover(name);
  };

  const skillSetInputHandler = (e, name, index, arr) => {
    const skillsetArr = [...arr];

    let value = e.target.value;

    let isSkillInputValid = true;

    if (name === "years") {
      if (!isNumOnly(value)) {
        isSkillInputValid = false;
      }

      if (isEmpty(value)) {
        isSkillInputValid = true;
      }
    }

    if (name === "months") {
      if (!isNumOnly(value) || value > 12) {
        isSkillInputValid = false;
      }

      if (isEmpty(value)) {
        isSkillInputValid = true;
      }
    }

    if (isSkillInputValid) {
      if (!skillsetArr[index]) {
        skillsetArr[index] = {
          skill: "",
          years: "",
          months: "",
        };
      }

      skillsetArr[index][name] = value;

      setDemandData((prevData) => {
        return {
          ...prevData,
          skillset: skillsetArr,
        };
      });

      setErrors((prevData) => {
        const skillsetErrArr = [...prevData.skillset];
        skillsetErrArr[index] = {
          ...skillsetErrArr[index],
          [name]: "",
        };
        return {
          ...prevData,
          skillset: skillsetErrArr,
        };
      });
    }
  };




  const removeSkill = (skillData, index, arr) => {
    if (index === 0) return;

    const newskillsetArr = arr.filter((val) => val !== skillData);

    setDemandData((prevData) => {
      return {
        ...prevData,
        skillset: newskillsetArr,
      };
    });

    const newskillsetErrArr = errors.skillset.filter((val, i) => i !== index);

    setErrors((prevData) => {
      return {
        ...prevData,
        skillset: newskillsetErrArr,
      };
    });
  };

  const dateHandler = (date, name) => {
    setDemandData((prevData) => {
      return {
        ...prevData,
        [name]: date,
      };
    });
    setErrors({
      ...errors,
      [name]: "",
    });
  };

  const inputChangeHandler = (e, inputName) => {
    const { value } = e.target;
    let inputValue = value;

    let isInputValid = true;

    if (inputName === "no_of_positions") {
      if (!isNumOnly(value)) {
        isInputValid = false;
      }

      if (isEmpty(value)) {
        isInputValid = true;
      }
    }

    if (inputName === "vendor_name") {
      isInputValid = vendorRegex.test(value);
    }

    if (inputName === "job_rr_id") {
      isInputValid = jobRRRegex.test(value);
    }

    if (inputName === "no_of_positions") {
      inputValue = Number(inputValue);

      if (isEmpty(value)) {
        inputValue = "";
      }
    }

    if (isInputValid) {
      setDemandData({
        ...demandData,
        [inputName]: inputValue,
      });
      setErrors({
        ...errors,
        [inputName]: "",
      });
    }
  };

  const addSkillSet = () => {
    const skillsetArr = demandData.skillset;
    skillsetArr.push({
      skill: "",
      years: "",
      months: "",
    });

    setDemandData((prevData) => {
      return {
        ...prevData,
        skillset: skillsetArr,
      };
    });

    const skillsetErrArr = errors.skillset;

    skillsetErrArr.push({
      skill: "",
      years: "",
      months: "",
    });

    setErrors((prevData) => {
      return {
        ...prevData,
        skillset: skillsetErrArr,
      };
    });
  };

  const [isModalShrunk, setIsModalShrunk] = useState(false);
  const [isPersonaOpen, setIsPersonaOpen] = useState(false);

  const modalSizeHandler = () => {
    setIsModalShrunk(!isModalShrunk);
  };

  const personaClickHandler = (persona) => {
    setDemandData((prevState) => {
      setPersonaText(persona.secondaryText);

      console.log(persona);
      return {
        ...prevState,
        assigned_to: persona.id,
        // assigned_to: '6387afcc7c36709133213e03',
      };
    });

    setErrors((prevData) => {
      return {
        ...prevData,
        assigned_to: "",
      };
    });
    setIsPersonaOpen(isPersonaOpen);
  };

  const getErrorObj = (obj) => {
    const errorObj = {};
    let min_month = (parseInt(getNumberFromString(obj.minimum_experience_months)))
    let max_month = (parseInt(getNumberFromString(obj.maximum_experience_months)))
    let min_year = (parseInt(getNumberFromString(obj.minimum_experience_years)))
    let max_year = (parseInt(getNumberFromString(obj.maximum_experience_years)))
    for (const [key, value] of Object.entries(obj)) {
      if (Array.isArray(value)) {
        errorObj[key] = [];
        value.map((data, index) => {
          let newErrObj = {};

          Object.keys(data).map((key) => {
            if (isEmpty(data[key])) {
              return (newErrObj[key] = "Required");
            } else {
              return (newErrObj[key] = "");
            }
          });
          return (errorObj[key][index] = newErrObj);
        });
      } else if (isEmpty(value)) {
        errorObj[key] = "Required";
      } else {
        errorObj[key] = "";
      }
      if (min_year > max_year) {
        errorObj["maximum_experience_years"] = " Min exp exceeds max exp."
      } else if (key === 'maximum_experience_months') {
        const min_experience_total = min_year * 12 + min_month;
        const max_experience_total = max_year * 12 + max_month;
        if (min_experience_total > max_experience_total) {
          errorObj[key] = "Min exp exceeds max exp."
        }
      }
    }

    return errorObj;
  };
  const sanitizer = (data) => {
    const sanitizedData = {};

    console.log(data);


    Object.keys(data).forEach((key) => {
      if (key === "skillset") {
        sanitizedData[key] = [];

        data["skillset"].map((skillObj, index) => {
          console.log(skillObj, index);
          sanitizedData[key].push({});
          sanitizedData[key][index]["skill"] = skillObj["skill"];
          sanitizedData[key][index]["exp"] =
            Number(skillObj["years"] * 12) + Number(skillObj["months"]);
        });
        return;
      }

      if (key === "minimum_experience_years") {
        return (sanitizedData["minimum_experience"] = sanitizedData[
          "minimum_experience"
        ]
          ? parseInt(data[key]) * 12 + sanitizedData["minimum_experience"]
          : parseInt(getNumberFromString(data[key]) * 12));
      }

      if (key === "minimum_experience_months") {
        return (sanitizedData["minimum_experience"] = sanitizedData[
          "minimum_experience"
        ]
          ? parseInt(data[key]) + sanitizedData["minimum_experience"]
          : parseInt(getNumberFromString(data[key])));
      }

      if (key === "maximum_experience_years") {
        return (sanitizedData["maximum_experience"] = sanitizedData[
          "maximum_experience"
        ]
          ? parseInt(data[key]) * 12 + sanitizedData["maximum_experience"]
          : parseInt(getNumberFromString(data[key]) * 12));
      }

      if (key === "maximum_experience_months") {
        return (sanitizedData["maximum_experience"] = sanitizedData[
          "maximum_experience"
        ]
          ? parseInt(data[key]) + sanitizedData["maximum_experience"]
          : parseInt(getNumberFromString(data[key])));
      }

      sanitizedData[key] = data[key];
    });

    return sanitizedData;
  };

  const updateDemand = () => {
    axiosPrivateCall
      .post("/api/v1/demand/updateDemand", sanitizer(demandData))
      .then((res) => {
        console.log(res);
        setIsLoading(false);
        mydemandValidate.demand === 'mydemand' ? navigateTo("/demand/mydemands") : navigateTo("/demand/managedemands");
        console.log(mydemandValidate.demand,"mmm")
      })
      .catch((e) => {
        console.log(e);
      });
  };

  const submitHandler = () => {
    if (!isLoading) {
      setIsLoading(true);
    }

    const errorObj = getErrorObj(demandData);
    console.log(errorObj);
    setErrors(errorObj);

    const isSkillsetEmpty = demandData.skillset.some(
      (skill) => skill.skill === "" || skill.years === "" || skill.months === ""
    );

    if (isDemandDataValid(demandData) && !isSkillsetEmpty) {
      console.log("valid");
      updateDemand();
    } else {
      console.log("not valid");
    }
  };


  // validations

  //   const isDemandDataValid = (obj) => {
  //     for (const [key, value] of Object.entries(obj)) {
  //       if (key === "job_description" && value.length <= 17) {
  //         return false;
  //       }

  //       if (Array.isArray(value)) {
  //         return value.every((data, index) => {
  //           return Object.values(data).every((val) => !isEmpty(val));
  //         });
  //       }

  //       if (isEmpty(value)) {
  //         return false;
  //       }
  //     }
  //     return true;
  //   };

  const isDemandDataValid = (obj) => {
    const excludedFields = ["vendor_name", "poc_vendor", "job_rr_id"];
    let min_month = (parseInt(getNumberFromString(obj.minimum_experience_months)))
    let max_month = (parseInt(getNumberFromString(obj.maximum_experience_months)))
    let min_year = (parseInt(getNumberFromString(obj.minimum_experience_years)))
    let max_year = (parseInt(getNumberFromString(obj.maximum_experience_years)))
    for (const [key, value] of Object.entries(obj)) {
      if (excludedFields.includes(key)) {
        continue; // skip validation for excluded fields
      }
      console.log(demandData.job_description.length === 8 ? true : false, "ss")
      if (demandData?.job_description && demandData.job_description.length === 8) {
        return true;
      } else if (demandData?.job_description && demandData.job_description.length < 18) {
        setErrorMessage('Minimum 10 characters Required');
        return false;
      }
      if (Array.isArray(value)) {
        return value.every((data, index) => {
          return Object.values(data).every((val) => !isEmpty(val));
        });
      }

      if (isEmpty(value)) {
        return false;
      }
      if (errors.maximum_experience_years === "Min exp exceeds max exp.") {
        return false;
      }
      const min_experience_total = min_year * 12 + min_month;
      const max_experience_total = max_year * 12 + max_month;
      if (min_experience_total > max_experience_total) {
        return false;
      }
    }
    return true;
  };

  const [min_experience, setMin_Experience] = useState([]);
  const [initial_experience, set_initial_experience] = useState([]);
  const [experience_update, set_experience_update] = useState(false)
  const list_format = [];

  const initial_max_experience_year = () => {
    dropDownYear.map((value, index) => {
      if (demandData.minimum_experience_years === value.text) {
        for (let i = index; i <= dropDownYear.length - 1; i++) {
          list_format.push(dropDownYear[i]);
        }
        return set_initial_experience(list_format);
      }
    });
  };

  const min_experience_list = [];
  const minimum_experience_filter = (max_experience) => {
    dropDownYear.map((value, index) => {
      if (max_experience === value.text) {
        for (let i = index; i > 0; i--) {
          min_experience_list.push(dropDownYear[i]);
        }
        return setMin_Experience(min_experience_list);
      }
    });
  };



  useEffect(() => {
    // maximum_experience_filter();
    minimum_experience_filter();
    initial_max_experience_year();
  }, []);

  // POC Vendor Name 
  function isValidInput(input) {
    const regex = /^[a-zA-Z\s]*$/;
    return regex.test(input);
  }
  useEffect(() => {
    axiosPrivateCall.get(`/api/v1/demand/linkedDetails/${userId}`)
      .then(res => setLinkedData(res.data))
      .catch(err => {
        console.log(err)
      })
  }, [])


  const ISOdateToCustomDate = (value) => {
    const dateFormat = new Date(value);
    let year = dateFormat.getFullYear();
    let month = dateFormat.getMonth() + 1;
    let date = dateFormat.getDate();

    if (date < 10) {
      date = '0' + date;
    }
    if (month < 10) {
      month = '0' + month;
    }

    return date + '/' + month + '/' + year;
  };
  useEffect(() => {
    // Load initial data
    loadMoreData();
  }, []);

  


  const loadMoreData = () => {
    // Assuming linkedData is an array of items
    const newData = linkedData.slice(0, visibleData.length + 3);
    setVisibleData(newData);
    if (newData.length >= linkedData.length) {
      setHasMore(false); // No more data to load
    }
  };

  const handleScroll = (e) => {
    const bottom = e.target.scrollHeight - e.target.scrollTop === e.target.clientHeight;
    if (bottom && hasMore) {
      loadMoreData();
    }
  };

  return (
    <div className={styles.pages}>
       {showAssignedDemandmodal && (
        <AssignedDemandModal
          data={demandData.assigned_to}
          isModalOpen={showAssignedDemandmodal}
          setIsModalOpen={setShowAssignedDemandModal}
        />
      )}
     
     <div className={styles.adddemand_modal_header_container}>
          <div className={styles.header_tag_expand_close_icon_container}>
            <div className={styles.header_tag_container}>Demand</div>

           
          </div>

          <div className={styles.AddLabel}>Demand ID:  {demandId ? demandId : ""}</div>

          <div className={styles.header_content_container}>
            <div className={styles.header_content_job_description_unassigned_save_container}>
              <div className={styles.header_content_job_description_unassigned_container}>
                <div className={styles.header_content_job_description_container}>
                  <div className={styles.job_label} onClick={() => setCurrentHover("job_title")}>
                    <Label className={styles.name_label_style} required>
                      Job Requirement Title
                    </Label>
                    <TextField
                      value={demandData.job_title}
                      placeholder="Enter the Job Requirement Title"
                      onChange={(e) => {
                        inputChangeHandler(e, "job_title");
                        setCurrentHover("");
                      }}
                      resizable={false}
                      styles={(props) => textFieldColored1(props, currentHover, errors.job_title, demandData.job_title)}
                    />
                  </div>
                </div>
              </div>

              <div className={styles.header_save_close_btns_container}>
              <div
                  ref={personaRef}
                  id="personaId"
                  onClick={() => setShowAssignedDemandModal(true)}

                  className={styles.unassigned_container}
                >
                  <div className={styles.unassigned_title_icon_container}>
                  <div className={styles.unassigned_title_container}>
                  {`Assigned  ${demandData?.assigned_to?.length}`}
                      {/* <Dropdown
                        className={styles.unassignedDropdown}
                        placeholder="Unassigned"
                        styles={(props) => DropdownStyles(props, currentHover, errorMessage.unassigned)}
                      /> */}
                    </div>   {/* <div className={styles.unassigned_icon_container}>
                        {
                          <Icon
                            iconName="ChevronDown"
                            className={downIconClass}
                          />
                        }
                      </div> */}
                  </div>
                
                </div>
                <PrimaryButton
                  className={styles.btnStyle}
                  onClick={submitHandler}
                  text="Save & Close"
                  iconProps={{ iconName: "Save" }}
                />
              </div>
            </div>
          </div>
        </div>

        <div className={styles.main_filter_options_container}>
          <div className={styles.main_filter_options_sub_container}>
            <div className={styles.main_role_dropdown_container}>
              <div className={styles.main_role_title}>
                <Label className={styles.required_field} required>
                  Status
                </Label>
              </div>
              <div className={styles.sec_div} onClick={() => setCurrentHover("status")}>
                <Dropdown
                  name="status"
                  onChange={(e, item) => {
                    dropDownHandler(e, item, "status");
                    setCurrentHover("");
                  }}
                  selectedKey={demandData.status}
                  placeholder="Select"
                  notifyOnReselect
                  styles={(props) => DropdownStyles(props, currentHover, errors.status,demandData.status, "status")}
                  // errorMessage={errors.status}
                  options={dropDownStatus}
                />
              </div>
            </div>
            <div className={styles.main_role_dropdown_container}>
              <div className={styles.main_role_title1}>
                <Label className={styles.required_field} required>
                  No of Positions
                </Label>
              </div>
              <div onClick={() => setCurrentHover("no_of_positions")}>
                <TextField
                  value={demandData.no_of_positions}
                  onChange={(e) => {
                    inputChangeHandler(e, "no_of_positions");
                  }}
                  placeholder={"Enter the count"}
                  styles={(props) => textFieldColored2(props, currentHover, errors.no_of_positions,demandData.no_of_positions, "no_of_positions")}
                />
              </div>
            </div>
          </div>
          <div className={styles.main_filter_options_sub_container}>
            <div className={styles.main_role_dropdown_container}>
              <div className={styles.main_role_title2}>
                <Label className={styles.required_field} required>
                  Priority
                </Label>{" "}
              </div>
              <div  className={styles.sec_div} onClick={() => setCurrentHover("priority")}>
                <Dropdown
                  onChange={(e, item) => {
                    dropDownHandler(e, item, "priority");
                    setCurrentHover("");
                  }}
                  selectedKey={demandData.priority}
                  placeholder="Select"
                  notifyOnReselect
                  styles={(props) => DropdownStyles(props, currentHover, errors.priority,demandData.priority, "priority")}
                  options={dropDownPriority}
                />
              </div>
            </div>
            <div className={styles.main_role_dropdown_container}>
              <div className={styles.main_role_title3}>
                <Label className={styles.required_field} required>
                  Client
                </Label>
              </div>
              <div onClick={() => setCurrentHover("client")}>
                {/* <TextField
                  value={demandData.client}
                  onChange={(e, item) => {
                    inputChangeHandler(e, "client");
                  }}
                  placeholder="Enter Client Name"
                  styles={(props) =>
                    textFieldColored(
                      props,
                      currentHover,
                      errors.client,
                      "client"
                    )
                  }
                /> */}

                 <TextField
                      value={demandData.client}
                      onChange={(e) => {
                        inputChangeHandler(e, "client");
                        setCurrentHover("");
                      }}
                      placeholder={"Enter the Name"}
                      // errorMessage={errors.vendor_name}
                      styles={(props) =>
                        textFieldColored2(props, currentHover, errors.client, demandData.client)
                      }
                    />
              </div>
            </div>
          </div>
        </div>

        <div className={styles.container}>
          {/* ----------------------------first div----------------------- */}

          <div className={styles.job_description_container}>
            <div className={styles.job_description}>
            <div className={styles.main_basic_information_title}>
            <Label className={styles.p_job} > 
                Job Description
                 </Label> 
              </div>

              <div
                className={`${styles.main_wysiwyg_container} ${errors.job_description
                    ? styles.main_wysiwyg_container_error
                    : ""
                  } 
								${demandData.job_description.length > 8
                    ? styles.main_wysiwyg_container_focus
                    : ""
                  }`}
              >
                <Editor
                  wrapperClassName={styles.editor_wrapper}
                  toolbar={editorToolbarOptions}
                  toolbarOnFocus
                  toolbarClassName={styles.editor_toolbar}
                  editorClassName={styles.editor_editor}
                  placeholder="Click to add description (Minimum 10 characters)"
                  editorState={editorState}
                  onEditorStateChange={handleEditorStateChange}
                />
              </div>
             
        
            </div>
            <div className={styles.error}>{errorMessage && <p>{errorMessage}</p>}</div>

        
            <div className={styles.additional_description}>
            <div className={styles.main_basic_information_title}>
                <Label className={styles.p_additional} > 
                Additional Information
                 </Label> 
              </div>

              <div
                className={`${styles.main_wysiwyg_container} ${demandData.additional_details.length > 8
                    ? styles.main_wysiwyg_container_focus
                    : ""
                  }`}
              >
                 <Editor
                  wrapperClassName={styles.editor_wrapper}
                  placeholder="Click to add description"
                  toolbarOnFocus
                  toolbarClassName={styles.editor_toolbar}
                  editorClassName={styles.editor_editor}
                  toolbar={editorToolbarOptions}
                  editorState={editorState2}
                  onEditorStateChange={(editorState2) =>
                    setEditorState2(editorState2)
                  }
                />
               
              </div>
             

            </div>
          </div>

          {/* ----------------------------second div----------------------- */}

          <div className={styles.demand_description_container}>
            <div className={styles.demand_information}>
              <p className={styles.p_job_description}>Demand Information</p>
              <div className={styles.two_sub}>
                <div className={styles.two_sub_left}>
                  <Label className={styles.customer_label_style} required>
                    Due Date
                  </Label>

                  <div onClick={() => setCurrentHover("due_date")}>
                    <DatePicker
                     value={new Date(demandData.due_date)}
                      placeholder={"DD/MM/YYYY"}
                      minDate={minDate}
                      styles={calendarClass(demandData.due_date, errors.due_date,"due_date")}
                      onSelectDate={(date) => {
                        dateHandler(date, "due_date");
                      }}
                    />
                  </div>
                </div>

                <div className={styles.two_sub_right}>
                  <Label className={styles.customer_label_style} required>Notice Period</Label>
                  <div onClick={() => setCurrentHover("notice_period")}>
                    <Dropdown
                      onChange={(e, item) => {
                        dropDownHandler(e, item, "notice_period");
                        setCurrentHover("");
                      }}
                      selectedKey={demandData.notice_period}
                      placeholder={"Select"}
                      notifyOnReselect
                      // errorMessage={errors.notice_period}
                      styles={(props) => DropdownStyles1(props, currentHover, errors.notice_period,demandData.notice_period, "notice_period")}
                      options={dropDownNoticePeriod}
                    />
                  </div>
                </div>
              </div>

              <div className={styles.data_month_container}>
                <div className={styles.minimum_exp_container}>
                  <Label className={styles.min_exp_label} required>
                    Minimum Experience
                  </Label>
                  <div className={styles.experience_div}>
                  <TextField
                      placeholder="00"
                      value={typeof demandData.minimum_experience_years === 'string' ? demandData.minimum_experience_years.replace(/\D/g, '') : demandData.minimum_experience_years}
                      onChange={(e) => {
                        inputChangeHandler(e, "minimum_experience_years");
                      }}
                      styles={(props) =>
                        textFieldColored3(props, currentHover, errors.minimum_experience_years, demandData.minimum_experience_years,"minimum_experience_years")
                      }
                      className={styles.year_text_box}
                    />

                    <Label className={styles.experience_text}>Years</Label>
                    <TextField
                      placeholder="00"
                      value={typeof demandData.minimum_experience_months === 'string' ? demandData.minimum_experience_months.replace(/\D/g, '') : demandData.minimum_experience_months}

                      onChange={(e) => {
                        inputChangeHandler(e, "minimum_experience_months");
                      }}
                      className={styles.month_text_box}
                      styles={(props) =>
                        textFieldColored3(props, currentHover, errors.minimum_experience_months,demandData.minimum_experience_months, "minimum_experience_months")
                      }
                    />
                    <Label className={styles.experience_text}>Months</Label>
                  </div>
                </div>

                <div className={styles.maximum_exp_container}>
                  <div>
                    <Label className={styles.min_exp_label} required>
                      Maximum Experience
                    </Label>
                    <div className={styles.experience_div}>
                    <TextField
                      value={typeof demandData.maximum_experience_years === 'string' ? demandData.maximum_experience_years.replace(/\D/g, '') : demandData.maximum_experience_years}
                      placeholder="00"
                        onChange={(e) => {
                          inputChangeHandler(e, "maximum_experience_years");
                        }}
                        styles={(props) =>
                          textFieldColored3(props, currentHover, errors.maximum_experience_years, demandData.maximum_experience_years,"maximum_experience_years")
                        }
                        className={styles.year_text_box}
                      />
                      <Label className={styles.experience_text}>Years</Label>
                      <TextField
                        placeholder="00"
                        value={typeof demandData.maximum_experience_months === 'string' ? demandData.maximum_experience_months.replace(/\D/g, '') : demandData.maximum_experience_months}
                        onChange={(e) => {
                          inputChangeHandler(e, "maximum_experience_months");
                        }}
                        className={styles.month_text_box}
                        styles={(props) =>
                          textFieldColored3(props, currentHover, errors.maximum_experience_months,demandData.maximum_experience_months, "maximum_experience_months")
                        }
                      />
                      <Label className={styles.experience_text}>Months</Label>
                    </div>
                  </div>
                </div>
              </div>

              <div className={styles.mode_of_hire}>
                <Label className={styles.required_field} required>
                  Mode of Hire
                </Label>
              </div>
              <div className={styles.width_of_mode}>
                <div onClick={() => setCurrentHover("mode_of_hire")}>
                  <Dropdown
                    onChange={(e, item) => {
                      dropDownHandler(e, item, "mode_of_hire");
                      setCurrentHover("");
                    }}
                    placeholder="Select"
                    selectedKey={demandData.mode_of_hire}
                    notifyOnReselect
                    styles={(props) => DropdownStyles(props, currentHover, errors.mode_of_hire, demandData.mode_of_hire,"mode_of_hire")}
                    options={modeOfHireDropdown}
                    // errorMessage={errors.mode_of_hire}
                  />
                </div>
              </div>
            </div>

            <div className={styles.vendor_information}>
              <p className={styles.p_job_description}>Vendor Information</p>
              <div className={styles.two_sub}>
                <div className={styles.two_sub_left}>
                  <Label className={styles.customer_label_style} >
                    Vendor Name
                  </Label>

                  <div   onClick={() => setCurrentHover("vendor_name")}>
                   
                  <TextField
                      value={demandData.vendor_name}
                      onChange={(e) => {
                        inputChangeHandler(e, "vendor_name");
                        setCurrentHover("");
                      }}
                      placeholder={"Enter the Name"}
                      // errorMessage={errors.vendor_name}
                      styles={(props) =>
                        textFieldColored2(props, currentHover)
                      }
                    />
                  </div>
                </div>

                <div className={styles.two_sub_right}>
                  <Label className={styles.customer_label_style}>Point of contact Vendor</Label>
                  <div onClick={() => setCurrentHover("poc_vendor")}>
                  <TextField
                          value={demandData.poc_vendor}
                          onChange={(e) => {
                            if (isValidInput(e.target.value)) {
                              inputChangeHandler(e, "poc_vendor");
                              setCurrentHover("");
                            }
                          }}
                          placeholder={"Enter the Name"}
                          styles={(props) =>
                            textFieldColored2(props, currentHover)
                          }
                        />
                  </div>
                </div>
              </div>

              <div className={styles.job_rr_id}>
                <Label className={styles.required_field} >
                  Job / RR ID
                </Label>

                <div onClick={() => setCurrentHover("vendor_name")}>
                <TextField
                          value={demandData.job_rr_id}
                          onChange={(e) => {
                            inputChangeHandler(e, "job_rr_id");
                          }}
                          placeholder={"Enter ID"}
                          // errorMessage={errors.job_rr_id}
                          styles={(props) =>
                            textFieldColored2(props, currentHover)
                          }
                        />
                </div>
              </div>
            </div>
          </div>

          {/* ----------------------------second div----------------------- */}

          <div className={styles.skill_set_container}>
            <div className={styles.skill_sets}>
              <div className={styles.skill_and_add}>
                <p className={styles.p_skill}>Skill Sets</p>
                <div onClick={addSkillSet} className={styles.main_right_add_icon_container}>
                  <CommandBarButton styles={addButtonStyles} iconProps={{ iconName: "Add" }} text="Add " />
                </div>
              </div>

              <div className={styles.main_right_skill_set_experience_container}>
                <div className={styles.main_right_skill_set_title_dropdown_container}>
                  <div className={styles.main_right_skill_set_title_sub_title}>
                    <Label className={styles.required_field} required>
                      Skill Set
                    </Label>
                  </div>
                  {demandData.skillset.map((skillData, index, arr) => (
                    <div key={index} className={styles.main_right_skill_set_dropdown_container}>
                      <ComboBox
                        type="text"
                        name={`skill`}
                        index={index}
                        skillArr={true}
                        arr={arr}
                        setInfo={setDemandData}
                        setInfoErrors={setErrors}
                        inputChangeHandler={skillSetInputHandler}
                        placeholder={demandData.skillset[index]?.skill}
                        // errorMessage={errors.skillset[index]?.skill}
                        dropdown={dropDownSkills}
                        value={
                          index === 0 ? "Primary Skill Set" : index === 1 ? "Secondary Skill Set" : "Other Skills"
                        }
                        comboStyles={(props) => textFieldColored2(props, currentHover,  errors.skillset[index]?.skill)}
                      />
                       
                    </div>
                  ))}
                </div>
                <div className={styles.main_right_skill_experience_container}>
                  <div className={styles.main_right_skill_experience_title_sub_title}>
                    <Label className={styles.required_field} required>
                      Relevant Skill Experience
                    </Label>
                  </div>
                  {demandData.skillset.map((skillData, index, arr) => (
                    <div key={index} className={styles.main_right_skill_experience_dropdown_remove_icon_container}>
                      <div className={styles.main_right_skill_experience_dropdown_container}>
                        <div className={styles.skill_alignment} onClick={() => setCurrentHover(`years${index}`)}>
                          <TextField
                            value={demandData.skillset[index]?.years}
                            // errorMessage={errors.skillset[index]?.years}
                            onChange={(e) => {
                              skillSetInputHandler(e, "years", index, arr);
                            }}
                            placeholder="00"
                            styles={(props) =>
                              textFieldColored3(props, currentHover, errors.skillset[index]?.years,demandData.skillset[index]?.years,  `years${index}`)
                            }
                          />
                          <Label className={styles.experience_text}>Years</Label>
                        </div>
                        <div className={styles.skill_alignment}>
                          <TextField
                            value={demandData.skillset[index]?.months}
                            // errorMessage={errors.skillset[index]?.months}
                            onChange={(e) => {
                              skillSetInputHandler(e, "months", index, arr);
                            }}
                            placeholder="00"
                            className={styles.month_text_box}
                            styles={(props) =>
                              textFieldColored3(props, currentHover, errors.skillset[index]?.months,  demandData.skillset[index]?.months,`months${index}`)
                            }
                          />
                          <Label className={styles.experience_text}>Months</Label>
                        </div>
                        <Icon
                          iconName="ChromeClose"
                          className={removeIconClass}
                          onClick={() => removeSkill(skillData, index, arr)}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
       <div className={styles.linked_candidates}>
              <p className={styles.p_linked}>Linked Candidates</p>
              <div className={styles.contentWrapper} onScroll={handleScroll}>
                {linkedData.length != 0 ?
                  linkedData.map(data => (
                    <div className={styles.linkedboxContainer}>

                      <p className={styles.content_level}>{demandData.status}</p>
                      <div className={styles.contentContainer}>
                        <p onClick={() =>     navigateTo(`/candidatelibrary/viewcandidate?candidate_id=${data._Id}`)}>{data.CandidateId}</p>
                        <p className={styles.content}>{data.CandidateName}<span className={styles.skill}>{`(${demandData.skillset[0].skill})`} </span></p>
                      </div>
                      <div className={styles.contentContainer}>
                        <div className={styles.updateContent}>
                          Updated  {ISOdateToCustomDate(data.UpdatedAt)}</div>
                        <Icon
                          iconName="LocationDot"
                          style={{
                            fontSize: "16px",
                            color:( data.Status === "level_1_select"|| data.Status === "level_2_select"|| data.Status === "final_select"|| data.Status === "offer_accept"|| data.Status === "onboard_select"|| data.Status === "bg_verification_select"|| data.Status === "initial_screening_select" )
                            ? "#13A10E" :
                              (data.Status === "bg_verification_reject" || data.Status === "onboard_reject"|| data.Status === "offer_denied"|| data.Status === "final_reject"|| data.Status === "Interview_Drop_3"|| data.Status === "Interview_Drop_2"|| data.Status === "Interview_Drop_1"|| data.Status === "level_2_reject"|| data.Status === "level_1_reject"|| data.Status === "initial_screening_reject")
                            ? "#DE1414" : "#0078D4"
                          }}
                        /><p>{data.Status}</p>

                      </div>
                    </div>

                  )) :
                  <a href="#" className={styles.noLinked}>
                    No Linked Opportunities
                  </a>
                }
              </div>

            </div>
            </div>
            </div>

    </div>
  );
};

export default EditDemand;