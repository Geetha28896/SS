import React,{useEffect,useState} from 'react'
import { Modal} from '@fluentui/react'
import styles from './Popup.module.css'
import { Icon } from '@fluentui/react/lib/Icon';
import {PrimaryButton, DefaultButton} from '@fluentui/react';

 
const textFieldColored1 = (props, currentHover, error, value) => {
    const borderColor = "#E1E5E8";
    const hoverBorderColor = "#E1E5E8"; // Same color for hover state

    return {
        text: {
            border: "1px solid #E1E5E8",
            borderRadius:"3px",
            width:"295px",
            selectors: {
                '&:hover': {
                    border: '1px solid rgb(96, 94, 92)',
                },
                '&:focus': {
                    border: '1px solid yellow',
                },
            },
        },
    }
};
  export function EventCancelPopup(props) {
     
    let showPopup = props.showPopup;
    let setShowPopup = props.setShowPopup;
    const titleValue = props.titleValue;
    const handleUpdate=()=>{
         props.handleUpdate(!showPopup)
        
        }
    

    return(
    <>
    
        <Modal isOpen={showPopup} containerClassName={styles.main_cancel_popup}>

            <div className={styles.cancelClosePopup}>
                <div className={styles.cancelTopContainer}>
                
                    <div className={styles.cancelTitle}>{`Are you sure you want to cancel this interview (${titleValue})?`}</div>

                    <div className={styles.cancelCloseButton} onClick={() => setShowPopup(!showPopup)}><Icon iconName='ChromeClose'/></div>
                </div>

                <div className={styles.message}> This action cannot be undone. Please select 'Yes'
                to confirm cancellation, or select 'No' to return without cancelling.
                </div>
                <div className={styles.cancelBottomContainer}>
                    <div className={styles.spacer}></div>
                    <div className={styles.cancelButtonContainer}>
                        <DefaultButton text={`No`} onClick={() => {
                            setShowPopup(!showPopup)}}
                            className={styles.eventCancelNo}
                             />
                        <PrimaryButton text={`Yes`} 
                            onClick={() => {
                                handleUpdate() }}
                                className={styles.eventCancelYes}
                            />
   
                    </div>
                </div>
               
            </div>
        </Modal>
    </>
    )
}
