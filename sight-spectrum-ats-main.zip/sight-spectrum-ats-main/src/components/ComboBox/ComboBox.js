
import React, { useState, useRef, useEffect } from "react";
import Fuse from "fuse.js";
import { TextField } from "@fluentui/react";
import styles from "./ComboBox.module.css";

function ComboBox(props) {
  console.log(props,"ksss")
  let dropdown = props.dropdown?.map((value) => {
    return { item: value };
  });
  const [isDroped, setIsDroped] = useState(false);
  const [options, setOptions] = useState([...dropdown]);
  const refDrop = useRef();
  const [value, setValue] = useState("");
  const [currentHover, setCurrentHover] = useState("");

  let inputChangeHandler = props.inputChangeHandler;
  let name = props.name;
  let error = props.errorMessage;
  let setInfo = props.setInfo;
  let setInfoErrors = props.setInfoErrors;
  let index = props.index;
  let textfield = props.textfield;

  const textField = (props, currentHover, error, value) => {
    return {
      fieldGroup: {
        height: "22px",
        width: "100%",
        borderColor: error ? "#a80000" : "transparent",
        selectors: {
          ":focus": {
            borderColor: "rgb(96, 94, 92)",
          },
        },
      },
      field: { lineHeight: "24px", fontSize: 12 },
    };
  };

  const textFieldColored = (props, currentHover, error, value) => {
    return {
      fieldGroup: {
        width: "160px",
        height: "22px",
        backgroundColor: "#EDF2F6",
        borderColor: error ? "#a80000" : "transparent",

        selectors: {
          ":focus": {
            borderColor: "rgb(96, 94, 92)",
          },
        },
      },
      field: {
        fontSize: 12,
      },
    };
  };

  const fuse = new Fuse(props.dropdown, {
    keys: ["text"],
  });

  useEffect(() => {
    document.addEventListener("click", handleOutsideClick, true);
  }, []);

  useEffect(() => {}, [options]);

  function handleOutsideClick(e) {
    if (!refDrop.current?.contains(e.target)) {
      setIsDroped(false);
    }
  }

  function dropdownContents(event) {
    let data = event.target.value;
    let result = fuse.search(data);
    if (data) {
      setOptions([...result]);
    } else {
      setOptions([...dropdown]);
    }
  }

  function textValue(event) {
    let data = event.target.value;
    setValue(data);
  }

  function select(text, name, key) {
    setValue(text);
    if (index === undefined) {
      setInfo((prevState) => {
        return { ...prevState, [name]: key };
      });
      setInfoErrors((prevState) => {
        return { ...prevState, [name]: null };
      });
    } else {
      // Handle state update for arrays
    }
    setIsDroped(false);
  }

  const keyValue = (text, key) => {
    select(text, name, key);
  };

  const handleFocus = () => {
    setIsDroped(true);
  };

  const handleClick = () => {
    setIsDroped(!isDroped);
  };

  return (
    <div styles={{ minWidth: props.width, height: "20px" }} className={styles.container}>
      <div className={styles.combo_container}>
        <div className={styles.input_container} onClick={handleClick}>
          <TextField
            type="text"
            name={props.name}
            placeholder={props.placeholder}
            value={value}
            errorMessage={props.showError ? error : null}
            styles={props.comboStyles}
            onChange={(event) => {
              dropdownContents(event, setInfo);
              textValue(event);
              if (props.skillArr) {
                inputChangeHandler(event, name, index, props.arr);
              } else {
                index === undefined
                  ? inputChangeHandler(event, name, setInfo, setInfoErrors)
                  : inputChangeHandler(event, name, index, setInfo, setInfoErrors);
              }
            }}
            onFocus={handleFocus} // Show dropdown when the text field receives focus
          />
        </div>
        {isDroped && (
        <div className={styles.dropdown_container} ref={refDrop}>
          {options.map((value) => (
              <div key={value.item.key} onClick={() => keyValue(value.item.text, value.item.key)} className={styles.dropdown_option}>
                {value.item.text}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default ComboBox;

// import React, { useState, useRef, useEffect } from "react";
// import Fuse from "fuse.js";
// import { TextField } from "@fluentui/react";
// import styles from "./ComboBox.module.css";

// function ComboBox(props) {
//   const [isDropped, setIsDropped] = useState(false);

//   let dropdown = props.dropdown?.map((value) => {
//     return { item: value };
//   });
//   const [isDroped, setIsDroped] = useState(false);
//   const [options, setOptions] = useState([...dropdown]);
//   const refDrop = useRef();
//   const [value, setValue] = useState("");
//   const [currentHover, setCurrentHover] = useState("");

//   let inputChangeHandler = props.inputChangeHandler;
//   let name = props.name;
//   let error = props.errorMessage;
//   let setInfo = props.setInfo;
//   let setInfoErrors = props.setInfoErrors;
//   let index = props.index;
//   let textfield = props.textfield;

//   const textField = (props, currentHover, error, value) => {
//     return {
//       fieldGroup: {
//         height: "22px",
//         width: "100%",
//         borderColor: error ? "#a80000" : "transparent",
//         selectors: {
//           ":focus": {
//             borderColor: "rgb(96, 94, 92)",
//           },
//         },
//       },
//       field: { lineHeight: "24px", fontSize: 12 },
//     };
//   };

//   const textFieldColored = (props, currentHover, error, value) => {
//     return {
//       fieldGroup: {
//         width: "160px",
//         height: "22px",
//         backgroundColor: "#EDF2F6",
//         borderColor: error ? "#a80000" : "transparent",

//         selectors: {
//           ":focus": {
//             borderColor: "rgb(96, 94, 92)",
//           },
//         },
//       },
//       field: {
//         fontSize: 12,
//       },
//     };
//   };

//   const fuse = new Fuse(props.dropdown, {
//     keys: ["text"],
//   });

//   useEffect(() => {
//     document.addEventListener("click", handleOutsideClick, true);
//   }, []);

//   useEffect(() => {}, [options]);

//   function handleOutsideClick(e) {
//     if (!refDrop.current?.contains(e.target)) {
//       setIsDroped(false);
//     }
//   }

//   function dropdownContents(event) {
//     let data = event.target.value;
//     let result = fuse.search(data);
//     if (data) {
//       setOptions([...result]);
//     } else {
//       setOptions([...dropdown]);
//     }
//   }

//   function textValue(event) {
//     let data = event.target.value;
//     setValue(data);
//   }

//   function select(text, name, key) {
//     setValue(text);
//     if (index === undefined) {
//       setInfo((prevState) => {
//         return { ...prevState, [name]: key };
//       });
//       setInfoErrors((prevState) => {
//         return { ...prevState, [name]: null };
//       });
//     } else {
//       // Handle state update for arrays
//     }
//     setIsDroped(false);
//   }

//   const keyValue = (text, key) => {
//     select(text, name, key);
//   };

//   const handleFocus = () => {
//     setIsDroped(true);
//   };

//   const handleClick = () => {
//     setIsDroped(!isDroped);
//   };







//   function handleBlur() {
//     setIsDropped(false);
//   }

//   return (
//     <div styles={{ minWidth: props.width, height: "20px" }} className={styles.container}>
//       <div className={styles.combo_container}>
//         <div className={styles.input_container} onClick={handleClick}>
//           <TextField
//             type="text"
//             name={props.name}
//             placeholder={props.placeholder}
//             value={value}
//             errorMessage={props.showError ? error : null}
//             styles={props.comboStyles}
//             onChange={(event) => {
//               dropdownContents(event, setInfo);
//               textValue(event);
//               if (props.skillArr) {
//                 inputChangeHandler(event, name, index, props.arr);
//               } else {
//                 index === undefined
//                   ? inputChangeHandler(event, name, setInfo, setInfoErrors)
//                   : inputChangeHandler(event, name, index, setInfo, setInfoErrors);
//               }
//             }}
//             onFocus={handleFocus} // Show dropdown when the text field receives focus
//             onBlur={handleBlur} // Close dropdown when the text field loses focus
//           />
//         </div>
//         {isDropped && (
//           <div className={styles.dropdown_container} ref={refDrop}>
//             {options.map((value) => (
//               <div key={value.item.key} onClick={() => keyValue(value.item.text, value.item.key)} className={styles.dropdown_option}>
//                 {value.item.text}
//               </div>
//             ))}
//           </div>
//         )}
//       </div>
//     </div>
//   );
// }

// export default ComboBox;
